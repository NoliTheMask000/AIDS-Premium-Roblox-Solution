wait(0.5)
Parts = {}
function GetDiscoColor(hue)
  local section = hue % 1 * 3
  local secondary = 0.5 * math.pi * (section % 1)
  if section < 1 then
    return Vector3.new(1, 1 - math.cos(secondary), 1 - math.sin(secondary))
  elseif section < 2 then
    return Vector3.new(1 - math.sin(secondary), 1, 1 - math.cos(secondary))
  else
    return Vector3.new(1 - math.cos(secondary), 1 - math.sin(secondary), 1)
  end
end
function Part(x, y, z, color, tr, cc, an, parent)
  local p = Instance.new("Part", parent or Weapon)
  p.formFactor = "Custom"
  p.Size = Vector3.new(x, y, z)
  p.BrickColor = BrickColor.new(color)
  p.CanCollide = cc
  p.Transparency = tr
  p.Anchored = an
  p.TopSurface, p.BottomSurface = 0, 0
  p:BreakJoints("")
  table.insert(Parts, p)
  return p
end
function Weld(p0, p1)
  local w = Instance.new("Motor", p0)
  w.Part0 = p0
  w.Part1 = p1
  return w
end
plr = Game.Players.LocalPlayer
char = plr.Character
local verlet = {}
verlet.step_time = 0.02
verlet.gravity = Vector3.new(0, -10, 0)
local char = game.Players.LocalPlayer.Character
local torso = char:WaitForChild("Torso")
local parts = {}
local render = game:GetService("RunService").RenderStepped
local point = {}
local link = {}
local rope = {}
local ccw = function(A, B, C)
  return (C.y - A.y) * (B.x - A.x) > (B.y - A.y) * (C.x - A.x)
end
local function intersect(A, B, C, D)
  return ccw(A, C, D) ~= ccw(B, C, D) and ccw(A, B, C) ~= ccw(A, B, D)
end
local vec2 = function(v)
  return Vector2.new(v.x, v.z)
end
function point:step()
  if not self.fixed then
    local derivative = (self.position - self.last_position) * 0.95
    self.last_position = self.position
    self.position = self.position + derivative + self.velocity * verlet.step_time ^ 2
  end
end
function link:step()
  for i = 1, 1 do
    local distance = self.point1.position - self.point2.position
    local magnitude = distance.magnitude
    local differance = (self.length - magnitude) / magnitude
    local translation = ((self.point1.fixed or self.point2.fixed) and 1 or 0.6) * distance * differance
    if not self.point1.fixed then
      self.point1.position = self.point1.position + translation
    end
    if not self.point2.fixed then
      self.point2.position = self.point2.position - translation
    end
  end
end
function verlet.new(class, a, b, c)
  if class == "Point" then
    local new = {}
    setmetatable(new, {__index = point})
    new.class = class
    new.position = a or Vector3.new()
    new.last_position = new.position
    new.velocity = verlet.gravity
    new.fixed = false
    return new
  elseif class == "Link" then
    local new = {}
    setmetatable(new, {__index = link})
    new.class = class
    new.point1 = a
    new.point2 = b
    new.length = c or (a.position - b.position).magnitude
    return new
  elseif class == "Rope" then
    local new = {}
    setmetatable(new, {__index = link})
    new.class = class
    new.start_point = a
    new.finish_point = b
    new.points = {}
    new.links = {}
    local inc = (b - a) / 10
    for i = 0, 10 do
      table.insert(new.points, verlet.new("Point", a + i * inc))
    end
    for i = 2, #new.points do
      table.insert(new.links, verlet.new("Link", new.points[i - 1], new.points[i]))
    end
    return new
  end
end
local tris = {}
local triParts = {}
local GetDiscoColor = function(hue)
  local section = hue % 1 * 3
  local secondary = 0.5 * math.pi * (section % 1)
  if section < 1 then
    return Color3.new(1, 1 - math.cos(secondary), 1 - math.sin(secondary))
  elseif section < 2 then
    return Color3.new(1 - math.sin(secondary), 1, 1 - math.cos(secondary))
  else
    return Color3.new(1 - math.cos(secondary), 1 - math.sin(secondary), 1)
  end
end
local setupPart = function(part)
  part.Anchored = true
  part.FormFactor = 3
  part.CanCollide = false
  part.TopSurface = 10
  part.BottomSurface = 10
  part.LeftSurface = 10
  part.RightSurface = 10
  part.FrontSurface = 10
  part.BackSurface = 10
  part.Material = "Neon"
  local m = Instance.new("SpecialMesh", part)
  m.MeshType = "Wedge"
  m.Scale = Vector3.new(0.2, 1, 1)
  return part
end
local CFrameFromTopBack = function(at, top, back)
  local right = top:Cross(back)
  return CFrame.new(at.x, at.y, at.z, right.x, top.x, back.x, right.y, top.y, back.y, right.z, top.z, back.z)
end
local function drawTri(parent, a, b, c)
  local this = {}
  local mPart1 = table.remove(triParts, 1) or setupPart(Instance.new("Part"))
  local mPart2 = table.remove(triParts, 1) or setupPart(Instance.new("Part"))
  function this:Set(a, b, c)
    local ab, bc, ca = b - a, c - b, a - c
    local abm, bcm, cam = ab.magnitude, bc.magnitude, ca.magnitude
    local edg1 = math.abs(0.5 + ca:Dot(ab) / (abm * abm))
    local edg2 = math.abs(0.5 + ab:Dot(bc) / (bcm * bcm))
    local edg3 = math.abs(0.5 + bc:Dot(ca) / (cam * cam))
    if edg1 < edg2 then
      if edg1 >= edg3 then
        a, b, c = c, a, b
        ab, bc, ca = ca, ab, bc
        abm = cam
      end
    elseif edg2 < edg3 then
      a, b, c = b, c, a
      ab, bc, ca = bc, ca, ab
      abm = bcm
    else
      a, b, c = c, a, b
      ab, bc, ca = ca, ab, bc
      abm = cam
    end
    local len1 = -ca:Dot(ab) / abm
    local len2 = abm - len1
    local width = ca + (ab.unit * len1).magnitude
    local maincf = CFrameFromTopBack(a, ab:Cross(bc).unit, -ab.unit)
    if len1 > 0.2 then
      mPart1.Parent = parent
      mPart1.Size = Vector3.new(0.2, width, len1)
      mPart1.CFrame = maincf * CFrame.Angles(math.pi, 0, math.pi / 2) * CFrame.new(0, width / 2, len1 / 2)
    else
      mPart1.Parent = nil
    end
    if len2 > 0.2 then
      mPart2.Parent = parent
      mPart2.Size = Vector3.new(0.2, width, len2)
      mPart2.CFrame = maincf * CFrame.Angles(math.pi, math.pi, -math.pi / 2) * CFrame.new(0, width / 2, -len1 - len2 / 2)
    else
      mPart2.Parent = nil
    end
  end
  function this:SetProperty(prop, value)
    mPart1[prop] = value
    mPart2[prop] = value
  end
  this:Set(a, b, c)
  function this:Destroy()
    mPart1:Destroy()
    mPart2:Destroy()
  end
  this.p1 = mPart1
  this.p2 = mPart2
  this.p1.BrickColor = BrickColor.new(GetDiscoColor(math.noise(0.5, 0.5, this.p1.CFrame.Y * 0.5 + time())))
  this.p2.BrickColor = BrickColor.new(GetDiscoColor(math.noise(0.5, 0.5, this.p2.CFrame.Y * 0.5 + time())))
  return this
end
function verlet.draw(object, id)
  if object.class == "Point" then
    local part = parts[id]
    part.BrickColor = BrickColor.new(1, 1, 1)
    part.Transparency = 0
    part.formFactor = 3
    part.Anchored = true
    part.CanCollide = false
    part.TopSurface = 0
    part.BottomSurface = 0
    part.Size = Vector3.new(0.35, 0.35, 0.35)
    part.Material = "Neon"
    part.CFrame = CFrame.new(object.position)
    part.Parent = torso
    return part
  elseif object.class == "Link" then
    local part = parts[id]
    local dist = (object.point1.position - object.point2.position).magnitude
    part.Size = Vector3.new(0.2, 0.2, dist)
    part.CFrame = CFrame.new(object.point1.position, object.point2.position) * CFrame.new(0, 0, dist * -0.5)
    part.Parent = torso
    return part
  end
end
function verlet.clear()
  for _, v in pairs(workspace:GetChildren()) do
    if v.Name == "Part" then
      v:Destroy()
    end
  end
end
local points = {}
local links = {}
for x = 0, 2 do
  points[x] = {}
  for y = 0, 3 do
    points[x][y] = verlet.new("Point", torso.Position + Vector3.new(x * 0.8 - 2, 2 - y * 0.8, 5 + y * 0.4))
    points[x][y].fixed = y == 0
  end
end
for x = 1, 2 do
  for y = 0, 3 do
    links[#links + 1] = verlet.new("Link", points[x][y], points[x - 1][y], 1 + y * 0.08)
  end
end
for x = 0, 2 do
  for y = 1, 3 do
    links[#links + 1] = verlet.new("Link", points[x][y], points[x][y - 1], 1.2 + y * 0.03)
  end
end
local AA1 = {}
v = game.Players.LocalPlayer
if v.Character ~= nil then
end
local WorldUp = Vector3.new(0, 1, 0)
function Look2(Vec1, Vec2)
  local Orig = Vec1
  Vec1 = Vec1 + Vector3.new(0, 1, 0)
  Vec2 = Vec2 + Vector3.new(0, 1, 0)
  local Forward = Vec2 - Vec1.unit
  local Up = WorldUp - WorldUp:Dot(Forward) * Forward.unit
  local Right = Up:Cross(Forward).unit
  Forward = -Forward
  Right = -Right
  return CFrame.new(Orig.X, Orig.Y, Orig.Z, Right.X, Up.X, Forward.X, Right.Y, Up.Y, Forward.Y, Right.Z, Up.Z, Forward.Z)
end
function Look(CFr, Vec2)
  local A = Vector3.new(0, 0, 0)
  local B = CFr:inverse() * Vec2
  local CF = Look2(A, Vector3.new(A.X, B.Y, B.Z))
  if 0 < B.Z then
    CF = CFr * (CF * CFrame.Angles(0, 0, math.pi))
  elseif B.Z == 0 then
    if 0 < B.Y then
      CF = CFr * CFrame.Angles(math.pi / 2, 0, 0)
    elseif 0 > B.Y then
      CF = CFr * CFrame.Angles(-math.pi / 2, 0, 0)
    else
      CF = CFr
    end
  end
  local _, _, _, _, X, _, _, Y, _, _, Z, _ = CF:components()
  local Up = Vector3.new(X, Y, Z)
  local Forward = Vec2 - CFr.p.unit
  local Right = Up:Cross(Forward)
  Forward = -Forward
  Right = -Right
  return CFrame.new(CFr.X, CFr.Y, CFr.Z, Right.X, Up.X, Forward.X, Right.Y, Up.Y, Forward.Y, Right.Z, Up.Z, Forward.Z)
end
Player = game:GetService("Players").LocalPlayer
Character = Player.Character
Character.Animate.idle.Animation2:Remove()
PlayerGui = Player.PlayerGui
Backpack = Player.Backpack
Torso = Character.Torso
Head = Character.Head
Humanoid = Character.Humanoid
m = Instance.new("Model", Character)
LeftArm = Character["Left Arm"]
LeftLeg = Character["Left Leg"]
RightArm = Character["Right Arm"]
RightLeg = Character["Right Leg"]
LS = Torso["Left Shoulder"]
LH = Torso["Left Hip"]
RS = Torso["Right Shoulder"]
RH = Torso["Right Hip"]
Face = Head.face
Neck = Torso.Neck
it = Instance.new
attacktype = 1
vt = Vector3.new
busterammo = 16
maxbusterammo = 16
Humanoid.Health = 1000
Humanoid.WalkSpeed = 20
cf = CFrame.new
holdE = false
euler = CFrame.fromEulerAnglesXYZ
angles = CFrame.Angles
cloaked = false
necko = cf(0, 1, 0, -1, 0, 0, 0, 0, 1, 0, 1, 0)
necko2 = cf(0, -0.5, 0, -1, 0, 0, 0, 0, 1, 0, 1, 0)
LHC0 = cf(-1, -1, 0, 0, 0, -1, 0, 1, 0, 1, 0, 0)
LHC1 = cf(-0.5, 1, 0, 0, 0, -1, 0, 1, 0, 1, 0, 0)
RHC0 = cf(1, -1, 0, 0, 0, 1, 0, 1, 0, -1, 0, 0)
RHC1 = cf(0.5, 1, 0, 0, 0, 1, 0, 1, 0, -1, 0, 0)
RootPart = Character.HumanoidRootPart
RootJoint = RootPart.RootJoint
RootCF = euler(-1.57, 0, 3.14)
attack = false
attackdebounce = false
deb = false
equipped = true
hand = false
MMouse = nil
combo = 0
mana = 0
trispeed = 0.2
attackmode = "none"
local idle = 0
local Anim = "Idle"
local Effects = {}
local gun = false
local shoot = false
player = nil
mana = 0
local CurrentMode = "Sheathed"
function VertexRainbow()
  while true do
    return BrickColor.new("White")
  end
end
local Gui = Instance.new("ScreenGui", PlayerGui)
Gui.Name = "WeaponGui"
local Ammo1 = Instance.new("TextLabel", Gui)
Ammo1.Name = "Buster"
Ammo1.Text = "Buster ammo:" .. busterammo .. "/" .. maxbusterammo
Ammo1.TextStrokeTransparency = 0
Ammo1.Font = "Garamond"
Ammo1.BackgroundTransparency = 1
Ammo1.TextColor3 = BrickColor.Yellow().Color
Ammo1.TextStrokeColor3 = BrickColor.Black().Color
Ammo1.Position = UDim2.new(0, 0, 0.5, 0)
Ammo1.TextScaled = true
Ammo1.Size = UDim2.new(0, 100, 0, 20)
mouse = Player:GetMouse()
RSH, LSH = nil, nil
RW, LW = Instance.new("Weld"), Instance.new("Weld")
RW.Name = "Right Shoulder"
LW.Name = "Left Shoulder"
LH = Torso["Left Hip"]
RH = Torso["Right Hip"]
TorsoColor = Torso.BrickColor
function NoOutline(Part)
  Part.TopSurface, Part.BottomSurface, Part.LeftSurface, Part.RightSurface, Part.FrontSurface, Part.BackSurface = 10, 10, 10, 10, 10, 10
end
player = Player
ch = Character
RSH = ch.Torso["Right Shoulder"]
LSH = ch.Torso["Left Shoulder"]
RSH.Parent = nil
LSH.Parent = nil
RW.Name = "Right Shoulder"
RW.Part0 = ch.Torso
RW.C0 = cf(1.5, 0.5, 0)
RW.C1 = cf(0, 0.5, 0)
RW.Part1 = ch["Right Arm"]
RW.Parent = ch.Torso
LW.Name = "Left Shoulder"
LW.Part0 = ch.Torso
LW.C0 = cf(-1.5, 0.5, 0)
LW.C1 = cf(0, 0.5, 0)
LW.Part1 = ch["Left Arm"]
LW.Parent = ch.Torso
local weldBetween = function(a, b)
  local weldd = Instance.new("ManualWeld")
  weldd.Part0 = a
  weldd.Part1 = b
  weldd.C0 = CFrame.new()
  weldd.C1 = b.CFrame:inverse() * a.CFrame
  weldd.Parent = a
  return weldd
end
function nooutline(part)
  part.TopSurface, part.BottomSurface, part.LeftSurface, part.RightSurface, part.FrontSurface, part.BackSurface = 10, 10, 10, 10, 10, 10
end
function part(formfactor, parent, material, reflectance, transparency, brickcolor, name, size)
  local fp = it("Part")
  fp.formFactor = formfactor
  fp.Parent = parent
  fp.Reflectance = reflectance
  fp.Transparency = transparency
  fp.CanCollide = false
  fp.Locked = true
  fp.BrickColor = BrickColor.new(tostring(brickcolor))
  fp.Name = name
  fp.Size = size
  fp.Position = Character.Torso.Position
  nooutline(fp)
  fp.Material = material
  fp:BreakJoints()
  return fp
end
function swait(num)
  if num == 0 or num == nil then
    game:service("RunService").Heartbeat:wait(0)
  else
    for i = 0, num do
      game:service("RunService").Heartbeat:wait(0)
    end
  end
end
function mesh(Mesh, part, meshtype, meshid, offset, scale)
  local mesh = it(Mesh)
  mesh.Parent = part
  if Mesh == "SpecialMesh" then
    mesh.MeshType = meshtype
    mesh.MeshId = meshid
  end
  mesh.Offset = offset
  mesh.Scale = scale
  return mesh
end
function weld(parent, part0, part1, c0, c1)
  local weld = it("Weld")
  weld.Parent = parent
  weld.Part0 = part0
  weld.Part1 = part1
  weld.C0 = c0
  weld.C1 = c1
  return weld
end
local CFrameFromTopBack = function(at, top, back)
  local right = top:Cross(back)
  return CFrame.new(at.x, at.y, at.z, right.x, top.x, back.x, right.y, top.y, back.y, right.z, top.z, back.z)
end
function Triangle(a, b, c)
    --[[
local edg1 = (c-a):Dot((b-a).unit)
local edg2 = (a-b):Dot((c-b).unit)
local edg3 = (b-c):Dot((a-c).unit)
if edg1 <= (b-a).magnitude and edg1 >= 0 then
a, b, c = a, b, c
elseif edg2 <= (c-b).magnitude and edg2 >= 0 then
a, b, c = b, c, a
elseif edg3 <= (a-c).magnitude and edg3 >= 0 then
a, b, c = c, a, b
else
assert(false, "unreachable")
end
 
local len1 = (c-a):Dot((b-a).unit)
local len2 = (b-a).magnitude - len1
local width = (a + (b-a).unit*len1 - c).magnitude
 
local maincf = CFrameFromTopBack(a, (b-a):Cross(c-b).unit, -(b-a).unit)
 
local list = {}

local TrailColor = ("Royal purple")
 
if len1 > 0.01 then
local w1 = Instance.new('WedgePart', m)
game:GetService("Debris"):AddItem(w1,5)
w1.Material = "Neon"
w1.FormFactor = 'Custom'
w1.BrickColor = VertexRainbow()
w1.Transparency = 0
w1.Reflectance = 0
w1.Material = "Neon"
w1.CanCollide = false
NoOutline(w1)
local sz = Vector3.new(0.2, width, len1)
w1.Size = sz
local sp = Instance.new("SpecialMesh",w1)
sp.MeshType = "Wedge"
sp.Scale = Vector3.new(0,1,1) * sz/w1.Size
w1:BreakJoints()
w1.Anchored = true
w1.Parent = workspace
w1.Transparency = 0.7
table.insert(Effects,{w1,"Disappear",.01})
w1.CFrame = maincf*CFrame.Angles(math.pi,0,math.pi/2)*CFrame.new(0,width/2,len1/2)
table.insert(list,w1)
end
 
if len2 > 0.01 then
local w2 = Instance.new('WedgePart', m)
game:GetService("Debris"):AddItem(w2,5)
w2.Material = "Neon"
w2.FormFactor = 'Custom'
w2.BrickColor = VertexRainbow()
w2.Transparency = 0
w2.Reflectance = 0
w2.Material = "Neon"
w2.CanCollide = false
NoOutline(w2)
local sz = Vector3.new(0.2, width, len2)
w2.Size = sz
local sp = Instance.new("SpecialMesh",w2)
sp.MeshType = "Wedge"
sp.Scale = Vector3.new(0,1,1) * sz/w2.Size
w2:BreakJoints()
w2.Anchored = true
w2.Parent = workspace
w2.Transparency = 0.7
table.insert(Effects,{w2,"Disappear",.01})
w2.CFrame = maincf*CFrame.Angles(math.pi,math.pi,-math.pi/2)*CFrame.new(0,width/2,-len1 - len2/2)
table.insert(list,w2)
end
return unpack(list)
]]
return nil
end
function so(id, par, vol, pit)
  coroutine.resume(coroutine.create(function()
    local sou = Instance.new("Sound", par or workspace)
    sou.Volume = vol
    sou.Pitch = pit or 1
    sou.SoundId = id
    swait()
    sou:play()
    game:GetService("Debris"):AddItem(sou, 6)
  end))
end
function clerp(a, b, t)
  local qa = {
    QuaternionFromCFrame(a)
  }
  local qb = {
    QuaternionFromCFrame(b)
  }
  local ax, ay, az = a.x, a.y, a.z
  local bx, by, bz = b.x, b.y, b.z
  local _t = 1 - t
  return QuaternionToCFrame(_t * ax + t * bx, _t * ay + t * by, _t * az + t * bz, QuaternionSlerp(qa, qb, t))
end
function QuaternionFromCFrame(cf)
  local mx, my, mz, m00, m01, m02, m10, m11, m12, m20, m21, m22 = cf:components()
  local trace = m00 + m11 + m22
  if trace > 0 then
    local s = math.sqrt(1 + trace)
    local recip = 0.5 / s
    return (m21 - m12) * recip, (m02 - m20) * recip, (m10 - m01) * recip, s * 0.5
  else
    local i = 0
    if m00 < m11 then
      i = 1
    end
    if m22 > (i == 0 and m00 or m11) then
      i = 2
    end
    if i == 0 then
      local s = math.sqrt(m00 - m11 - m22 + 1)
      local recip = 0.5 / s
      return 0.5 * s, (m10 + m01) * recip, (m20 + m02) * recip, (m21 - m12) * recip
    elseif i == 1 then
      local s = math.sqrt(m11 - m22 - m00 + 1)
      local recip = 0.5 / s
      return (m01 + m10) * recip, 0.5 * s, (m21 + m12) * recip, (m02 - m20) * recip
    elseif i == 2 then
      local s = math.sqrt(m22 - m00 - m11 + 1)
      local recip = 0.5 / s
      return (m02 + m20) * recip, (m12 + m21) * recip, 0.5 * s, (m10 - m01) * recip
    end
  end
end
function QuaternionToCFrame(px, py, pz, x, y, z, w)
  local xs, ys, zs = x + x, y + y, z + z
  local wx, wy, wz = w * xs, w * ys, w * zs
  local xx = x * xs
  local xy = x * ys
  local xz = x * zs
  local yy = y * ys
  local yz = y * zs
  local zz = z * zs
  return CFrame.new(px, py, pz, 1 - (yy + zz), xy - wz, xz + wy, xy + wz, 1 - (xx + zz), yz - wx, xz - wy, yz + wx, 1 - (xx + yy))
end
function QuaternionSlerp(a, b, t)
  local cosTheta = a[1] * b[1] + a[2] * b[2] + a[3] * b[3] + a[4] * b[4]
  local startInterp, finishInterp
  if cosTheta >= 1.0E-4 then
    if 1 - cosTheta > 1.0E-4 then
      local theta = math.acos(cosTheta)
      local invSinTheta = 1 / math.sin(theta)
      startInterp = math.sin((1 - t) * theta) * invSinTheta
      finishInterp = math.sin(t * theta) * invSinTheta
    else
      startInterp = 1 - t
      finishInterp = t
    end
  elseif 1 + cosTheta > 1.0E-4 then
    local theta = math.acos(-cosTheta)
    local invSinTheta = 1 / math.sin(theta)
    startInterp = math.sin((t - 1) * theta) * invSinTheta
    finishInterp = math.sin(t * theta) * invSinTheta
  else
    startInterp = t - 1
    finishInterp = t
  end
  return a[1] * startInterp + b[1] * finishInterp, a[2] * startInterp + b[2] * finishInterp, a[3] * startInterp + b[3] * finishInterp, a[4] * startInterp + b[4] * finishInterp
end
function rayCast(Pos, Dir, Max, Ignore)
  return game:service("Workspace"):FindPartOnRay(Ray.new(Pos, Dir.unit * (Max or 999.999)), Ignore)
end
function Damagefunc(Part, hit, minim, maxim, knockback, Type, Property, Delay, KnockbackType, decreaseblock)
  if hit.Parent == nil then
    return
  end
  local h = hit.Parent:FindFirstChild("Humanoid")
  for _, v in pairs(hit.Parent:children()) do
    if v:IsA("Humanoid") then
      h = v
    end
  end
  if hit.Parent.Parent:FindFirstChild("Torso") ~= nil then
    h = hit.Parent.Parent:FindFirstChild("Humanoid")
  end
  if hit.Parent.className == "Hat" then
    hit = hit.Parent.Parent:findFirstChild("Head")
  end
  if h ~= nil and hit.Parent.Name ~= Character.Name and hit.Parent:FindFirstChild("Torso") ~= nil then
    if hit.Parent:findFirstChild("DebounceHit") ~= nil and hit.Parent.DebounceHit.Value == true then
      return
    end
    local c = Instance.new("ObjectValue")
    c.Name = "creator"
    c.Value = game:service("Players").LocalPlayer
    c.Parent = h
    game:GetService("Debris"):AddItem(c, 0.5)
    local Damage = math.random(minim, maxim)
    local blocked = false
    local block = hit.Parent:findFirstChild("Block")
    if block ~= nil then
      print(block.className)
      if block.className == "NumberValue" and block.Value > 0 then
        blocked = true
        if decreaseblock == nil then
          block.Value = block.Value - 1
        end
      end
      if block.className == "IntValue" and block.Value > 0 then
        blocked = true
        if decreaseblock ~= nil then
          block.Value = block.Value - 1
        end
      end
    end
    if blocked == false then
      h.Health = h.Health - Damage
      ShowDamage(Part.CFrame * CFrame.new(0, 0, Part.Size.Z / 2).p + Vector3.new(0, 1.5, 0), -Damage, 1.5, Part.BrickColor.Color)
    else
      h.Health = h.Health - Damage / 2
      ShowDamage(Part.CFrame * CFrame.new(0, 0, Part.Size.Z / 2).p + Vector3.new(0, 1.5, 0), -Damage, 1.5, BrickColor.new("White").Color)
    end
    if Type == "Knockdown" then
      local hum = hit.Parent.Humanoid
      hum.PlatformStand = true
      coroutine.resume(coroutine.create(function(HHumanoid)
        swait(1)
        HHumanoid.PlatformStand = false
      end), hum)
      local angle = hit.Position - (Property.Position + Vector3.new(0, 0, 0)).unit
      local bodvol = Instance.new("BodyVelocity")
      bodvol.velocity = angle * knockback
      bodvol.P = 5000
      bodvol.maxForce = Vector3.new(8000, 8000, 8000)
      bodvol.Parent = hit
      local rl = Instance.new("BodyAngularVelocity")
      rl.P = 3000
      rl.maxTorque = Vector3.new(500000, 500000, 500000) * 50000000000000
      rl.angularvelocity = Vector3.new(math.random(-10, 10), math.random(-10, 10), math.random(-10, 10))
      rl.Parent = hit
      game:GetService("Debris"):AddItem(bodvol, 0.5)
      game:GetService("Debris"):AddItem(rl, 0.5)
    elseif Type == "Normal" then
      local vp = Instance.new("BodyVelocity")
      vp.P = 500
      vp.maxForce = Vector3.new(math.huge, 0, math.huge)
      if KnockbackType == 1 then
        vp.velocity = Property.CFrame.lookVector * knockback + Property.Velocity / 1.05
      elseif KnockbackType == 2 then
        vp.velocity = Property.CFrame.lookVector * knockback
      end
      if knockback > 0 then
        vp.Parent = hit.Parent.Torso
      end
      game:GetService("Debris"):AddItem(vp, 0.5)
    elseif Type == "Up" then
      local bodyVelocity = Instance.new("BodyVelocity")
      bodyVelocity.velocity = vt(0, 60, 0)
      bodyVelocity.P = 5000
      bodyVelocity.maxForce = Vector3.new(8000, 8000, 8000)
      bodyVelocity.Parent = hit
      game:GetService("Debris"):AddItem(bodyVelocity, 1)
      local rl = Instance.new("BodyAngularVelocity")
      rl.P = 3000
      rl.maxTorque = Vector3.new(500000, 500000, 500000) * 50000000000000
      rl.angularvelocity = Vector3.new(math.random(-30, 30), math.random(-30, 30), math.random(-30, 30))
      rl.Parent = hit
      game:GetService("Debris"):AddItem(rl, 0.5)
    elseif Type == "Snare" then
      local bp = Instance.new("BodyPosition")
      bp.P = 2000
      bp.D = 100
      bp.maxForce = Vector3.new(math.huge, math.huge, math.huge)
      bp.position = hit.Parent.Torso.Position
      bp.Parent = hit.Parent.Torso
      game:GetService("Debris"):AddItem(bp, 1)
    elseif Type == "Target" then
      local Targetting = false
      if Targetting == false then
        ZTarget = hit.Parent.Torso
        coroutine.resume(coroutine.create(function(Part)
          so("http://www.roblox.com/asset/?id=15666462", Part, 1, 1.5)
          swait(5)
          so("http://www.roblox.com/asset/?id=15666462", Part, 1, 1.5)
        end), ZTarget)
        local TargHum = ZTarget.Parent:findFirstChild("Humanoid")
        local targetgui = Instance.new("BillboardGui")
        targetgui.Parent = ZTarget
        targetgui.Size = UDim2.new(10, 100, 10, 100)
        local targ = Instance.new("ImageLabel")
        targ.Parent = targetgui
        targ.BackgroundTransparency = 1
        targ.Image = "rbxassetid://4834067"
        targ.Size = UDim2.new(1, 0, 1, 0)
        cam.CameraType = "Scriptable"
        cam.CoordinateFrame = CFrame.new(Head.CFrame.p, ZTarget.Position)
        local dir = Vector3.new(cam.CoordinateFrame.lookVector.x, 0, cam.CoordinateFrame.lookVector.z)
        workspace.CurrentCamera.CoordinateFrame = CFrame.new(Head.CFrame.p, ZTarget.Position)
        Targetting = true
        RocketTarget = ZTarget
        for i = 1, Property do
          if 0 < Humanoid.Health and Character.Parent ~= nil and 0 < TargHum.Health and TargHum.Parent ~= nil and Targetting == true then
            swait()
          end
          cam.CoordinateFrame = CFrame.new(Head.CFrame.p, ZTarget.Position)
          dir = Vector3.new(cam.CoordinateFrame.lookVector.x, 0, cam.CoordinateFrame.lookVector.z)
          cam.CoordinateFrame = CFrame.new(Head.CFrame.p, ZTarget.Position) * cf(0, 5, 10) * euler(-0.3, 0, 0)
        end
        Targetting = false
        RocketTarget = nil
        targetgui.Parent = nil
        cam.CameraType = "Custom"
      end
    end
    local debounce = Instance.new("BoolValue")
    debounce.Name = "DebounceHit"
    debounce.Parent = hit.Parent
    debounce.Value = true
    game:GetService("Debris"):AddItem(debounce, Delay)
    c = Instance.new("ObjectValue")
    c.Name = "creator"
    c.Value = Player
    c.Parent = h
    game:GetService("Debris"):AddItem(c, 0.5)
  end
end
function ShowDamage(Pos, Text, Time, Color)
  local Rate = 0.03333333333333333
  local Pos = Pos or Vector3.new(0, 0, 0)
  local Text = Text or ""
  local Time = Time or 2
  local Color = Color or Color3.new(1, 0, 0)
  local EffectPart = part("Custom", workspace, "Neon", 0, 1, BrickColor.new(Color), "Effect", vt(0, 0, 0))
  EffectPart.Anchored = true
  local BillboardGui = Instance.new("BillboardGui")
  BillboardGui.Size = UDim2.new(3, 0, 3, 0)
  BillboardGui.Adornee = EffectPart
  local TextLabel = Instance.new("TextLabel")
  TextLabel.BackgroundTransparency = 1
  TextLabel.Size = UDim2.new(1, 0, 1, 0)
  TextLabel.Text = Text
  TextLabel.TextColor3 = Color
  TextLabel.TextScaled = true
  TextLabel.Font = Enum.Font.ArialBold
  TextLabel.Parent = BillboardGui
  BillboardGui.Parent = EffectPart
  game.Debris:AddItem(EffectPart, Time + 0.1)
  EffectPart.Parent = game:GetService("Workspace")
  Delay(0, function()
    local Frames = Time / Rate
    for Frame = 1, Frames do
      wait(Rate)
      local Percent = Frame / Frames
      EffectPart.CFrame = CFrame.new(Pos) + Vector3.new(0, Percent, 0)
      TextLabel.TextTransparency = Percent
    end
    if EffectPart and EffectPart.Parent then
      EffectPart:Destroy()
    end
  end)
end
R = ""
L = ""
handle = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Handle", Vector3.new(0.34799999, 2.78399992, 0.34799999))
handleweld = weld(m, Character["Right Arm"], handle, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-1.00324273, 0.013961792, -0.00828075409, -1.38366803E-13, -0.999999881, 4.25688995E-9, 2.4656245E-7, -4.25688951E-9, -1, 1, -1.373172E-13, 2.4656245E-7))
mesh("CylinderMesh", handle, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 1, 1))
Hitbox = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0.5, 1, VertexRainbow(), "Hitbox", Vector3.new(1.04400003, 6.35600042, 0.600000024))
Hitboxweld = weld(m, handle, Hitbox, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-3.08990479E-4, -5.48094559, -2.00271606E-5, 1, 6.10120843E-11, -1.08637464E-14, -6.10120843E-11, 1, 7.57154339E-11, 1.08637574E-14, -7.57154339E-11, 1))
mesh("BlockMesh", Hitbox, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 1, 0.579999983))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.34799996, 0.34799999, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, -0.00242900848, 2.16260338, 1.38366803E-13, -2.4656245E-7, -1, -0.999999702, -4.25688862E-9, -1.37317173E-13, -4.25688862E-9, 0.999999702, -2.46562365E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.0649600029, 0.266800046, 0.495319903))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.34799996, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, -1.90548706, -0.270383835, 1.38366803E-13, -2.4656245E-7, -1, -0.707106292, 0.707106471, -1.74345999E-7, 0.707106471, 0.707106292, -1.74345757E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.226199999, 0.379320025, 1.68895996))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Metal, 0, 0, "Really black", "Part", Vector3.new(0.200000003, 0.34799999, 0.812000036))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(4.84466553E-4, -0.232157588, -1.08489037, -1.6391111E-7, -2.91180186E-7, -0.999989986, -0.999989986, 2.34624395E-7, 1.63911025E-7, 2.34622007E-7, 1, -2.91177315E-7))
mesh("SpecialMesh", Part, Enum.MeshType.Wedge, "", Vector3.new(0, 0, 0), Vector3.new(0.628719985, 1, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.34799996, 0.34799999, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, 1.1207962, -1.77352905, -1.94793994E-8, -1.96046472E-7, -1, 0.707106471, 0.707106292, -1.52399679E-7, 0.707106292, -0.707106471, 1.24851695E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.0522000007, 0.293480009, 0.495319903))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.200000003, 0.812000036, 0.591600001))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-1.44004822E-4, -7.46494102, -8.79764557E-5, 4.47029542E-8, 2.42425131E-7, 0.999980867, -2.50834205E-7, 1, -2.42420526E-7, -0.999980867, -2.5083898E-7, 4.47030146E-8))
mesh("SpecialMesh", Part, Enum.MeshType.Wedge, "", Vector3.new(0, 0, 0), Vector3.new(0.628719985, 1, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.231999978, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.0605430603, -4.62282181, 0.00242900848, 1.38366803E-13, -2.4656245E-7, -1, -4.25688995E-9, 1, -2.4656245E-7, 1, 4.25688995E-9, 1.37317214E-13))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.190239996, 0.25752002, 0.723839939))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.34799996, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, -1.90548706, -0.270383835, 1.38366803E-13, -2.4656245E-7, -1, -0.707106292, 0.707106471, -1.74345999E-7, 0.707106471, 0.707106292, -1.74345757E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.187919989, 0.477920026, 1.68895996))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.200000003, 0.34799999, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.232713461, -1.89698601, 1.04904175E-4, 0.999990463, 6.10373974E-11, -1.79689993E-14, -6.10378414E-11, 1, 7.57154339E-11, 1.79689976E-14, -7.57438556E-11, 0.999990463))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.579999983, 1, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.231999993, 0.200000003, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.174778461, -1.66498375, 9.53674316E-6, 1, -2.34479103E-12, -1.42102626E-14, 2.34479103E-12, 1, -2.89901436E-12, 2.04982668E-14, 2.89901436E-12, 1))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 0.580000103, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0.5, 0, "White", "Part", Vector3.new(1.04400003, 4.75600052, 0.200000003))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-2.87055969E-4, -4.68094635, -3.14712524E-5, 0.999985695, 6.10369533E-11, -1.79689095E-14, -6.10378414E-11, 1, 7.57154339E-11, 1.79689129E-14, -7.57438556E-11, 0.999985695))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 1, 0.579999983))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.231999978, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.055480957, 0.00242888927, 4.62282181, 1.38366803E-13, -2.4656245E-7, -1, 0.999999881, 1.91580511E-8, 1.33643137E-13, 1.91580511E-8, -0.999999881, 2.46562422E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.230839998, 0.200680032, 2.79675961))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.579999983, 0.812000036, 0.200000003))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(1.58329582, -0.00271689892, 0.00253105164, -7.87626959E-8, 0.999999642, -2.45072926E-7, -0.999999464, 8.51500772E-8, -4.54507015E-10, 1.08588507E-8, 2.02850984E-7, 0.999999642))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/asset/?id=3270017", Vector3.new(0, 0, 0), Vector3.new(0.798079908, 0.843320072, 0.58927989))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.34799996, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, 1.91083908, -0.265031815, 1.38366803E-13, -2.4656245E-7, -1, -0.70710659, -0.707106471, 1.743458E-7, -0.707106471, 0.70710659, -1.74346027E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.187919989, 0.477920026, 1.68895996))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.34799996, 0.34799999, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, -1.11735535, -1.77697182, 5.58765407E-8, -2.23627353E-7, -1, 0.707106352, -0.707106411, 1.97639011E-7, -0.707106411, -0.707106352, 1.18617642E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.0649600029, 0.266800046, 0.495319903))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.34799996, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, -1.21653748, 2.8604393, 1.38366803E-13, -2.4656245E-7, -1, 0.707106769, 0.707106709, -1.74345857E-7, 0.707106709, -0.707106769, 1.74346084E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.214599997, 0.428039998, 1.68895996))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.34799996, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, 1.91083908, -0.265031815, 1.38366803E-13, -2.4656245E-7, -1, -0.70710659, -0.707106471, 1.743458E-7, -0.707106471, 0.70710659, -1.74346027E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.214599997, 0.428039998, 1.68895996))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.44659999, 0.200000003, 0.371199995))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.00553905964, -0.620464325, 0.00238800049, 0.999994755, 4.21545732E-9, 1.69303116E-13, -4.2154511E-9, 1, -2.46550314E-7, -1.77448632E-13, 2.46551593E-7, 0.999994755))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 0.579999983, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.34799996, 0.34799999, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, 1.12079048, -0.461172104, -1.20904753E-8, -2.04617493E-7, -1, 0.70710665, 0.70710659, -1.53235618E-7, 0.70710659, -0.70710665, 1.36137132E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.0522000007, 0.293480009, 0.495319903))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.812000036, 0.200000003, 0.579999983))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-1.58329773, -0.00251197815, 0.00270497799, 4.25687707E-9, -1, 2.46565747E-7, 1.65165096E-13, -2.46565747E-7, -1, 1, 4.25687707E-9, 1.64115493E-13))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 0.526639998, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.200000003, 0.812000036, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.294445038, 1.4429245, 0.00253105164, 0.965925753, -0.258819014, 6.3815186E-8, 0.258819014, 0.965925753, -2.38160979E-7, -1.38366803E-13, 2.4656245E-7, 1))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.579999983, 1, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.34799996, 0.34799999, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, 1.12079048, -0.461172104, -1.20904753E-8, -2.04617493E-7, -1, 0.70710665, 0.70710659, -1.53235618E-7, 0.70710659, -0.70710665, 1.36137132E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.0649600029, 0.266800046, 0.495319903))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.231999978, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.0605430603, -4.62282181, 0.00242900848, 1.38366803E-13, -2.4656245E-7, -1, -4.25688995E-9, 1, -2.4656245E-7, 1, 4.25688995E-9, 1.37317214E-13))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.229680017, 0.249400035, 0.650759876))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.34799996, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, -1.90548706, -0.270383835, 1.38366803E-13, -2.4656245E-7, -1, -0.707106292, 0.707106471, -1.74345999E-7, 0.707106471, 0.707106292, -1.74345757E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.214599997, 0.428039998, 1.68895996))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(1.04400003, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(2.28609848, -1.26961899, 0.00253105164, 0.707106709, -0.707106769, 1.74346084E-7, 0.707106769, 0.707106709, -1.74345857E-7, -1.38366803E-13, 2.4656245E-7, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.34799996, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, -1.21653748, 2.8604393, 1.38366803E-13, -2.4656245E-7, -1, 0.707106769, 0.707106709, -1.74345857E-7, 0.707106709, -0.707106769, 1.74346084E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.187919989, 0.477920026, 1.68895996))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.34799996, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, 1.21997452, 2.85700226, 1.38366803E-13, -2.4656245E-7, -1, 0.70710659, -0.70710665, 1.74346042E-7, -0.70710665, -0.70710659, 1.74345828E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.214599997, 0.428039998, 1.68895996))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.34799996, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, -2.18717003, 1.162413, 1.38366803E-13, -2.4656245E-7, -1, -4.25688995E-9, 1, -2.4656245E-7, 1, 4.25688995E-9, 1.37317214E-13))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.187919989, 0.477920026, 1.68895996))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.34799996, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, -2.18717003, 1.162413, 1.38366803E-13, -2.4656245E-7, -1, -4.25688995E-9, 1, -2.4656245E-7, 1, 4.25688995E-9, 1.37317214E-13))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.214599997, 0.428039998, 1.68895996))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.34799996, 0.34799999, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, -1.11734962, -0.464616776, 4.62869565E-8, -2.3199955E-7, -1, 0.707106471, -0.70710659, 1.96778231E-7, -0.70710659, -0.707106471, 1.31318558E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.0649600029, 0.266800046, 0.495319903))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.579999983, 0.200000003, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-6.06894493E-4, -1.54850197, -4.76837158E-6, 1, -2.34479103E-12, -1.42102626E-14, 2.34479103E-12, 1, -2.89901436E-12, 2.04982668E-14, 2.89901436E-12, 1))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 0.579999983, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.34799996, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, -2.18717003, -1.15753412, 1.38366803E-13, -2.4656245E-7, -1, -4.25688995E-9, 1, -2.4656245E-7, 1, 4.25688995E-9, 1.37317214E-13))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.214599997, 0.428039998, 1.68895996))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.200000003, 0.34799999, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.23126626, -1.89697075, 1.04904175E-4, 0.999990463, 6.10373974E-11, -1.79689993E-14, -6.10378414E-11, 1, 7.57154339E-11, 1.79689976E-14, -7.57438556E-11, 0.999990463))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.580000222, 1, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(1.04400003, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.859739304, -1.87621498, 0.00253105164, 0.70710659, 0.70710659, -1.74345828E-7, -0.70710659, 0.70710659, -1.74346027E-7, -1.38366803E-13, 2.4656245E-7, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.200000003, 0.34799999, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-1.58202362, 0.00305497646, 0.00253105164, 1.91577065E-8, -1, 2.46562593E-7, 0.999994159, 1.91577474E-8, -8.742213E-8, 4.37109904E-8, 2.46561086E-7, 0.999994159))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.579999983, 1, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.34799996, 0.34799999, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, 1.58260727, -0.577546716, 1.38366803E-13, -2.4656245E-7, -1, -3.40592123E-8, 0.999999821, -2.46562394E-7, 0.999999821, 3.40592123E-8, 1.29969047E-13))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.0522000007, 0.293480009, 0.495319903))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.44659999, 0.69599998, 0.371199995))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.00555098057, -1.02645874, 0.00238800049, 0.999994278, 4.2154551E-9, 1.69303035E-13, -4.21544888E-9, 0.999999523, -2.46550201E-7, -1.77448632E-13, 2.46551593E-7, 0.999994755))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 1, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.34799996, 0.34799999, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, -0.0024292469, 2.16260338, 1.38366803E-13, -2.4656245E-7, -1, -0.999999702, -6.38615347E-8, -1.22620908E-13, -6.38615347E-8, 0.999999702, -2.46562365E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.0522000007, 0.293480009, 0.495319903))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.200000003, 0.463999987, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-6.50644302E-4, -1.8385067, 1.04904175E-4, 0.999990463, 6.10373974E-11, -1.79689993E-14, -6.10378414E-11, 1, 7.57154339E-11, 1.79689976E-14, -7.57438556E-11, 0.999990463))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.579999983, 1, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.200000003, 4.75600052, 0.200000003))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(1.56164169E-4, -4.68094444, -2.74658203E-4, 0.999971211, 5.13775689E-11, -1.44165397E-14, -5.13864507E-11, 1, 6.64499566E-11, 8.34828473E-15, -6.64783784E-11, 0.999971211))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.580000401, 1, 0.69599992))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.34799996, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, 1.21997452, 2.85700226, 1.38366803E-13, -2.4656245E-7, -1, 0.70710659, -0.70710665, 1.74346042E-7, -0.70710665, -0.70710659, 1.74345828E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.226199999, 0.379320025, 1.68895996))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.231999978, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.0605430603, 0.00242888927, 4.62282181, 1.38366803E-13, -2.4656245E-7, -1, 0.999999881, 1.91580511E-8, 1.33643137E-13, 1.91580511E-8, -0.999999881, 2.46562422E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.230839998, 0.200680032, 2.79675961))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.34799996, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, -2.18717003, -1.15753412, 1.38366803E-13, -2.4656245E-7, -1, -4.25688995E-9, 1, -2.4656245E-7, 1, 4.25688995E-9, 1.37317214E-13))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.226199999, 0.379320025, 1.68895996))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.34799996, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, -2.18717003, -1.15753412, 1.38366803E-13, -2.4656245E-7, -1, -4.25688995E-9, 1, -2.4656245E-7, 1, 4.25688995E-9, 1.37317214E-13))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.187919989, 0.477920026, 1.68895996))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.200000003, 0.231999993, 0.200000003))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-2.68936157E-4, -7.1749382, -1.66773796E-4, -2.98020346E-8, 2.42384317E-7, 0.999980867, -2.50883971E-7, 1, -2.42379713E-7, -0.999980867, -2.50888746E-7, -2.98019742E-8))
mesh("SpecialMesh", Part, Enum.MeshType.Wedge, "", Vector3.new(0, 0, 0), Vector3.new(0.698320508, 1.00999999, 0.590207934))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.44659999, 1.15999997, 0.371199995))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.00572288036, 0.249307632, 0.00253105164, 0.999997973, 4.25688151E-9, 1.37316929E-13, -4.25688196E-9, 0.999998093, -2.46561967E-7, -1.38366789E-13, 2.46562422E-7, 0.999999881))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 1, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.44659999, 0.200000003, 0.371199995))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.00575697422, 1.22929001, 0.00253105164, 1, 4.25689928E-9, 1.49599246E-13, -4.25689928E-9, 1, -2.46565691E-7, -1.50648848E-13, 2.46565691E-7, 1))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 0.579999983, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.34799996, 0.34799999, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, -1.11734962, -0.464616776, 4.62869565E-8, -2.3199955E-7, -1, 0.707106471, -0.70710659, 1.96778231E-7, -0.70710659, -0.707106471, 1.31318558E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.0522000007, 0.293480009, 0.495319903))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.200000003, 0.579999983, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.347447634, -1.78050041, 1.02043152E-4, 0.999989986, 6.10373974E-11, -1.79689739E-14, -6.10378414E-11, 1, 7.57154339E-11, 1.79689976E-14, -7.57438556E-11, 0.999989986))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.579999983, 1, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.34799996, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, -1.21653748, 2.8604393, 1.38366803E-13, -2.4656245E-7, -1, 0.707106769, 0.707106709, -1.74345857E-7, 0.707106709, -0.707106769, 1.74346084E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.226199999, 0.379320025, 1.68895996))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.231999978, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.055480957, -4.62282181, 0.00242900848, 1.38366803E-13, -2.4656245E-7, -1, -4.25688995E-9, 1, -2.4656245E-7, 1, 4.25688995E-9, 1.37317214E-13))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.229680017, 0.249400035, 0.650759876))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.696000099, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.872640967, -2.18717003, 0.00248718262, 1, 4.25688995E-9, 1.37317214E-13, -4.25688995E-9, 1, -2.4656245E-7, -1.38366803E-13, 2.4656245E-7, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.34799996, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, 1.91083908, -0.265031815, 1.38366803E-13, -2.4656245E-7, -1, -0.70710659, -0.707106471, 1.743458E-7, -0.707106471, 0.70710659, -1.74346027E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.226199999, 0.379320025, 1.68895996))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.34799996, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, -2.18717003, 1.162413, 1.38366803E-13, -2.4656245E-7, -1, -4.25688995E-9, 1, -2.4656245E-7, 1, 4.25688995E-9, 1.37317214E-13))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.226199999, 0.379320025, 1.68895996))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0.5, 0, "White", "Part", Vector3.new(0.200000003, 1.50800002, 1.04400003))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-5.53131104E-5, -7.8129406, 1.8453598E-4, 4.47029258E-8, 2.42408902E-7, 0.999980867, -2.50858221E-7, 1, -2.42404298E-7, -0.999980867, -2.50863025E-7, 4.47029933E-8))
mesh("SpecialMesh", Part, Enum.MeshType.Wedge, "", Vector3.new(0, 0, 0), Vector3.new(0.581159949, 1, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(1.04400003, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-6.66975975E-4, -2.18694496, 1.04904175E-4, 0.999990463, 6.10373974E-11, -1.79689993E-14, -6.10378414E-11, 1, 7.57154339E-11, 1.79689976E-14, -7.57438556E-11, 0.999990463))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.34799996, 0.34799999, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, -1.11735535, -1.77697182, 5.58765407E-8, -2.23627353E-7, -1, 0.707106352, -0.707106411, 1.97639011E-7, -0.707106411, -0.707106352, 1.18617642E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.0522000007, 0.293480009, 0.495319903))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.231999993, 0.200000003, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.173270226, -1.66498375, 1.039505E-4, 0.999997854, 6.10373974E-11, -1.7969128E-14, -6.10378414E-11, 1, 7.57154339E-11, 1.79691145E-14, -7.57154339E-11, 0.999997854))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 0.580000103, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.34799996, 0.34799999, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, 1.58260727, 0.582428694, -3.71006301E-8, -2.2971102E-7, -1, 2.55454324E-8, 0.999999821, -2.29710963E-7, 0.999999821, -2.55454431E-8, -3.71006159E-8))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.0522000007, 0.293480009, 0.495319903))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(1.04400003, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.863862991, -1.87209129, 0.00253105164, 0.70710659, -0.70710659, 1.74346027E-7, 0.70710659, 0.70710659, -1.74345828E-7, -1.38366803E-13, 2.4656245E-7, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.34799996, 0.34799999, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, 1.58260727, -0.577546716, 1.38366803E-13, -2.4656245E-7, -1, -3.40592123E-8, 0.999999821, -2.46562394E-7, 0.999999821, 3.40592123E-8, 1.29969047E-13))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.0649600029, 0.266800046, 0.495319903))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.34799996, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, 1.21997452, 2.85700226, 1.38366803E-13, -2.4656245E-7, -1, 0.70710659, -0.70710665, 1.74346042E-7, -0.70710665, -0.70710659, 1.74345828E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.187919989, 0.477920026, 1.68895996))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.580000043, 4.75600052, 0.200000003))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-1.963377E-4, -4.68094635, -9.53674316E-5, 0.999990404, 6.10373974E-11, -1.79689874E-14, -6.10378414E-11, 1, 7.57154339E-11, 1.79689976E-14, -7.57154339E-11, 0.999990404))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 1, 0.638000011))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(1.04400003, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-2.28197098, -1.27374649, 0.00253105164, 0.707106709, 0.707106769, -1.74345885E-7, -0.707106769, 0.707106709, -1.74346056E-7, -1.38366803E-13, 2.4656245E-7, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.200000003, 0.34799999, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.116648793, -1.89650726, 1.04904175E-4, 0.999990463, 6.10373974E-11, -1.79689993E-14, -6.10378414E-11, 1, 7.57154339E-11, 1.79689976E-14, -7.57438556E-11, 0.999990463))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.579999983, 1, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.34799996, 0.34799999, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, 1.58260727, 0.582428694, -3.71006301E-8, -2.2971102E-7, -1, 2.55454324E-8, 0.999999821, -2.29710963E-7, 0.999999821, -2.55454431E-8, -3.71006159E-8))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.0649600029, 0.266800046, 0.495319903))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.44659999, 0.200000003, 0.371199995))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.00563848019, -0.388711929, 0.00253295898, 0.99999404, 4.25686464E-9, 1.37316401E-13, -4.25686508E-9, 0.999994159, -2.46561001E-7, -1.38366789E-13, 2.46562422E-7, 0.999999881))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 0.579999983, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.34799999, 0.34799999, 0.200000003))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(1.58329582, -0.00271689892, 0.00253105164, -7.87626959E-8, 0.999999642, -2.45072926E-7, -0.999999464, 8.51500772E-8, -4.54507015E-10, 1.08588507E-8, 2.02850984E-7, 0.999999642))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/asset/?id=3270017", Vector3.new(0, 0, 0), Vector3.new(0.579999983, 0.595080018, 0.683239937))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.231999978, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.0605430603, 0.00242888927, 4.62282181, 1.38366803E-13, -2.4656245E-7, -1, 0.999999881, 1.91580511E-8, 1.33643137E-13, 1.91580511E-8, -0.999999881, 2.46562422E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.190239996, 0.25752002, 2.79675961))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.200000003, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.347726822, -1.60689163, -9.05990601E-5, 0.99999994, 6.59379218E-11, -1.80878482E-14, -6.59667876E-11, 1, -5.95150595E-11, 2.41627922E-14, 5.94866378E-11, 0.99999994))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.580000103, 1, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.34799996, 0.34799999, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00253105164, 1.1207962, -1.77352905, -1.94793994E-8, -1.96046472E-7, -1, 0.707106471, 0.707106292, -1.52399679E-7, 0.707106292, -0.707106471, 1.24851695E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.0649600029, 0.266800046, 0.495319903))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.696000099, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.870689273, -2.18681908, 1.04904175E-4, 0.999990463, 6.10373974E-11, -1.79689993E-14, -6.10378414E-11, 1, 7.57154339E-11, 1.79689976E-14, -7.57438556E-11, 0.999990463))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Metal, 0, 0, "Really black", "Part", Vector3.new(0.200000003, 0.34799999, 0.812000036))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-4.25338745E-4, -0.231835961, -1.08489037, -4.08055101E-9, 2.02203083E-7, 0.99999994, 0.99999994, 2.42933169E-7, 4.08050749E-9, -2.42933169E-7, 1, -2.02203097E-7))
mesh("SpecialMesh", Part, Enum.MeshType.Wedge, "", Vector3.new(0, 0, 0), Vector3.new(0.628719985, 1, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.812000036, 0.200000003, 0.812000036))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-1.58329773, -0.00251197815, 0.00270497799, 4.25687707E-9, -1, 2.46565747E-7, 1.65165096E-13, -2.46565747E-7, -1, 1, 4.25687707E-9, 1.64115493E-13))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 0.444280028, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.231999978, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.055480957, -4.62282181, 0.00242900848, 1.38366803E-13, -2.4656245E-7, -1, -4.25688995E-9, 1, -2.4656245E-7, 1, 4.25688995E-9, 1.37317214E-13))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.190239996, 0.25752002, 0.723839939))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.44659999, 0.200000003, 0.371199995))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.00563395023, 0.887273788, 0.00253295898, 0.999990106, 4.25684776E-9, 1.37315859E-13, -4.25684821E-9, 0.999990225, -2.46560035E-7, -1.38366789E-13, 2.46562422E-7, 0.999999881))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 0.579999983, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.200000003, 0.34799999, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.348541379, -1.89650154, 1.04904175E-4, 0.999990463, 6.10373974E-11, -1.79689993E-14, -6.10378414E-11, 1, 7.57154339E-11, 1.79689976E-14, -7.57438556E-11, 0.999990463))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.579999983, 1, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.579999983, 0.812000036, 0.200000003))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(1.58329582, -0.00271689892, 0.00253105164, -7.87626959E-8, 0.999999642, -2.45072926E-7, -0.999999464, 8.51500772E-8, -4.54507015E-10, 1.08588507E-8, 2.02850984E-7, 0.999999642))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/asset/?id=3270017", Vector3.new(0, 0, 0), Vector3.new(0.835199952, 0.808520079, 0.58927989))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.44659999, 0.200000003, 0.371199995))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.00555217266, -1.43245697, 0.00238800049, 0.999993682, 4.21545243E-9, 1.69302926E-13, -4.21544666E-9, 0.999998927, -2.46550059E-7, -1.77448618E-13, 2.46551593E-7, 0.999994755))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 0.579999983, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.200000003, 0.34799999, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.115347862, -1.89650726, 1.04904175E-4, 0.999990463, 6.10373974E-11, -1.79689993E-14, -6.10378414E-11, 1, 7.57154339E-11, 1.79689976E-14, -7.57438556E-11, 0.999990463))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.579999983, 1, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.231999978, 0.231999993, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.055480957, 0.00242888927, 4.62282181, 1.38366803E-13, -2.4656245E-7, -1, 0.999999881, 1.91580511E-8, 1.33643137E-13, 1.91580511E-8, -0.999999881, 2.46562422E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/Asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.190239996, 0.25752002, 2.79675961))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, VertexRainbow(), "Part", Vector3.new(0.200000003, 0.812000036, 0.34799999))
Partweld = weld(m, handle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.300365448, 1.44133759, 0.00253105164, 0.965925753, 0.258819014, -6.3814916E-8, -0.258819014, 0.965925753, -2.38161064E-7, -1.38366803E-13, 2.4656245E-7, 1))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.579999983, 1, 1))
HandleB = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "HandleB", Vector3.new(0.6209023, 0.354801297, 0.263675183))
HandleBweld = weld(m, Character["Left Arm"], HandleB, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.712272644, -0.658613205, 0.044960022, 0, -0.499999821, -0.86602509, 0, -0.866024971, 0.499999881, -1, 0, 0))
BarrelB = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "BarrelB", Vector3.new(0.266101122, 0.263675213, 0.354801387))
BarrelBweld = weld(m, HandleB, BarrelB, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.65196991, -3.61154366, 0, 0.866024852, -0.499999672, 0, 0.499999672, 0.866024852, 0, 0, 0, 1))
mesh("CylinderMesh", BarrelB, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 0.336399972, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.798303008, 0.532201946, 0.709602773))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.47013092, -1.24765587, -4.57763672E-5, 0.866024852, -0.499999672, 0, 0.499999672, 0.866024852, 0, 0, 0, 1))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 1, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.443501562, 0.263675213, 0.6209023))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.115322113, 0, 0.316355348, 0.866025031, -0.499999583, 0, 0, 0, 1, -0.499999583, -0.866025031, 0))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 0.672799945, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Medium stone grey", "Part", Vector3.new(0.354801446, 0.270536005, 0.354801387))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.651966095, -3.5117569, 0, 0.866024852, -0.499999672, 0, 0.499999672, 0.866024852, 0, 0, 0, 1))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 1, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.263675183, 0.263675213, 0.798303008))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.647537231, 0.228363037, -0.582419634, -0.866024315, 0.499999404, 0, 0, 0, 0.999999642, 0.499999553, 0.866024554, 0))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.336399972, 0.353219956, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.44350177, 1.86270726, 0.532202065))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.647533417, -2.71123719, 0, 0.866024852, -0.499999672, 0, 0.499999672, 0.866024852, 0, 0, 0, 1))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 1, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.6209023, 0.263675213, 0.798303008))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.47013092, 0.223937988, -0.582418919, -0.866024315, 0.499999404, 0, 0, 0, 0.999999642, 0.499999553, 0.866024554, 0))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 0.353219956, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.798303008, 0.263675213, 0.798303008))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.47013092, 0.221725464, -0.582418919, -0.866024315, 0.499999404, 0, 0, 0, 0.999999642, 0.499999553, 0.866024554, 0))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 0.336399972, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.263675183, 0.263675213, 0.798303008))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.470134735, 0.228363037, -0.405021667, -0.866024315, 0.499999404, 0, 0, 0, 0.999999642, 0.499999553, 0.866024554, 0))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.336399972, 0.353219956, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.263675183, 0.263675213, 0.798303008))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.470134735, 0.228363037, -0.759824157, -0.866024315, 0.499999404, 0, 0, 0, 0.999999642, 0.499999553, 0.866024554, 0))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.336399972, 0.353219956, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.6209023, 0.263675213, 0.798303008))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.47013092, 0.223937988, -0.582418919, -0.866024315, 0.499999404, 0, 0, 0, 0.999999642, 0.499999553, 0.866024554, 0))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 0.353219956, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.263675183, 0.263675213, 0.798303008))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.292743683, 0.228363037, -0.582422733, -0.866024315, 0.499999404, 0, 0, 0, 0.999999642, 0.499999553, 0.866024554, 0))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.336399972, 0.353219956, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.798303008, 0.263675213, 0.798303008))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.47013092, -0.22177124, -0.582418919, -0.866024315, 0.499999404, 0, 0, 0, 0.999999642, 0.499999553, 0.866024554, 0))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 0.336399972, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.263675183, 0.263675213, 0.798303008))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.470134735, -0.228408813, -0.405021667, -0.866024315, 0.499999404, 0, 0, 0, 0.999999642, 0.499999553, 0.866024554, 0))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.336399972, 0.353219956, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.263675183, 0.263675213, 0.798303008))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.647537231, -0.228408813, -0.582419634, -0.866024315, 0.499999404, 0, 0, 0, 0.999999642, 0.499999553, 0.866024554, 0))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.336399972, 0.353219956, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.263675183, 0.263675213, 0.798303008))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.292743683, -0.228408813, -0.582422733, -0.866024315, 0.499999404, 0, 0, 0, 0.999999642, 0.499999553, 0.866024554, 0))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.336399972, 0.353219956, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.6209023, 0.263675213, 0.798303008))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.47013092, -0.223960876, -0.582418919, -0.866024315, 0.499999404, 0, 0, 0, 0.999999642, 0.499999553, 0.866024554, 0))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 0.353219956, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.263675183, 0.263675213, 0.798303008))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.470134735, -0.228408813, -0.759824157, -0.866024315, 0.499999404, 0, 0, 0, 0.999999642, 0.499999553, 0.866024554, 0))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.336399972, 0.353219956, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.6209023, 0.263675213, 0.263675183))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00384521484, 0.00221633911, 0, 0.999999344, 0, 0, 0, 0.999999344, 0, 0, 0, 1))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 0.672799945, 0.70644027))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.263675183, 0.266100973, 0.263675183))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.957988739, -0.493718386, -0.133056641, 0.866024852, -0.499999672, 0, 0.499999672, 0.866024852, 0, 0, 0, 1))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.672799945, 1, 0.336399972))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.6209023, 0.263675213, 0.354801387))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.470127106, -0.094623208, 0, 0.866024852, -0.499999672, 0, 0.499999672, 0.866024852, 0, 0, 0, 1))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 0.672799945, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.263675183, 0.798303008, 0.354801387))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.824935913, -0.582421541, 0, 0.866024852, -0.499999672, 0, 0.499999672, 0.866024852, 0, 0, 0, 1))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.336399972, 1, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.263675183, 0.798303068, 0.263675183))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.913650513, -0.582422614, 0, 0.866024852, -0.499999672, 0, 0.499999672, 0.866024852, 0, 0, 0, 1))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.336399972, 1, 0.672800243))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.263675183, 0.266100973, 0.263675183))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.957988739, -0.493718386, 0.133049011, 0.866024852, -0.499999672, 0, 0.499999672, 0.866024852, 0, 0, 0, 1))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.672799945, 1, 0.336399972))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.354801267, 0.263675213, 0.354801387))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.306606293, 0, -0.00222206116, 0.999999583, 1.1920929E-7, 0, 0, 0, 1, 1.1920929E-7, -0.999999583, 0))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 0.672799945, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.354801267, 0.266100973, 0.363671392))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.514480591, -0.138983727, 0, 0.866024852, -0.499999672, 0, 0.499999672, 0.866024852, 0, 0, 0, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.263675183, 1.86270726, 0.263675183))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.869281769, -2.71124148, 0, 0.866024852, -0.499999672, 0, 0.499999672, 0.866024852, 0, 0, 0, 1))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.672800481, 1, 0.672800243))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.354801297, 0.263675213, 0.263675183))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.306606293, 0, -0.00222206116, 0.999999583, 1.1920929E-7, 0, 0, 0, 1, 1.1920929E-7, -0.999999583, 0))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 0.706439912, 0.672800243))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.263675183, 1.86270726, 0.263675183))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.425792694, -2.71124005, 0, 0.866024852, -0.499999672, 0, 0.499999672, 0.866024852, 0, 0, 0, 1))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.672800481, 1, 0.672800243))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.354801446, 0.443501711, 0.263675183))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.159671783, -3.33218336, 0, 0.866024852, -0.499999672, 0, 0.499999672, 0.866024852, 0, 0, 0, 1))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 1, 0.672800243))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.263675183, 0.266101062, 0.263675183))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-1.00234604, -3.33218288, 0, 0.866024852, -0.499999672, 0, 0.499999672, 0.866024852, 0, 0, 0, 1))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.336399972, 1, 0.672800243))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.354801446, 1.33050513, 0.263675183))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.337085724, -2.44513679, 0, 0.866024852, -0.499999672, 0, 0.499999672, 0.866024852, 0, 0, 0, 1))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 1, 0.672800243))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.798303068, 0.263675213, 0.354801387))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.47013092, -1.55811501, 0, 0.866024852, -0.499999672, 0, 0.499999672, 0.866024852, 0, 0, 0, 1))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 0.336399972, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.263675183, 0.532201946, 0.354801387))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.824932098, -1.24765778, 0, 0.866024852, -0.499999672, 0, 0.499999672, 0.866024852, 0, 0, 0, 1))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.336399972, 1, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.6209023, 0.798303008, 0.354801387))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.470127106, -0.582418799, 0, 0.866024852, -0.499999672, 0, 0.499999672, 0.866024852, 0, 0, 0, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.263675183, 0.798303068, 0.263675183))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.913650513, -1.38070595, 0, 0.866024852, -0.499999672, 0, 0.499999672, 0.866024852, 0, 0, 0, 1))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.336399972, 1, 0.672800243))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.532202065, 0.263675213, 0.354801387))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.603176117, -1.69116795, 0, 0.866024852, -0.499999672, 0, 0.499999672, 0.866024852, 0, 0, 0, 1))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 0.672800183, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.263675183, 0.443501592, 0.354801387))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.115318298, -1.29201102, 0, 0.866024852, -0.499999672, 0, 0.499999672, 0.866024852, 0, 0, 0, 1))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.336399972, 1, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.263675183, 0.354801297, 0.263675183))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.115318298, 0, 0.9815588, 0.866024911, -0.499999762, 0, 0, 0, 1, -0.499999762, -0.866024911, 0))
mesh("BlockMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.336399972, 1, 0.672800183))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Part", Vector3.new(0.263675183, 0.354801297, 0.263675183))
Partweld = weld(m, HandleB, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.0709648132, 0, 0.981558442, 0.866024911, -0.499999762, 0, 0, 0, 1, -0.499999762, -0.866024911, 0))
mesh("CylinderMesh", Part, "", "", Vector3.new(0, 0, 0), Vector3.new(0.672799706, 1, 0.672800183))
Wedge = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Wedge", Vector3.new(0.354801327, 0.263675213, 0.263675183))
Wedgeweld = weld(m, HandleB, Wedge, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, -0.824932098, -0.0946245193, 0, 0, 1, 0.866024911, -0.499999762, 0, 0.499999762, 0.866024911, 0))
mesh("SpecialMesh", Wedge, Enum.MeshType.Wedge, "", Vector3.new(0, 0, 0), Vector3.new(1, 0.336399972, 0.672799885))
Wedge = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Wedge", Vector3.new(0.363671362, 0.263675213, 0.263675183))
Wedgeweld = weld(m, HandleB, Wedge, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, 0.425788879, 0.0384018421, 5.16191072E-8, -2.98023082E-8, -0.999999702, -0.866024613, 0.499999583, -5.96046448E-8, 0.499999762, 0.866024911, 0))
mesh("SpecialMesh", Wedge, Enum.MeshType.Wedge, "", Vector3.new(0, 0, 0), Vector3.new(1, 0.672800004, 0.336399972))
Wedge = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Wedge", Vector3.new(0.363671362, 0.263675213, 0.263675183))
Wedgeweld = weld(m, HandleB, Wedge, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, -0.603176117, 0.0384008884, 0, 0, 1, 0.866024911, -0.499999762, 0, 0.499999762, 0.866024911, 0))
mesh("SpecialMesh", Wedge, Enum.MeshType.Wedge, "", Vector3.new(0, 0, 0), Vector3.new(1, 0.672800004, 0.336399972))
Wedge = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Wedge", Vector3.new(0.354801327, 0.354801297, 0.263675183))
Wedgeweld = weld(m, HandleB, Wedge, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, 0.337089539, 0.0383994579, 3.87143366E-8, -2.23517329E-8, -0.999999583, -0.866024613, 0.499999613, -4.47034836E-8, 0.499999762, 0.866024911, 0))
mesh("SpecialMesh", Wedge, Enum.MeshType.Wedge, "", Vector3.new(0, 0, 0), Vector3.new(1, 1, 0.336399972))
Wedge = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Wedge", Vector3.new(0.263675183, 0.354801297, 0.354801297))
Wedgeweld = weld(m, HandleB, Wedge, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, 0.306602478, 0.17517662, 0, 0, -1, 0.999999583, 1.1920929E-7, 0, 1.1920929E-7, -0.999999583, 0))
mesh("SpecialMesh", Wedge, Enum.MeshType.Wedge, "", Vector3.new(0, 0, 0), Vector3.new(0.672799945, 1, 1))
Wedge = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Wedge", Vector3.new(0.263675183, 0.354801297, 0.263675183))
Wedgeweld = weld(m, HandleB, Wedge, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, 0.159656525, -3.0217073, 4.16935109E-7, 5.17906784E-8, -0.999999404, -0.866022944, 0.500002921, -3.35181227E-7, 0.500002861, 0.866022885, 1.04308128E-7))
mesh("SpecialMesh", Wedge, Enum.MeshType.Wedge, "", Vector3.new(0, 0, 0), Vector3.new(0.672800004, 1, 0.672799945))
Wedge = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Wedge", Vector3.new(0.263675183, 0.263675213, 0.263675183))
Wedgeweld = weld(m, HandleB, Wedge, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, -1.00234604, 3.55395985, -7.45057704E-9, -1.29047768E-8, -0.999999762, 0.866024911, -0.499999762, 0, -0.499999613, -0.866024792, 1.49011612E-8))
mesh("SpecialMesh", Wedge, Enum.MeshType.Wedge, "", Vector3.new(0, 0, 0), Vector3.new(0.672800004, 0.336399972, 0.672799885))
Wedge = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Wedge", Vector3.new(0.263675183, 0.263675213, 0.263675183))
Wedgeweld = weld(m, HandleB, Wedge, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, -1.00234604, -3.11040449, 0, 0, 1, 0.866024911, -0.499999762, 0, 0.499999762, 0.866024911, 0))
mesh("SpecialMesh", Wedge, Enum.MeshType.Wedge, "", Vector3.new(0, 0, 0), Vector3.new(0.672800004, 0.336399972, 0.672799885))
Wedge = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Wedge", Vector3.new(0.263675183, 0.263675213, 0.263675183))
Wedgeweld = weld(m, HandleB, Wedge, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, -0.869285583, -0.0946269035, 0, 0, 1, 0.866024911, -0.499999762, 0, 0.499999762, 0.866024911, 0))
mesh("SpecialMesh", Wedge, Enum.MeshType.Wedge, "", Vector3.new(0, 0, 0), Vector3.new(0.672800004, 0.672799945, 0.672799885))
Wedge = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Wedge", Vector3.new(0.263675183, 0.263675213, 0.263675183))
Wedgeweld = weld(m, HandleB, Wedge, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.133049011, -0.957988739, -0.272016048, 0, 0, 1, 0.866024911, -0.499999762, 0, 0.499999762, 0.866024911, 0))
mesh("SpecialMesh", Wedge, Enum.MeshType.Wedge, "", Vector3.new(0, 0, 0), Vector3.new(0.336399972, 0.672799945, 0.672799885))
Wedge = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Wedge", Vector3.new(0.263675183, 0.263675213, 0.263675183))
Wedgeweld = weld(m, HandleB, Wedge, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.133056641, -0.957988739, -0.272016048, 0, 0, 1, 0.866024911, -0.499999762, 0, 0.499999762, 0.866024911, 0))
mesh("SpecialMesh", Wedge, Enum.MeshType.Wedge, "", Vector3.new(0, 0, 0), Vector3.new(0.336399972, 0.672799945, 0.672799885))
Wedge = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Wedge", Vector3.new(0.354801327, 0.266100973, 0.263675183))
Wedgeweld = weld(m, HandleB, Wedge, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, 0.204036713, 1.69116938, 7.38661754E-9, -1.06415222E-7, 0.999999702, -0.866022885, 0.500002861, 5.96046448E-8, -0.50000298, -0.866023242, -8.84652422E-8))
mesh("SpecialMesh", Wedge, Enum.MeshType.Wedge, "", Vector3.new(0, 0, 0), Vector3.new(1, 1, 0.672799945))
Wedge = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Black", "Wedge", Vector3.new(0.354801327, 0.266100973, 0.263675183))
Wedgeweld = weld(m, HandleB, Wedge, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, -0.647533417, 0.038402319, 0, 0, 1, 0.866024911, -0.499999762, 0, 0.499999762, 0.866024911, 0))
mesh("SpecialMesh", Wedge, Enum.MeshType.Wedge, "", Vector3.new(0, 0, 0), Vector3.new(1, 1, 0.336399972))
mesh("BlockMesh", HandleB, "", "", Vector3.new(0, 0, 0), Vector3.new(1, 1, 0.672800243))
GunHandle = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Handle", Vector3.new(0.381150067, 0.381150067, 0.381150067))
GunHandleweld = weld(m, Character.Torso, GunHandle, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(2, 1, -0.5) * angles(0, 0, -1.6))
mesh("SpecialMesh", GunHandle, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(9.53674316E-7, -0.953024864, 0.129212379, -4.37114096E-8, 1.59872116E-14, -1, -0.939692676, 0.342020005, 4.10753103E-8, 0.342020005, 0.939692676, -1.49501655E-8))
mesh("SpecialMesh", Part, Enum.MeshType.Torso, "", Vector3.new(0, 0, 0), Vector3.new(0.899999976, 1, 1.10000002))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-4.17971992, 0.11357975, 0, 0.939692616, 0.342020094, 2.63613131E-9, -0.342020094, 0.939692616, 1.4950194E-8, 2.6361171E-9, -1.49502029E-8, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(7.5, 1, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(4.76837158E-7, 0.0182886124, -1.77848053, 8.56958948E-9, 1.90287484E-8, -1, -0.342020094, 0.939692616, 1.4950194E-8, 0.939692616, 0.342020094, 1.45609942E-8))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.600000024, 0.403200001, 0.403200001))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(4.76837158E-7, 0.0182931423, 5.51375294, 1.32045113E-8, -1.71789978E-7, 1, -0.342020392, 0.939692497, 1.65945977E-7, -0.939692497, -0.342020392, -4.63474912E-8))
mesh("SpecialMesh", Part, Enum.MeshType.Cylinder, "", Vector3.new(0, 0, 0), Vector3.new(1.00999999, 0.100000001, 0.100000001))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(4.76837158E-7, 0.11357975, 5.51375103, 1.32045113E-8, -1.71789978E-7, 1, -0.342020392, 0.939692497, 1.65945977E-7, -0.939692497, -0.342020392, -4.63474912E-8))
mesh("SpecialMesh", Part, Enum.MeshType.Cylinder, "", Vector3.new(0, 0, 0), Vector3.new(1.00999999, 0.100000001, 0.100000001))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(4.76837158E-7, 0.208868504, 5.51374912, 1.32045113E-8, -1.71789978E-7, 1, -0.342020392, 0.939692497, 1.65945977E-7, -0.939692497, -0.342020392, -4.63474912E-8))
mesh("SpecialMesh", Part, Enum.MeshType.Cylinder, "", Vector3.new(0, 0, 0), Vector3.new(1.00999999, 0.100000001, 0.100000001))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, 0.208867311, 2.84569836, 1.32045113E-8, -1.71789978E-7, 1, -0.342020392, 0.939692497, 1.65945977E-7, -0.939692497, -0.342020392, -4.63474912E-8))
mesh("SpecialMesh", Part, Enum.MeshType.Cylinder, "", Vector3.new(0, 0, 0), Vector3.new(1.00999999, 0.100000001, 0.100000001))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, 0.0182921886, 2.84569836, 1.32045113E-8, -1.71789978E-7, 1, -0.342020392, 0.939692497, 1.65945977E-7, -0.939692497, -0.342020392, -4.63474912E-8))
mesh("SpecialMesh", Part, Enum.MeshType.Cylinder, "", Vector3.new(0, 0, 0), Vector3.new(1.00999999, 0.100000001, 0.100000001))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, 0.113578558, 2.84569359, 1.32045113E-8, -1.71789978E-7, 1, -0.342020392, 0.939692497, 1.65945977E-7, -0.939692497, -0.342020392, -4.63474912E-8))
mesh("SpecialMesh", Part, Enum.MeshType.Cylinder, "", Vector3.new(0, 0, 0), Vector3.new(1.00999999, 0.100000001, 0.100000001))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, 0.113579512, 4.17971992, 1.32045113E-8, -1.71789978E-7, 1, -0.342020392, 0.939692497, 1.65945977E-7, -0.939692497, -0.342020392, -4.63474912E-8))
mesh("SpecialMesh", Part, Enum.MeshType.Cylinder, "", Vector3.new(0, 0, 0), Vector3.new(1.00999999, 0.25, 0.25))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, 0.113581657, 4.94202137, 1.32045113E-8, -1.71789978E-7, 1, -0.342020392, 0.939692497, 1.65945977E-7, -0.939692497, -0.342020392, -4.63474912E-8))
mesh("SpecialMesh", Part, Enum.MeshType.Cylinder, "", Vector3.new(0, 0, 0), Vector3.new(1.00999999, 0.25, 0.25))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, 0.113580942, 3.41741848, 1.32045113E-8, -1.71789978E-7, 1, -0.342020392, 0.939692497, 1.65945977E-7, -0.939692497, -0.342020392, -4.63474912E-8))
mesh("SpecialMesh", Part, Enum.MeshType.Cylinder, "", Vector3.new(0, 0, 0), Vector3.new(1.00999999, 0.25, 0.25))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-1.66413498, 0.113578558, 0, 0.939692616, 0.342020094, 7.61535688E-8, -0.342020094, 0.939692616, -3.01059487E-7, -1.74529333E-7, 2.56857305E-7, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(6, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-1.99341202, -0.442775249, 0, 0.996194661, 0.0871559829, 1.52967971E-7, -0.0871559829, 0.996194661, -2.82404528E-7, -1.76999123E-7, 2.67997791E-7, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-1.71560287, -0.943623543, 0, 0.984807849, -0.173647612, 2.22336723E-7, 0.173647612, 0.984807849, -2.44504179E-7, -1.76501374E-7, 2.79397881E-7, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-1.31763077, -1.35550165, 0, 0.906307995, -0.422617674, 2.79532543E-7, 0.422617674, 0.906307995, -1.89941261E-7, -1.73070049E-7, 2.90280695E-7, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.826614857, -1.65033817, 0, 0.766044676, -0.642787278, 3.20657591E-7, 0.642787278, 0.766044676, -1.22434102E-7, -1.66938946E-7, 2.99904627E-7, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.237905979, -1.80804634, 0, 0.573577225, -0.819151521, 3.42909118E-7, 0.819151521, 0.573577225, -4.65834837E-8, -1.58525921E-7, 3.07613732E-7, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(1.21473026, 1.17686081, 0, -0.422618568, -0.906307578, 2.33652415E-7, -0.906307578, 0.422618568, -2.35821346E-7, 1.14980821E-7, -3.11423435E-7, -1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(1.4658556, 0.484131813, 0, -0.819152176, -0.573576212, 9.02945203E-8, -0.573576212, 0.819152176, -2.99197779E-7, 9.7647785E-8, -2.96879307E-7, -1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.689001441, 1.65122223, 0, 0.0871550441, -0.99619472, 3.2611581E-7, -0.99619472, -0.0871550441, -1.0925686E-7, 1.37263726E-7, -3.15352565E-7, -1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(1.38589287, 0.847026825, 0, -0.642787814, -0.766044259, 1.66145298E-7, -0.766044259, 0.642787814, -2.76946309E-7, 1.05356911E-7, -3.05292332E-7, -1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.964036465, 1.4511528, 0, -0.173648596, -0.98480773, 2.88215375E-7, -0.98480773, 0.173648596, -1.78625584E-7, 1.25863636E-7, -3.14854816E-7, -1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(4.76837158E-7, 0.0182888508, -1.77848053, 8.56958948E-9, 1.90287484E-8, -1, -0.342020094, 0.939692616, 1.4950194E-8, 0.939692616, 0.342020094, 1.45609942E-8))
mesh("SpecialMesh", Part, Enum.MeshType.Cylinder, "", Vector3.new(0, 0, 0), Vector3.new(0.910000026, 1.5, 1.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.670000553, -0.0719742775, -5.36790085, 1.33454066E-7, -2.71807494E-7, -1, -0.342020601, 0.939692438, -3.01059487E-7, 0.939692438, 0.342020601, 3.24420135E-8))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/asset/?id=92135524", Vector3.new(0, 0, 0), Vector3.new(0.190575033, 0.190575033, 0.190575033))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.659999847, -0.0719754696, -5.36789989, 1.33454066E-7, -2.71807494E-7, -1, -0.342020392, 0.939692497, -3.01059487E-7, 0.939692497, 0.342020392, 3.24420846E-8))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/asset/?id=92135508", Vector3.new(0, 0, 0), Vector3.new(0.190575033, 0.190575033, 0.190575033))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.4897995, 0.0615938902, 0, 0.965925753, 0.258819044, 1.48945745E-9, -0.258819044, 0.965925753, 1.13133343E-8, 1.48941481E-9, -1.13133485E-8, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.323446274, 0.0280549526, 0, 0.98480773, 0.173648268, 6.64051925E-10, -0.173648268, 0.98480773, 7.59049534E-9, 6.64112321E-10, -7.59047314E-9, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.172198296, 0.0073826313, 0, 0.996194661, 0.0871557742, 1.66355818E-10, -0.0871557742, 0.996194661, 3.80969301E-9, 1.66313185E-10, -3.80967968E-9, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.172844887, 0.00577545166, 0, 0.99619472, -0.0871556699, 1.66338054E-10, 0.0871556699, 0.99619472, -3.80969656E-9, 1.66338054E-10, 3.80970278E-9, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.345030785, 0.0304279327, 0, 0.98480773, -0.173648208, 6.64124755E-10, 0.173648208, 0.98480773, -7.59039764E-9, 6.64048372E-10, 7.59040564E-9, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.515238762, 0.0700221062, 0, 0.965925813, -0.258818954, 1.48945389E-9, 0.258818954, 0.965925813, -1.13132934E-8, 1.48938284E-9, 1.13132979E-8, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.682182312, 0.126252174, 0, 0.939692676, -0.342019945, 2.63611533E-9, 0.342019945, 0.939692676, -1.49501673E-8, 2.63610644E-9, 1.49501904E-8, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(4.76837158E-7, 0.323209524, -4.17972374, -4.37114096E-8, 1.59872116E-14, -1, -0.342020094, 0.939692616, 1.4950194E-8, 0.939692616, 0.342020094, -4.10752889E-8))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.190575033, 0.57172507, 0.190575033))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(9.53674316E-7, 0.323212624, -4.94202137, -4.37114096E-8, 1.59872116E-14, -1, -0.342020094, 0.939692616, 1.4950194E-8, 0.939692616, 0.342020094, -4.10752889E-8))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.190575033, 0.57172507, 0.190575033))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(4.76837158E-7, 0.323210716, -3.41741848, -4.37114096E-8, 1.59872116E-14, -1, -0.342020094, 0.939692616, 1.4950194E-8, 0.939692616, 0.342020094, -4.10752889E-8))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.190575033, 0.57172507, 0.190575033))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, 0.132636786, -2.46454144, -4.37114096E-8, 1.59872116E-14, -1, -0.342020094, 0.939692616, 1.4950194E-8, 0.939692616, 0.342020094, -4.10752889E-8))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.381150067, 0.952875078, 0.476437539))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(4.76837158E-7, 0.0182888508, -1.77848053, 8.56958948E-9, 1.90287484E-8, -1, -0.342020094, 0.939692616, 1.4950194E-8, 0.939692616, 0.342020094, 1.45609924E-8))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.238218769, 1.90575016, 0.285862535))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, -0.128981352, -0.489798546, -4.37113954E-8, 2.13162821E-14, -1, -0.258819014, 0.965925753, 1.13133352E-8, 0.965925753, 0.258819014, -4.22219593E-8))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.247747526, 0.476437539, 0.381150067))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, -0.183193088, -0.172199249, -4.37114096E-8, 1.77635684E-14, -1, -0.0871557742, 0.996194661, 3.80972143E-9, 0.996194661, 0.0871557742, -4.3545068E-8))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.247747526, 0.476437539, 0.381150067))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, -0.108569622, 0.172843933, 1.33454066E-7, -2.71807494E-7, -1, 0.0871556997, 0.996194661, -2.59141927E-7, 0.996194661, -0.0871556997, 1.56635821E-7))
mesh("SpecialMesh", Part, Enum.MeshType.Cylinder, "", Vector3.new(0, 0, 0), Vector3.new(1.00999999, 0.100000001, 0.100000001))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, 0.175938845, -0.489797592, 1.33454066E-7, -2.71807494E-7, -1, -0.258819014, 0.965925753, -2.97086331E-7, 0.965925753, 0.258819014, 5.85577808E-8))
mesh("SpecialMesh", Part, Enum.MeshType.Cylinder, "", Vector3.new(0, 0, 0), Vector3.new(1.00999999, 0.100000001, 0.100000001))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, -0.0604324341, -0.48746109, 1.33454066E-7, -2.71807494E-7, -1, -0.258819014, 0.965925753, -2.97086331E-7, 0.965925753, 0.258819014, 5.85577808E-8))
mesh("SpecialMesh", Part, Enum.MeshType.Cylinder, "", Vector3.new(0, 0, 0), Vector3.new(1.00999999, 0.100000001, 0.100000001))
SwordHandle = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "SwordHandle", Vector3.new(0.381150067, 0.381150067, 0.381150067))
SwordHandleweld = weld(m, GunHandle, SwordHandle, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-4.17971992, 0.11357975, 0, 0.939692616, 0.342020094, 2.63613131E-9, -0.342020094, 0.939692616, 1.4950194E-8, 2.6361171E-9, -1.49502029E-8, 1))
mesh("SpecialMesh", SwordHandle, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(7.5999999, 1.10000002, 0.899999976))
BulletHole = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "BulletHole", Vector3.new(0.381150067, 0.381150067, 0.381150067))
BulletHoleweld = weld(m, GunHandle, BulletHole, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-5.61284924, 0.113579512, 0, 0.939692616, 0.342020094, 2.63613131E-9, -0.342020094, 0.939692616, 1.4950194E-8, 2.6361171E-9, -1.49502029E-8, 1))
mesh("SpecialMesh", BulletHole, Enum.MeshType.Cylinder, "", Vector3.new(0, 0, 0), Vector3.new(0.100000001, 0.75, 0.75))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Dark stone grey", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-5.61094379, 0.113578796, 0, 0.939692616, 0.342020094, 2.63613131E-9, -0.342020094, 0.939692616, 1.4950194E-8, 2.6361171E-9, -1.49502029E-8, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Cylinder, "", Vector3.new(0, 0, 0), Vector3.new(0.100000001, 0.899999976, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.515238762, 0.0700221062, 0, 0.965925813, -0.258818954, 1.48945389E-9, 0.258818954, 0.965925813, -1.13132934E-8, 1.48938284E-9, 1.13132979E-8, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.20000005, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, -0.184798479, 0.17284584, 1.33454066E-7, -2.71807494E-7, -1, 0.0871556997, 0.996194661, -2.59141927E-7, 0.996194661, -0.0871556997, 1.56635821E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.247747526, 0.476437539, 0.381150067))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, -0.120551586, 0.515238762, 1.33454066E-7, -2.71807494E-7, -1, 0.258818954, 0.965925813, -2.28005462E-7, 0.965925813, -0.258818954, 1.99255666E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.247747526, 0.476437539, 0.381150067))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, 0.184368134, 0.515237808, 1.33454066E-7, -2.71807494E-7, -1, 0.258818954, 0.965925813, -2.28005462E-7, 0.965925813, -0.258818954, 1.99255666E-7))
mesh("SpecialMesh", Part, Enum.MeshType.Cylinder, "", Vector3.new(0, 0, 0), Vector3.new(1.00999999, 0.100000001, 0.100000001))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, -0.0443205833, 0.515239716, 1.33454066E-7, -2.71807494E-7, -1, 0.258818954, 0.965925813, -2.28005462E-7, 0.965925813, -0.258818954, 1.99255666E-7))
mesh("SpecialMesh", Part, Enum.MeshType.Cylinder, "", Vector3.new(0, 0, 0), Vector3.new(1.00999999, 0.100000001, 0.100000001))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.4897995, 0.061593771, 0, 0.965925753, 0.258819014, 1.02269169E-7, -0.258819014, 0.965925753, -2.97086331E-7, -1.75676021E-7, 2.60494147E-7, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.20000005, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.172198296, 0.00738239288, 0, 0.996194661, 0.0871557742, 1.66355818E-10, -0.0871557742, 0.996194661, 3.80969301E-9, 1.66313185E-10, -3.80967968E-9, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.20000005, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, 0.121727228, -0.172197342, 1.33454066E-7, -2.71807494E-7, -1, -0.0871557742, 0.996194661, -2.82404471E-7, 0.996194661, 0.0871557742, 1.09256646E-7))
mesh("SpecialMesh", Part, Enum.MeshType.Cylinder, "", Vector3.new(0, 0, 0), Vector3.new(1.00999999, 0.100000001, 0.100000001))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, -0.106962085, -0.172197342, 1.33454066E-7, -2.71807494E-7, -1, -0.0871557742, 0.996194661, -2.82404471E-7, 0.996194661, 0.0871557742, 1.09256646E-7))
mesh("SpecialMesh", Part, Enum.MeshType.Cylinder, "", Vector3.new(0, 0, 0), Vector3.new(1.00999999, 0.100000001, 0.100000001))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.172844887, 0.00577545166, 0, 0.99619472, -0.0871556699, 1.66338054E-10, 0.0871556699, 0.99619472, -3.80969656E-9, 1.66338054E-10, 3.80970278E-9, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.20000005, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, 0.120121241, 0.17284584, 1.33454066E-7, -2.71807494E-7, -1, 0.0871556997, 0.996194661, -2.59141927E-7, 0.996194661, -0.0871556997, 1.56635821E-7))
mesh("SpecialMesh", Part, Enum.MeshType.Cylinder, "", Vector3.new(0, 0, 0), Vector3.new(1.00999999, 0.100000001, 0.100000001))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-4.76837158E-7, 0.856247663, 1.77848053, 2.58338559E-7, -5.6264372E-7, -1, 0.342020243, -0.939692557, 6.1706919E-7, -0.939692557, -0.342020243, -5.03233153E-8))
mesh("SpecialMesh", Part, Enum.MeshType.Sphere, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 1, 1.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-4.76837158E-7, 0.856247425, 1.77848053, 2.58338559E-7, -5.6264372E-7, -1, 0.342020243, -0.939692557, 6.1706919E-7, -0.939692557, -0.342020243, -5.03233153E-8))
mesh("SpecialMesh", Part, Enum.MeshType.Sphere, "", Vector3.new(0, 0, 0), Vector3.new(1.75, 0.75, 1.75))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-4.76837158E-7, 0.856247425, 1.77848053, 2.58338559E-7, -5.6264372E-7, -1, 0.342020243, -0.939692557, 6.1706919E-7, -0.939692557, -0.342020243, -5.03233153E-8))
mesh("SpecialMesh", Part, Enum.MeshType.Sphere, "", Vector3.new(0, 0, 0), Vector3.new(2, 0.5, 2))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-4.76837158E-7, 0.856247425, 1.77848053, 2.58338559E-7, -5.6264372E-7, -1, 0.342020243, -0.939692557, 6.1706919E-7, -0.939692557, -0.342020243, -5.03233153E-8))
mesh("SpecialMesh", Part, Enum.MeshType.Sphere, "", Vector3.new(0, 0, 0), Vector3.new(2.25, 0.25, 2.25))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(4.76837158E-7, 0.0182888508, -1.77848053, 8.56958948E-9, 1.90287484E-8, -1, -0.342020094, 0.939692616, 1.4950194E-8, 0.939692616, 0.342020094, 1.45609942E-8))
mesh("SpecialMesh", Part, Enum.MeshType.Cylinder, "", Vector3.new(0, 0, 0), Vector3.new(0.920000017, 1, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-1.67055988, -1.02164078, 0, 0.642787814, 0.766044259, -7.87225218E-8, 0.766044259, -0.642787814, 2.76946309E-7, 1.61551213E-7, -2.38322642E-7, -1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-1.25393057, -1.4192028, 0, 0.422618568, 0.906307578, -1.46229652E-7, 0.906307578, -0.422618568, 2.35821346E-7, 1.5192731E-7, -2.32191539E-7, -1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-1.93903637, -0.645702362, 0, 0.819152057, 0.573576331, -2.87178992E-9, 0.573576331, -0.819152057, 2.99197779E-7, 1.69260346E-7, -2.46735681E-7, -1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(1.04205418, 1.40610981, 0, -0.766044855, 0.642787099, -2.33234758E-7, -0.642787099, -0.766044855, 1.22434187E-7, -9.99691849E-8, 2.43710389E-7, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(1.27842999, 1.11316061, 0, -0.906307995, 0.422617674, -1.92109766E-7, -0.422617674, -0.906307995, 1.89941261E-7, -9.38380822E-8, 2.53334292E-7, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.776017189, 1.62790489, 0, -0.573577285, 0.819151461, -2.55486327E-7, -0.819151461, -0.573577285, 4.65834908E-8, -1.08382203E-7, 2.36001242E-7, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.748598099, -1.69538212, 0, 0.173648387, 0.98480773, -2.00792655E-7, 0.98480773, -0.173648387, 1.78625527E-7, 1.41044467E-7, -2.28760186E-7, -1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(1.43093586, 0.76900959, 0, -0.984807849, 0.173647612, -1.34913961E-7, -0.173647612, -0.984807849, 2.44504179E-7, -9.04067505E-8, 2.64217107E-7, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.15088892, -1.83136272, 0, -0.0871550143, 0.99619478, -2.38693019E-7, 0.99619478, 0.0871550143, 1.0925686E-7, 1.29644391E-7, -2.28262437E-7, -1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(1.52022934, 0.281204462, 0, -0.996194661, -0.0871562362, -6.55451302E-8, 0.0871562362, -0.996194661, 2.82404528E-7, -8.99090082E-8, 2.75617197E-7, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.10000002, 0.899999976))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, 0.0612716675, 1.0129261, 1.33454066E-7, -2.71807494E-7, -1, 0.342020243, -0.939692557, 3.01059487E-7, -0.939692557, -0.342020243, -3.24421308E-8))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.247747526, 0.476437539, 0.381150067))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, -0.242487907, 0.986351013, 1.33454066E-7, -2.71807494E-7, -1, 0.342020243, -0.939692557, 3.01059487E-7, -0.939692557, -0.342020243, -3.24421308E-8))
mesh("SpecialMesh", Part, Enum.MeshType.Cylinder, "", Vector3.new(0, 0, 0), Vector3.new(1.00999999, 0.100000001, 0.100000001))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.996317863, -0.128578424, 0, -0.939692557, -0.342020243, 1.12692575E-8, 0.342020243, -0.939692557, 3.01059487E-7, -9.23787979E-8, 2.86757682E-7, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.20000005, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, 0.0612716675, 1.37292576, 1.33454066E-7, -2.71807494E-7, -1, 0.342020243, -0.939692557, 3.01059487E-7, -0.939692557, -0.342020243, -3.24421308E-8))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/asset/?id=9756362", Vector3.new(0, 0, 0), Vector3.new(0.247747526, 0.476437539, 0.381150067))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(1.35631847, -0.128578424, 0, -0.939692557, -0.342020243, 1.12692575E-8, 0.342020243, -0.939692557, 3.01059487E-7, -9.23787979E-8, 2.86757682E-7, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(0.5, 1.20000005, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, -0.242487907, 1.34635162, 1.33454066E-7, -2.71807494E-7, -1, 0.342020243, -0.939692557, 3.01059487E-7, -0.939692557, -0.342020243, -3.24421308E-8))
mesh("SpecialMesh", Part, Enum.MeshType.Cylinder, "", Vector3.new(0, 0, 0), Vector3.new(1.00999999, 0.100000001, 0.100000001))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, -0.00248789787, 0.986351013, 1.33454066E-7, -2.71807494E-7, -1, 0.342020243, -0.939692557, 3.01059487E-7, -0.939692557, -0.342020243, -3.24421308E-8))
mesh("SpecialMesh", Part, Enum.MeshType.Cylinder, "", Vector3.new(0, 0, 0), Vector3.new(1.00999999, 0.100000001, 0.100000001))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0, -0.00248789787, 1.34635162, 1.33454066E-7, -2.71807494E-7, -1, 0.342020243, -0.939692557, 3.01059487E-7, -0.939692557, -0.342020243, -3.24421308E-8))
mesh("SpecialMesh", Part, Enum.MeshType.Cylinder, "", Vector3.new(0, 0, 0), Vector3.new(1.00999999, 0.100000001, 0.100000001))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.655434608, -0.288022995, -5.37018013, 2.79783706E-7, 7.8075999E-9, 1, 0.342020094, -0.939692616, -8.83548879E-8, 0.939692616, 0.342020094, -2.65581036E-7))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/asset/?id=92135524", Vector3.new(0, 0, 0), Vector3.new(0.190575033, 0.190575033, 0.190575033))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, GunHandle, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.66565752, -0.288024902, -5.36789989, -1.85097718E-7, 4.13697137E-7, 1, 0.342020392, -0.939692497, 4.52055303E-7, 0.939692497, 0.342020392, 3.24420846E-8))
mesh("SpecialMesh", Part, Enum.MeshType.FileMesh, "http://www.roblox.com/asset/?id=92135508", Vector3.new(0, 0, 0), Vector3.new(0.190575033, 0.190575033, 0.190575033))
CoreHandle = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Handle", Vector3.new(0.381150067, 0.381150067, 0.381150067))
CoreHandleweld = weld(m, Character.Torso, CoreHandle, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-5, 0, -5))
mesh("SpecialMesh", CoreHandle, Enum.MeshType.Sphere, "", Vector3.new(0, 0, 0), Vector3.new(7.5, 7.5, 7.5))
Ring1ReferencePoint = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 1, "White", "Handle", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Ring1ReferencePointweld = weld(m, CoreHandle, Ring1ReferencePoint, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.126105309, -0.124329567, -0.0193977356, 0.866025567, -0.499999702, -1.54855613E-8, 0.499999702, 0.866025567, -8.94058605E-9, 1.78811828E-8, 0, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring1ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.0487003326, 0.170000553, -2.0073452, 0.707106769, 3.61242698E-8, -0.707106709, 1.49011612E-7, 1, 9.83475559E-8, 0.707106709, -1.55333566E-7, 0.707106829))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring1ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.0345611572, -0.170001507, -2.08923244, -0.25881952, 1.12944072E-7, -0.965925694, -1.78813934E-7, -1.00000012, -6.85452335E-8, -0.965925694, 1.76499938E-7, 0.25881952))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Metal, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring1ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.0654983521, 0.170000076, -1.98813725, 0.50000006, -3.696071E-8, -0.866025388, 1.1920929E-7, 1, 8.94058783E-9, 0.866025329, -1.53481906E-7, 0.50000006))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring1ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00164413452, -0.17000246, -1.94940472, 0.25881955, -3.09876853E-8, 0.965925694, -8.94069672E-8, -1, -3.87429111E-8, 0.965925694, -5.72906451E-8, -0.25881955))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Metal, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring1ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.0628457069, -0.17000103, -2.05058289, -1, 1.49011612E-7, 3.04476913E-7, -1.49011612E-7, -1, -8.56288374E-10, 3.04476941E-7, -8.5632923E-10, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Metal, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring1ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.0513486862, -0.17000246, -2.08439445, -0.866025627, 2.13086551E-7, -0.499999732, -2.08616257E-7, -1, 5.96057159E-9, -0.499999702, 1.26367681E-7, 0.866025567))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Metal, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring1ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.0869293213, 0.170001507, -2.02276611, -0.866025269, 1.7434364E-7, 0.500000298, 2.38418579E-7, 1, 5.36440723E-8, -0.500000238, 1.71655543E-7, -0.866025269))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Metal, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring1ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.00387001038, -0.170002937, -1.9525547, 0.500000417, -8.22485759E-8, 0.86602515, -5.96046448E-8, -1, -3.87429111E-8, 0.86602515, -5.51343469E-8, -0.500000417))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Metal, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring1ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.0341186523, 0.169999599, -1.95340586, 2.32048365E-7, -5.22409245E-8, -1, 2.08616257E-7, 1, -5.22408925E-8, 1, -2.08616257E-7, 2.32048379E-7))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Metal, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring1ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.0219216347, -0.170001984, -1.95992088, 0.866025507, -1.53481906E-7, 0.499999762, -1.78813934E-7, -0.99999994, -2.38417499E-8, 0.499999762, -5.18618677E-8, -0.866025507))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring1ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.0774993896, 0.17000246, -2.00134659, -0.965925753, 2.95709214E-7, 0.258819312, 3.57627869E-7, 1, 4.61934953E-8, -0.258819312, 1.35295807E-7, -0.965925753))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring1ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.0341739655, 0.170001507, -2.07081223, -0.258819073, 7.33204431E-8, 0.965925813, 1.78813934E-7, 1, -5.06640561E-8, -0.965925813, 1.51325608E-7, -0.258819103))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring1ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.0670967102, 0.170000553, -1.96782446, 0.258819103, -1.03122765E-7, -0.965925813, 1.78813934E-7, 1, -5.06640561E-8, 0.965925813, -1.51325608E-7, 0.258819103))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring1ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.0439095497, -0.17000103, -1.96881485, 0.965925932, -6.19186338E-8, 0.258818865, -1.1920929E-7, -1, 1.25169862E-7, 0.258818865, -1.47826256E-7, -0.965925813))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Metal, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring1ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.0628457069, -0.170001984, -1.9794178, 1, -5.96046412E-8, -2.65629694E-7, -5.96046448E-8, -1, -2.09936371E-8, -2.65629666E-7, 2.09936495E-8, -1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Metal, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring1ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.0341186523, -0.17000246, -2.07909966, -7.37518917E-7, 7.7378985E-8, -1, -2.08616257E-7, -1, -7.73789282E-8, -1, 2.08616257E-7, 7.37518974E-7))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring1ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.0623283386, 0.170000553, -2.03755379, 0.965925813, -2.74883263E-8, -0.258819252, 5.96046448E-8, 1, 8.34463947E-8, 0.258819252, -9.80429107E-8, 0.965925753))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring1ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.00162315369, -0.17000103, -1.95702171, 0.707107127, -3.61242662E-8, 0.707106352, -1.78813934E-7, -0.99999994, 5.06640561E-8, 0.707106352, -1.12887335E-7, -0.707107186))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Metal, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring1ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.0575027466, 0.170001507, -2.02154922, 0.866025329, -5.51343504E-8, -0.500000179, 8.94069672E-8, 1, 2.38417499E-8, 0.500000179, -6.73474148E-8, 0.866025329))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring1ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.0904979706, 0.170001984, -2.0459013, -0.707106829, 2.34803732E-8, 0.707106769, 2.08616257E-7, 0.99999994, 6.85452335E-8, -0.707106709, 1.85135889E-7, -0.707106829))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Metal, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring1ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.0589771271, 0.169999599, -2.06140852, -0.49999994, 6.67630289E-8, 0.866025448, 1.78813934E-7, 0.99999994, 3.87429111E-8, -0.866025448, 1.53481906E-7, -0.49999994))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring1ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.0590806007, -0.17000103, -2.07008362, -0.965925932, 1.21523286E-7, -0.258818775, -1.49011612E-7, -1, 5.96057337E-9, -0.258818775, 3.60675401E-8, 0.965925932))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Metal, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring1ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.00265312195, -0.170001984, -2.09698868, -0.500000536, 2.01457866E-7, -0.86602509, -2.38418579E-7, -1, -1.28149878E-7, -0.86602509, 8.49366728E-8, 0.500000536))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring1ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.0401754379, -0.17000103, -2.09622192, -0.707107186, 1.85135875E-7, -0.707106352, -2.38418579E-7, -1, 5.06640561E-8, -0.707106352, 1.7249198E-7, 0.707107186))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Ring2ReferencePoint = part(Enum.FormFactor.Custom, m, Enum.Material.SmoothPlastic, 0, 1, "White", "Handle", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Ring2ReferencePointweld = weld(m, CoreHandle, Ring2ReferencePoint, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.0446195602, -0.171374798, -0.0193977356, 0.866025269, 0.500000298, -1.54855613E-8, -0.500000298, 0.866025269, -8.94058516E-9, 8.94059227E-9, 1.54855577E-8, 1))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Metal, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring2ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.178648949, -0.0305736065, -2.37941742, 1, 2.60665813E-15, -2.76067851E-7, -9.33221395E-17, -1, -2.914188E-9, -2.76067851E-7, 2.914188E-9, -1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring2ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.155764103, -0.0305743217, -2.33884048, 0.965925932, -1.21523286E-7, 0.258818924, -1.1920929E-7, -1, 1.34111557E-8, 0.258818924, -3.60675401E-8, -0.965925813))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Metal, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring2ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.122206688, -0.0305736065, -2.30201721, 0.866025567, -1.23679584E-7, 0.499999762, -1.49011612E-7, -1, -5.36440723E-8, 0.499999762, -2.20595489E-8, -0.866025507))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring2ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.0802621841, -0.0305736065, -2.27513695, 0.707107246, -1.2553123E-7, 0.707106411, -2.38418579E-7, -1.00000012, -8.94058871E-9, 0.707106411, -1.12887335E-7, -0.707107186))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Metal, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring2ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.0617694855, -0.0305755138, -2.25226593, 0.500000477, 2.20595506E-8, 0.86602515, -2.98023224E-8, -1, -8.94058516E-9, 0.866025209, 4.47029702E-9, -0.500000477))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring2ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.0283260345, -0.0305755138, -2.23754883, 0.25881952, -3.84382659E-8, 0.965925753, 4.6150569E-16, -1, -3.87429075E-8, 0.965925753, 3.2116322E-8, -0.25881952))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Metal, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring2ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.0341186523, 0.0305724144, -2.23760414, 2.3204862E-7, 7.0121942E-8, -1, -1.1920929E-7, 1, 7.01219491E-8, 1, 1.1920929E-7, 2.32048635E-7))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring2ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.097070694, 0.0305728912, -2.25596666, 0.258819103, 1.12944072E-7, -0.965925813, -2.98023224E-8, 1, 9.83475488E-8, 0.965925813, -2.31399389E-9, 0.258819103))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Metal, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring2ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.123401642, 0.0305736065, -2.28784943, 0.50000006, 9.71497371E-8, -0.866025388, -1.49011612E-7, 1, 8.9405825E-9, 0.866025388, 1.7434364E-7, 0.50000006))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring2ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.130586624, 0.0305733681, -2.32545948, 0.707106888, 9.57289146E-8, -0.707106769, -5.96046448E-8, 1, 6.85452264E-8, 0.707106769, 2.34803732E-8, 0.707106829))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Metal, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring2ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.157791138, 0.0305743217, -2.36365128, 0.866025388, 3.02493504E-7, -0.500000179, -1.1920929E-7, 1, 1.57952201E-7, 0.500000179, -3.75450959E-8, 0.866025269))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring2ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.174186707, 0.0305743217, -2.40757751, 0.965925813, 6.19186409E-8, -0.258819252, -5.96046448E-8, 1, -1.34111584E-8, 0.258819252, 4.35181207E-8, 0.965925753))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Metal, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring2ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.178647041, -0.030575037, -2.4505806, -1, 5.96046412E-8, 3.04476941E-7, -5.96046448E-8, -1, -8.56271498E-10, 3.04476941E-7, -8.56285709E-10, 1))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring2ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.170937061, -0.0305745602, -2.50005341, -0.965925932, 6.19186338E-8, -0.258818775, -5.96046448E-8, -1, -3.1292327E-8, -0.258818775, -8.63594263E-9, 0.965925932))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Metal, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring2ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.151638031, -0.0305743217, -2.54229546, -0.866025567, 6.4074932E-8, -0.499999732, -5.96046448E-8, -1, -6.85452335E-8, -0.499999762, -5.24462607E-8, 0.866025567))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring2ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.122059822, -0.0305738449, -2.57810593, -0.707107306, 6.32194475E-9, -0.707106352, 2.98023224E-8, -1, -8.94058427E-9, -0.707106352, -3.61242769E-8, 0.707107246))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Metal, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring2ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.0552463531, -0.0305752754, -2.59727478, -0.500000477, 7.74277087E-9, -0.86602509, -5.96046448E-8, -1, -8.94058516E-9, -0.866025209, 2.53320245E-8, 0.500000477))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring2ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.00459098816, -0.0305759907, -2.60108852, -0.25881952, 3.09876818E-8, -0.965925694, -2.38418579E-7, -1, 5.06640561E-8, -0.965925694, 2.36104583E-7, 0.258819491))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Metal, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring2ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(0.0341205597, -0.0305759907, -2.59490204, -7.37519429E-7, 5.97119367E-8, -1, -1.49011612E-7, -1, -5.97117662E-8, -1, 1.49011612E-7, 7.37519429E-7))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring2ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.0641441345, 0.0305731297, -2.58266878, -0.258819073, -7.56911689E-8, 0.965925872, 2.08616257E-7, 1, 1.28149878E-7, -0.965925872, 2.10930253E-7, -0.258819073))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Metal, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring2ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.116876602, 0.0305738449, -2.56169653, -0.499999821, 1.26367681E-7, 0.866025507, 2.08616257E-7, 1, -5.06640561E-8, -0.866025567, 1.53481906E-7, -0.499999821))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring2ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.172384262, 0.0305747986, -2.52778625, -0.707106709, 2.32096625E-7, 0.707106829, 2.68220901E-7, 1, -8.04663784E-8, -0.707106829, 1.25531244E-7, -0.707106709))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Metal, 0, 0, "Really black", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring2ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.18721962, 0.0305728912, -2.48066711, -0.866025269, 1.44541318E-7, 0.500000238, 2.08616257E-7, 1, 6.85452335E-8, -0.500000238, 1.41853221E-7, -0.866025269))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
Part = part(Enum.FormFactor.Custom, m, Enum.Material.Neon, 0, 0, "White", "Part", Vector3.new(0.381150067, 0.381150067, 0.381150067))
Partweld = weld(m, Ring2ReferencePoint, Part, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), CFrame.new(-0.18935585, 0.030575037, -2.43131638, -0.965925753, 1.16895293E-7, 0.258819401, 1.78813934E-7, 1, 9.08969753E-8, -0.258819431, 1.27845226E-7, -0.965925694))
mesh("SpecialMesh", Part, Enum.MeshType.Brick, "", Vector3.new(0, 0, 0), Vector3.new(1.5, 0.5, 0.5))
function MagniDamage(Part, magni, minDam, maxDam, knockdown, knockback)
  Dam = math.random(minDam, maxDam)
  for _, c in pairs(workspace:children()) do
    do
      local hum = c:findFirstChild("Humanoid")
      if hum ~= nil then
        local head = c:findFirstChild("Torso")
        if head ~= nil then
          local targ = head.Position - Part.Position
          local mag = targ.magnitude
          if magni >= mag and c.Name ~= Player.Name then
            hum:TakeDamage(Dam)
            ShowDamage(Part.CFrame * CFrame.new(0, 0, Part.Size.Z / 2).p + Vector3.new(0, 1.5, 0), -Dam, 1.5, Part.BrickColor.Color)
            if knockdown then
              coroutine.resume(coroutine.create(function()
                hum.PlatformStand = true
                swait(30)
                hum.PlatformStand = false
              end))
            end
            if knockback ~= nil then
              bv = Instance.new("BodyVelocity", hum.Parent.Torso)
              bv.Velocity = Part.CFrame.lookVector * knockback
              bv.MaxForce = Vector3.new(math.huge, math.huge, math.huge)
              swait()
              bv:Remove()
            end
          end
        end
      end
    end
  end
end
Mouse = player:GetMouse()
function LaserBarrage(Prt, Parent)
  attack = true
  if busterammo > 0 then
    busterammo = busterammo - 1
    so("http://www.roblox.com/asset/?id=203691837", BarrelB, 1, 0.9)
    local efprt = part(3, Parent, "SmoothPlastic", 0, 0.5, BrickColor.new("White"), "Effect", vt(0.2, 0.2, 0.2))
    efprt.Anchored = true
    local efmsh = mesh("CylinderMesh", efprt, "", "", vt(0, 0, 0), vt(1, 1, 1))
    local spread = vt((math.random(-1, 0) + math.random()) * 0, (math.random(-1, 0) + math.random()) * 0, (math.random(-1, 0) + math.random()) * 0) * (Prt.Position - Mouse.Hit.p).magnitude / 100
    coroutine.resume(coroutine.create(function(Part, Mesh, Spreaded)
      game:GetService("Debris"):AddItem(Part, 6)
      local TheHit = Mouse.Hit.p
      local MouseLook = cf((Prt.Position + TheHit) / 2, TheHit + Spreaded)
      local hit, pos = rayCast(Prt.Position, MouseLook.lookVector, 1000, Parent)
      so("Elec", Prt, 0.2, 1)
      local tefprt = part(3, workspace, "SmoothPlastic", 0, 1, BrickColor.new("Black"), "Effect", vt(0.2, 0.2, 0.2))
      tefprt.CFrame = cf(pos)
      MagniDamage(tefprt, 2, 5, 8)
      MagicCircle(BrickColor.new("White"), cf(pos), 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.04)
      so("Elec", tefprt, 0.3, 1)
      game:GetService("Debris"):AddItem(tefprt, 3)
      Part.CFrame = CFrame.new((Prt.Position + pos) / 2, pos) * angles(1.57, 0, 0)
      local mag = (Prt.Position - pos).magnitude
      MagicCylinder(BrickColor.new("White"), Part.CFrame, 1, mag * 5, 1, 0.5, 0.5, 0.5, 0.05)
      Part.Parent = nil
    end), efprt, efmsh, spread)
  else
    so("http://www.roblox.com/asset/?id=203691822", BarrelB, 1, 0.9)
  end
end
local GetDiscoColor = function(hue)
  local section = hue % 1 * 3
  local secondary = 0.5 * math.pi * (section % 1)
  if section < 1 then
    return Color3.new(1, 1 - math.cos(secondary), 1 - math.sin(secondary))
  elseif section < 2 then
    return Color3.new(1 - math.sin(secondary), 1, 1 - math.cos(secondary))
  else
    return Color3.new(1 - math.cos(secondary), 1 - math.sin(secondary), 1)
  end
end
local setupPart = function(part)
  part.Anchored = true
  part.FormFactor = 3
  part.CanCollide = false
  part.TopSurface = 10
  part.BottomSurface = 10
  part.LeftSurface = 10
  part.RightSurface = 10
  part.FrontSurface = 10
  part.BackSurface = 10
  part.Material = "Neon"
  local m = Instance.new("SpecialMesh", part)
  m.MeshType = "Wedge"
  m.Scale = Vector3.new(0.2, 1, 1)
  return part
end
local CFrameFromTopBack = function(at, top, back)
  local right = top:Cross(back)
  return CFrame.new(at.x, at.y, at.z, right.x, top.x, back.x, right.y, top.y, back.y, right.z, top.z, back.z)
end
local function drawTri(parent, a, b, c)
  local this = {}
  local mPart1 = table.remove(triParts, 1) or setupPart(Instance.new("Part"))
  local mPart2 = table.remove(triParts, 1) or setupPart(Instance.new("Part"))
  function this:Set(a, b, c)
    local ab, bc, ca = b - a, c - b, a - c
    local abm, bcm, cam = ab.magnitude, bc.magnitude, ca.magnitude
    local edg1 = math.abs(0.5 + ca:Dot(ab) / (abm * abm))
    local edg2 = math.abs(0.5 + ab:Dot(bc) / (bcm * bcm))
    local edg3 = math.abs(0.5 + bc:Dot(ca) / (cam * cam))
    if edg1 < edg2 then
      if edg1 >= edg3 then
        a, b, c = c, a, b
        ab, bc, ca = ca, ab, bc
        abm = cam
      end
    elseif edg2 < edg3 then
      a, b, c = b, c, a
      ab, bc, ca = bc, ca, ab
      abm = bcm
    else
      a, b, c = c, a, b
      ab, bc, ca = ca, ab, bc
      abm = cam
    end
    local len1 = -ca:Dot(ab) / abm
    local len2 = abm - len1
    local width = (ca + ab).unit * len1.magnitude
    local maincf = CFrameFromTopBack(a, ab:Cross(bc).unit, -ab.unit)
    if len1 > 0.2 then
      mPart1.Parent = parent
      mPart1.Size = Vector3.new(0.2, width, len1)
      mPart1.CFrame = maincf * CFrame.Angles(math.pi, 0, math.pi / 2) * CFrame.new(0, width / 2, len1 / 2)
    else
      mPart1.Parent = nil
    end
    if len2 > 0.2 then
      mPart2.Parent = parent
      mPart2.Size = Vector3.new(0.2, width, len2)
      mPart2.CFrame = maincf * CFrame.Angles(math.pi, math.pi, -math.pi / 2) * CFrame.new(0, width / 2, -len1 - len2 / 2)
    else
      mPart2.Parent = nil
    end
  end
  function this:SetProperty(prop, value)
    mPart1[prop] = value
    mPart2[prop] = value
  end
  this:Set(a, b, c)
  function this:Destroy()
    mPart1:Destroy()
    mPart2:Destroy()
  end
  this.p1 = mPart1
  this.p2 = mPart2
  this.p1.BrickColor = BrickColor.new(GetDiscoColor(math.noise(0.5, 0.5, this.p1.CFrame.Y * 0.5 + time())))
  this.p2.BrickColor = BrickColor.new(GetDiscoColor(math.noise(0.5, 0.5, this.p2.CFrame.Y * 0.5 + time())))
  return this
end
function verlet.draw(object, id)
  if object.class == "Point" then
    local part = parts[id]
    part.BrickColor = BrickColor.new(1, 1, 1)
    part.Transparency = 0
    part.formFactor = 3
    part.Anchored = true
    part.CanCollide = false
    part.TopSurface = 0
    part.BottomSurface = 0
    part.Size = Vector3.new(0.35, 0.35, 0.35)
    part.Material = "Neon"
    part.CFrame = CFrame.new(object.position)
    part.Parent = torso
    return part
  elseif object.class == "Link" then
    local part = parts[id]
    local dist = (object.point1.position - object.point2.position).magnitude
    part.Size = Vector3.new(0.2, 0.2, dist)
    part.CFrame = CFrame.new(object.point1.position, object.point2.position) * CFrame.new(0, 0, dist * -0.5)
    part.Parent = torso
    return part
  end
end
function verlet.clear()
  for _, v in pairs(workspace:GetChildren()) do
    if v.Name == "Part" then
      v:Destroy()
    end
  end
end
local points = {}
local links = {}
for x = 0, 2 do
  points[x] = {}
  for y = 0, 3 do
    points[x][y] = verlet.new("Point", torso.Position + Vector3.new(x * 0.8 - 2, 2 - y * 0.8, 5 + y * 0.4))
    points[x][y].fixed = y == 0
  end
end
for x = 1, 2 do
  for y = 0, 3 do
    links[#links + 1] = verlet.new("Link", points[x][y], points[x - 1][y], 1 + y * 0.08)
  end
end
for x = 0, 2 do
  for y = 1, 3 do
    links[#links + 1] = verlet.new("Link", points[x][y], points[x][y - 1], 1.2 + y * 0.03)
  end
end
local AA1 = {}
v = game.Players.LocalPlayer
if v.Character ~= nil then
end
local WorldUp = Vector3.new(0, 1, 0)
function Look2(Vec1, Vec2)
  local Orig = Vec1
  Vec1 = Vec1 + Vector3.new(0, 1, 0)
  Vec2 = Vec2 + Vector3.new(0, 1, 0)
  local Forward = Vec2 - Vec1.unit
  local Up = WorldUp - WorldUp:Dot(Forward) * Forward.unit
  local Right = Up:Cross(Forward).unit
  Forward = -Forward
  Right = -Right
  return CFrame.new(Orig.X, Orig.Y, Orig.Z, Right.X, Up.X, Forward.X, Right.Y, Up.Y, Forward.Y, Right.Z, Up.Z, Forward.Z)
end
function Look(CFr, Vec2)
  local A = Vector3.new(0, 0, 0)
  local B = CFr:inverse() * Vec2
  local CF = Look2(A, Vector3.new(A.X, B.Y, B.Z))
  if 0 < B.Z then
    CF = CFr * (CF * CFrame.Angles(0, 0, math.pi))
  elseif B.Z == 0 then
    if 0 < B.Y then
      CF = CFr * CFrame.Angles(math.pi / 2, 0, 0)
    elseif 0 > B.Y then
      CF = CFr * CFrame.Angles(-math.pi / 2, 0, 0)
    else
      CF = CFr
    end
  end
  local _, _, _, _, X, _, _, Y, _, _, Z, _ = CF:components()
  local Up = Vector3.new(X, Y, Z)
  local Forward = Vec2 - CFr.p.unit
  local Right = Up:Cross(Forward)
  Forward = -Forward
  Right = -Right
  return CFrame.new(CFr.X, CFr.Y, CFr.Z, Right.X, Up.X, Forward.X, Right.Y, Up.Y, Forward.Y, Right.Z, Up.Z, Forward.Z)
end
function Simulate(j, d, m, r, t)
  local joint = j
  for i, v in ipairs(t) do
    if v[1]:FindFirstChild("Weld") then
      local stiff = m.CFrame.lookVector * 0.03
      if i > 1 then
        joint = t[i - 1][1].CFrame * CFrame.new(0, 0, d * 0.5)
      end
      local dir = v[2].p - (joint.p + Vector3.new(0, 0.2, 0) + stiff).unit
      local dis = v[2].p - (joint.p + Vector3.new(0, 0.2, 0) + stiff).magnitude
      local pos = joint.p + dir * (d * 0.5)
      local inv = v[1].Weld.Part0.CFrame
      local rel1 = inv:inverse() * pos
      local rel2 = inv:inverse() * (pos - dir * dis)
      local cf = Look(CFrame.new(rel1), rel2)
      v[1].Weld.C0 = cf
      v[2] = inv * cf
    end
  end
end
Player = game:GetService("Players").LocalPlayer
Character = Player.Character
PlayerGui = Player.PlayerGui
Backpack = Player.Backpack
Torso = Character.Torso
Head = Character.Head
Humanoid = Character.Humanoid
LeftArm = Character["Left Arm"]
LeftLeg = Character["Left Leg"]
RightArm = Character["Right Arm"]
RightLeg = Character["Right Leg"]
LS = Torso["Left Shoulder"]
LH = Torso["Left Hip"]
RS = Torso["Right Shoulder"]
RH = Torso["Right Hip"]
Face = Head.face
Neck = Torso.Neck
it = Instance.new
attacktype = 1
vt = Vector3.new
Humanoid.Health = 1000
Humanoid.WalkSpeed = 20
cf = CFrame.new
holdE = false
euler = CFrame.fromEulerAnglesXYZ
angles = CFrame.Angles
cloaked = false
necko = cf(0, 1, 0, -1, 0, 0, 0, 0, 1, 0, 1, 0)
necko2 = cf(0, -0.5, 0, -1, 0, 0, 0, 0, 1, 0, 1, 0)
LHC0 = cf(-1, -1, 0, 0, 0, -1, 0, 1, 0, 1, 0, 0)
LHC1 = cf(-0.5, 1, 0, 0, 0, -1, 0, 1, 0, 1, 0, 0)
RHC0 = cf(1, -1, 0, 0, 0, 1, 0, 1, 0, -1, 0, 0)
RHC1 = cf(0.5, 1, 0, 0, 0, 1, 0, 1, 0, -1, 0, 0)
RootPart = Character.HumanoidRootPart
RootJoint = RootPart.RootJoint
RootCF = euler(-1.57, 0, 3.14)
attack = false
attackdebounce = false
deb = false
equipped = true
hand = false
MMouse = nil
combo = 0
mana = 0
trispeed = 0.2
attackmode = "none"
local idle = 0
local Anim = "Idle"
local Effects = {}
local gun = false
local shoot = false
player = nil
mana = 0
handleweld.C0 = cf(3, 3, 0.5) * angles(math.rad(90), math.rad(150), math.rad(90))
handleweld.Part0 = Torso
function VertexRainbow()
  while true do
    return BrickColor.new("White")
  end
end
mouse = Player:GetMouse()
RSH, LSH = nil, nil
RW, LW = Instance.new("Weld"), Instance.new("Weld")
RW.Name = "Right Shoulder"
LW.Name = "Left Shoulder"
LH = Torso["Left Hip"]
RH = Torso["Right Hip"]
TorsoColor = Torso.BrickColor
function NoOutline(Part)
  Part.TopSurface, Part.BottomSurface, Part.LeftSurface, Part.RightSurface, Part.FrontSurface, Part.BackSurface = 10, 10, 10, 10, 10, 10
end
player = Player
ch = Character
RSH = ch.Torso["Right Shoulder"]
LSH = ch.Torso["Left Shoulder"]
RSH.Parent = nil
LSH.Parent = nil
RW.Name = "Right Shoulder"
RW.Part0 = ch.Torso
RW.C0 = cf(1.5, 0.5, 0)
RW.C1 = cf(0, 0.5, 0)
RW.Part1 = ch["Right Arm"]
RW.Parent = ch.Torso
LW.Name = "Left Shoulder"
LW.Part0 = ch.Torso
LW.C0 = cf(-1.5, 0.5, 0)
LW.C1 = cf(0, 0.5, 0)
LW.Part1 = ch["Left Arm"]
LW.Parent = ch.Torso
local weldBetween = function(a, b)
  local weldd = Instance.new("ManualWeld")
  weldd.Part0 = a
  weldd.Part1 = b
  weldd.C0 = CFrame.new()
  weldd.C1 = b.CFrame:inverse() * a.CFrame
  weldd.Parent = a
  return weldd
end
function nooutline(part)
  part.TopSurface, part.BottomSurface, part.LeftSurface, part.RightSurface, part.FrontSurface, part.BackSurface = 10, 10, 10, 10, 10, 10
end
function part(formfactor, parent, material, reflectance, transparency, brickcolor, name, size)
  local fp = it("Part")
  fp.formFactor = formfactor
  fp.Parent = parent
  if fp.Parent == workspace then
      fp.Parent = Character
  end
  fp.Reflectance = reflectance
  fp.Transparency = transparency
  fp.CanCollide = false
  fp.Locked = true
  fp.BrickColor = BrickColor.new(tostring(brickcolor))
  fp.Name = name
  fp.Size = size
  fp.Position = Character.Torso.Position
  nooutline(fp)
  fp.Material = material
  fp:BreakJoints()
  return fp
end
function swait(num)
  if num == 0 or num == nil then
    game:service("RunService").Heartbeat:wait(0)
  else
    for i = 0, num do
      game:service("RunService").Heartbeat:wait(0)
    end
  end
end
function mesh(Mesh, part, meshtype, meshid, offset, scale)
  local mesh = it(Mesh)
  mesh.Parent = part
  if Mesh == "SpecialMesh" then
    mesh.MeshType = meshtype
    mesh.MeshId = meshid
  end
  mesh.Offset = offset
  mesh.Scale = scale
  return mesh
end
function weld(parent, part0, part1, c0, c1)
  local weld = it("Weld")
  weld.Parent = parent
  weld.Part0 = part0
  weld.Part1 = part1
  weld.C0 = c0
  weld.C1 = c1
  return weld
end
function so(id, par, vol, pit)
  coroutine.resume(coroutine.create(function()
    local sou = Instance.new("Sound", par or workspace)
    sou.Volume = vol
    sou.Pitch = pit or 1
    sou.SoundId = id
    swait()
    sou:play()
    game:GetService("Debris"):AddItem(sou, 6)
  end))
end
function clerp(a, b, t)
  local qa = {
    QuaternionFromCFrame(a)
  }
  local qb = {
    QuaternionFromCFrame(b)
  }
  local ax, ay, az = a.x, a.y, a.z
  local bx, by, bz = b.x, b.y, b.z
  local _t = 1 - t
  return QuaternionToCFrame(_t * ax + t * bx, _t * ay + t * by, _t * az + t * bz, QuaternionSlerp(qa, qb, t))
end
function QuaternionFromCFrame(cf)
  local mx, my, mz, m00, m01, m02, m10, m11, m12, m20, m21, m22 = cf:components()
  local trace = m00 + m11 + m22
  if trace > 0 then
    local s = math.sqrt(1 + trace)
    local recip = 0.5 / s
    return (m21 - m12) * recip, (m02 - m20) * recip, (m10 - m01) * recip, s * 0.5
  else
    local i = 0
    if m00 < m11 then
      i = 1
    end
    if m22 > (i == 0 and m00 or m11) then
      i = 2
    end
    if i == 0 then
      local s = math.sqrt(m00 - m11 - m22 + 1)
      local recip = 0.5 / s
      return 0.5 * s, (m10 + m01) * recip, (m20 + m02) * recip, (m21 - m12) * recip
    elseif i == 1 then
      local s = math.sqrt(m11 - m22 - m00 + 1)
      local recip = 0.5 / s
      return (m01 + m10) * recip, 0.5 * s, (m21 + m12) * recip, (m02 - m20) * recip
    elseif i == 2 then
      local s = math.sqrt(m22 - m00 - m11 + 1)
      local recip = 0.5 / s
      return (m02 + m20) * recip, (m12 + m21) * recip, 0.5 * s, (m10 - m01) * recip
    end
  end
end
function QuaternionToCFrame(px, py, pz, x, y, z, w)
  local xs, ys, zs = x + x, y + y, z + z
  local wx, wy, wz = w * xs, w * ys, w * zs
  local xx = x * xs
  local xy = x * ys
  local xz = x * zs
  local yy = y * ys
  local yz = y * zs
  local zz = z * zs
  return CFrame.new(px, py, pz, 1 - (yy + zz), xy - wz, xz + wy, xy + wz, 1 - (xx + zz), yz - wx, xz - wy, yz + wx, 1 - (xx + yy))
end
function QuaternionSlerp(a, b, t)
  local cosTheta = a[1] * b[1] + a[2] * b[2] + a[3] * b[3] + a[4] * b[4]
  local startInterp, finishInterp
  if cosTheta >= 1.0E-4 then
    if 1 - cosTheta > 1.0E-4 then
      local theta = math.acos(cosTheta)
      local invSinTheta = 1 / math.sin(theta)
      startInterp = math.sin((1 - t) * theta) * invSinTheta
      finishInterp = math.sin(t * theta) * invSinTheta
    else
      startInterp = 1 - t
      finishInterp = t
    end
  elseif 1 + cosTheta > 1.0E-4 then
    local theta = math.acos(-cosTheta)
    local invSinTheta = 1 / math.sin(theta)
    startInterp = math.sin((t - 1) * theta) * invSinTheta
    finishInterp = math.sin(t * theta) * invSinTheta
  else
    startInterp = t - 1
    finishInterp = t
  end
  return a[1] * startInterp + b[1] * finishInterp, a[2] * startInterp + b[2] * finishInterp, a[3] * startInterp + b[3] * finishInterp, a[4] * startInterp + b[4] * finishInterp
end
function rayCast(Pos, Dir, Max, Ignore)
  return game:service("Workspace"):FindPartOnRay(Ray.new(Pos, Dir.unit * (Max or 999.999)), Ignore)
end
function Damagefunc(Part, hit, minim, maxim, knockback, Type, Property, Delay, KnockbackType, decreaseblock)
  if hit.Parent == nil then
    return
  end
  local h = hit.Parent:FindFirstChild("Humanoid")
  for _, v in pairs(hit.Parent:children()) do
    if v:IsA("Humanoid") then
      h = v
    end
  end
  if hit.Parent.Parent:FindFirstChild("Torso") ~= nil then
    h = hit.Parent.Parent:FindFirstChild("Humanoid")
  end
  if hit.Parent.className == "Hat" then
    hit = hit.Parent.Parent:findFirstChild("Head")
  end
  if h ~= nil and hit.Parent.Name ~= Character.Name and hit.Parent:FindFirstChild("Torso") ~= nil then
    if hit.Parent:findFirstChild("DebounceHit") ~= nil and hit.Parent.DebounceHit.Value == true then
      return
    end
    local c = Instance.new("ObjectValue")
    c.Name = "creator"
    c.Value = game:service("Players").LocalPlayer
    c.Parent = h
    game:GetService("Debris"):AddItem(c, 0.5)
    local Damage = math.random(minim, maxim)
    local blocked = false
    local block = hit.Parent:findFirstChild("Block")
    if block ~= nil then
      print(block.className)
      if block.className == "NumberValue" and block.Value > 0 then
        blocked = true
        if decreaseblock == nil then
          block.Value = block.Value - 1
        end
      end
      if block.className == "IntValue" and block.Value > 0 then
        blocked = true
        if decreaseblock ~= nil then
          block.Value = block.Value - 1
        end
      end
    end
    if blocked == false then
      h.Health = h.Health - Damage
      ShowDamage(Part.CFrame * CFrame.new(0, 0, Part.Size.Z / 2).p + Vector3.new(0, 1.5, 0), -Damage, 1.5, Part.BrickColor.Color)
    else
      h.Health = h.Health - Damage / 2
      ShowDamage(Part.CFrame * CFrame.new(0, 0, Part.Size.Z / 2).p + Vector3.new(0, 1.5, 0), -Damage, 1.5, BrickColor.new("White").Color)
    end
    if Type == "Knockdown" then
      local hum = hit.Parent.Humanoid
      hum.PlatformStand = true
      coroutine.resume(coroutine.create(function(HHumanoid)
        swait(1)
        HHumanoid.PlatformStand = false
      end), hum)
      local angle = hit.Position - (Property.Position + Vector3.new(0, 0, 0)).unit
      local bodvol = Instance.new("BodyVelocity")
      bodvol.velocity = angle * knockback
      bodvol.P = 5000
      bodvol.maxForce = Vector3.new(8000, 8000, 8000)
      bodvol.Parent = hit
      local rl = Instance.new("BodyAngularVelocity")
      rl.P = 3000
      rl.maxTorque = Vector3.new(500000, 500000, 500000) * 50000000000000
      rl.angularvelocity = Vector3.new(math.random(-10, 10), math.random(-10, 10), math.random(-10, 10))
      rl.Parent = hit
      game:GetService("Debris"):AddItem(bodvol, 0.5)
      game:GetService("Debris"):AddItem(rl, 0.5)
    elseif Type == "Normal" then
      local vp = Instance.new("BodyVelocity")
      vp.P = 500
      vp.maxForce = Vector3.new(math.huge, 0, math.huge)
      if KnockbackType == 1 then
        vp.velocity = Property.CFrame.lookVector * knockback + Property.Velocity / 1.05
      elseif KnockbackType == 2 then
        vp.velocity = Property.CFrame.lookVector * knockback
      end
      if knockback > 0 then
        vp.Parent = hit.Parent.Torso
      end
      game:GetService("Debris"):AddItem(vp, 0.5)
    elseif Type == "Up" then
      local bodyVelocity = Instance.new("BodyVelocity")
      bodyVelocity.velocity = vt(0, 60, 0)
      bodyVelocity.P = 5000
      bodyVelocity.maxForce = Vector3.new(8000, 8000, 8000)
      bodyVelocity.Parent = hit
      game:GetService("Debris"):AddItem(bodyVelocity, 1)
      local rl = Instance.new("BodyAngularVelocity")
      rl.P = 3000
      rl.maxTorque = Vector3.new(500000, 500000, 500000) * 50000000000000
      rl.angularvelocity = Vector3.new(math.random(-30, 30), math.random(-30, 30), math.random(-30, 30))
      rl.Parent = hit
      game:GetService("Debris"):AddItem(rl, 0.5)
    elseif Type == "Snare" then
      local bp = Instance.new("BodyPosition")
      bp.P = 2000
      bp.D = 100
      bp.maxForce = Vector3.new(math.huge, math.huge, math.huge)
      bp.position = hit.Parent.Torso.Position
      bp.Parent = hit.Parent.Torso
      game:GetService("Debris"):AddItem(bp, 1)
    elseif Type == "Target" then
      local Targetting = false
      if Targetting == false then
        ZTarget = hit.Parent.Torso
        coroutine.resume(coroutine.create(function(Part)
          so("http://www.roblox.com/asset/?id=15666462", Part, 1, 1.5)
          swait(5)
          so("http://www.roblox.com/asset/?id=15666462", Part, 1, 1.5)
        end), ZTarget)
        local TargHum = ZTarget.Parent:findFirstChild("Humanoid")
        local targetgui = Instance.new("BillboardGui")
        targetgui.Parent = ZTarget
        targetgui.Size = UDim2.new(10, 100, 10, 100)
        local targ = Instance.new("ImageLabel")
        targ.Parent = targetgui
        targ.BackgroundTransparency = 1
        targ.Image = "rbxassetid://4834067"
        targ.Size = UDim2.new(1, 0, 1, 0)
        cam.CameraType = "Scriptable"
        cam.CoordinateFrame = CFrame.new(Head.CFrame.p, ZTarget.Position)
        local dir = Vector3.new(cam.CoordinateFrame.lookVector.x, 0, cam.CoordinateFrame.lookVector.z)
        workspace.CurrentCamera.CoordinateFrame = CFrame.new(Head.CFrame.p, ZTarget.Position)
        Targetting = true
        RocketTarget = ZTarget
        for i = 1, Property do
          if 0 < Humanoid.Health and Character.Parent ~= nil and 0 < TargHum.Health and TargHum.Parent ~= nil and Targetting == true then
            swait()
          end
          cam.CoordinateFrame = CFrame.new(Head.CFrame.p, ZTarget.Position)
          dir = Vector3.new(cam.CoordinateFrame.lookVector.x, 0, cam.CoordinateFrame.lookVector.z)
          cam.CoordinateFrame = CFrame.new(Head.CFrame.p, ZTarget.Position) * cf(0, 5, 10) * euler(-0.3, 0, 0)
        end
        Targetting = false
        RocketTarget = nil
        targetgui.Parent = nil
        cam.CameraType = "Custom"
      end
    end
    local debounce = Instance.new("BoolValue")
    debounce.Name = "DebounceHit"
    debounce.Parent = hit.Parent
    debounce.Value = true
    game:GetService("Debris"):AddItem(debounce, Delay)
    c = Instance.new("ObjectValue")
    c.Name = "creator"
    c.Value = Player
    c.Parent = h
    game:GetService("Debris"):AddItem(c, 0.5)
  end
end
function ShowDamage(Pos, Text, Time, Color)
  local Rate = 0.03333333333333333
  local Pos = Pos or Vector3.new(0, 0, 0)
  local Text = Text or ""
  local Time = Time or 2
  local Color = Color or Color3.new(1, 0, 0)
  local EffectPart = part("Custom", workspace, "Neon", 0, 1, BrickColor.new(Color), "Effect", vt(0, 0, 0))
  EffectPart.Anchored = true
  local BillboardGui = Instance.new("BillboardGui")
  BillboardGui.Size = UDim2.new(3, 0, 3, 0)
  BillboardGui.Adornee = EffectPart
  local TextLabel = Instance.new("TextLabel")
  TextLabel.BackgroundTransparency = 1
  TextLabel.Size = UDim2.new(1, 0, 1, 0)
  TextLabel.Text = Text
  TextLabel.TextColor3 = Color
  TextLabel.TextScaled = true
  TextLabel.Font = Enum.Font.ArialBold
  TextLabel.Parent = BillboardGui
  BillboardGui.Parent = EffectPart
  game.Debris:AddItem(EffectPart, Time + 0.1)
  EffectPart.Parent = game:GetService("Workspace")
  Delay(0, function()
    local Frames = Time / Rate
    for Frame = 1, Frames do
      wait(Rate)
      local Percent = Frame / Frames
      EffectPart.CFrame = CFrame.new(Pos) + Vector3.new(0, Percent, 0)
      TextLabel.TextTransparency = Percent
    end
    if EffectPart and EffectPart.Parent then
      EffectPart:Destroy()
    end
  end)
end
function BreakEffect(brickcolor, cframe, x1, y1, z1)
  local prt = part("Custom", workspace, "Neon", 0, 0, VertexRainbow(), "Effect", vt(0.5, 0.5, 0.5))
  prt.Anchored = true
  prt.CFrame = cframe * euler(math.random(-50, 50), math.random(-50, 50), math.random(-50, 50))
  local msh = mesh("SpecialMesh", prt, "Sphere", "", vt(0, 0, 0), vt(x1, y1, z1))
  coroutine.resume(coroutine.create(function(Part, CF, Numbb, randnumb)
    CF = Part.CFrame
    Numbb = 0
    randnumb = math.random() - math.random()
    for i = 0, 1, 0.05 do
      wait()
      CF = CF * cf(0, 1, 0)
      Part.CFrame = CF * euler(Numbb, 0, 0)
      Part.Transparency = i
      Numbb = Numbb + randnumb
    end
    Part.Parent = nil
  end), prt)
end
function attackone()
  attack = true
  local con = Hitbox.Touched:connect(function(hit)
    Damagefunc(Hitbox, hit, 12, 16, math.random(10, 20), "Normal", RootPart, 0.2, 1)
  end)
  for i = 0, 1, 0.1 do
    swait()
    RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(120), math.rad(0), math.rad(20)), 0.3)
    LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(-10), math.rad(-20), math.rad(-90)), 0.3)
    handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0.4) * angles(math.rad(70), math.rad(-10), math.rad(0)), 0.3)
    RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(-70)), 0.3)
    Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(50)), 0.3)
  end
  so("http://www.roblox.com/asset/?id=154965962", Hitbox, 1, 1)
  so("http://www.roblox.com/asset/?id=231917758", Hitbox, 1, 1)
  hitconasdf = Hitbox.Touched:connect(function(hit)
    local Humanoid2 = hit.Parent:FindFirstChild("Humanoid")
    if Humanoid2 and not Humanoid2:IsDescendantOf(Character) then
      so("http://roblox.com/asset/?id=154965973", Hitbox, 1, 1)
      for i = 1, 10 do
        BreakEffect(VertexRainbow(), hit.Parent.Torso.CFrame, 0.5, math.random(5, 20), 0.5)
      end
      hitconasdf:disconnect()
    end
  end)
  for i = 0, 1, 0.1 do
    swait()
    local blcf = Hitbox.CFrame * CFrame.new(0, 0.3, 0)
    if scfr and 0.1 < (Hitbox.Position - scfr.p).magnitude then
      local h = 5
      local a, b = Triangle(scfr * CFrame.new(0, h / 2, 0).p, scfr * CFrame.new(0, -h / 2, 0).p, blcf * CFrame.new(0, h / 2, 0).p)
      if a then
        game.Debris:AddItem(a, 1)
      end
      if b then
        game.Debris:AddItem(b, 1)
      end
      local a, b = Triangle(blcf * CFrame.new(0, h / 2, 0).p, blcf * CFrame.new(0, -h / 2, 0).p, scfr * CFrame.new(0, -h / 2, 0).p)
      if a then
        game.Debris:AddItem(a, 1)
      end
      if b then
        game.Debris:AddItem(b, 1)
      end
      scfr = blcf
    elseif not scfr then
      scfr = blcf
    end
    RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(110), math.rad(-90), math.rad(20)), 0.3)
    LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(-10), math.rad(-20), math.rad(-50)), 0.3)
    handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0) * angles(math.rad(-60), math.rad(-10), math.rad(0)), 0.3)
    RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(90)), 0.3)
    Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(-50)), 0.3)
  end
  attack = false
  con:disconnect()
  scfr = nil
  pcall(function()
    hitconasdf:disconnect()
  end)
end
function attacktwo()
  attack = true
  local con = Hitbox.Touched:connect(function(hit)
    Damagefunc(Hitbox, hit, 12, 16, math.random(10, 20), "Normal", RootPart, 0.2, 1)
  end)
  for i = 0, 1, 0.1 do
    swait()
    RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(0), math.rad(90), math.rad(90)), 0.3)
    LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(-10), math.rad(-20), math.rad(-50)), 0.3)
    handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0) * angles(math.rad(-30), math.rad(-10), math.rad(0)), 0.3)
    RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(70)), 0.3)
    Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(-50)), 0.3)
  end
  so("http://www.roblox.com/asset/?id=154965962", Hitbox, 1, 0.9)
  so("http://www.roblox.com/asset/?id=231917758", Hitbox, 1, 0.9)
  hitconasdf = Hitbox.Touched:connect(function(hit)
    local Humanoid2 = hit.Parent:FindFirstChild("Humanoid")
    if Humanoid2 and not Humanoid2:IsDescendantOf(Character) then
      so("http://roblox.com/asset/?id=154965973", Hitbox, 1, 1)
      for i = 1, 10 do
        BreakEffect(VertexRainbow(), hit.Parent.Torso.CFrame, 0.5, math.random(5, 20), 0.5)
      end
      hitconasdf:disconnect()
    end
  end)
  for i = 0, 1, 0.1 do
    swait()
    local blcf = Hitbox.CFrame * CFrame.new(0, 0.3, 0)
    if scfr and 0.1 < (Hitbox.Position - scfr.p).magnitude then
      local h = 5
      local a, b = Triangle(scfr * CFrame.new(0, h / 2, 0).p, scfr * CFrame.new(0, -h / 2, 0).p, blcf * CFrame.new(0, h / 2, 0).p)
      if a then
        game.Debris:AddItem(a, 1)
      end
      if b then
        game.Debris:AddItem(b, 1)
      end
      local a, b = Triangle(blcf * CFrame.new(0, h / 2, 0).p, blcf * CFrame.new(0, -h / 2, 0).p, scfr * CFrame.new(0, -h / 2, 0).p)
      if a then
        game.Debris:AddItem(a, 1)
      end
      if b then
        game.Debris:AddItem(b, 1)
      end
      scfr = blcf
    elseif not scfr then
      scfr = blcf
    end
    RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(0), math.rad(-50), math.rad(90)), 0.3)
    LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(-10), math.rad(-20), math.rad(-90)), 0.3)
    handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0) * angles(math.rad(-50), math.rad(10), math.rad(0)), 0.3)
    RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(-70)), 0.3)
    Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(50)), 0.3)
  end
  attack = false
  con:disconnect()
  scfr = nil
  pcall(function()
    hitconasdf:disconnect()
  end)
end
function busterattackone()
  attack = true
  for i = 1, 10 do
    swait()
    LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(0), math.rad(-120), math.rad(-90)), 0.3)
    LH.C0 = clerp(LH.C0, cf(-1, -1, 0) * angles(math.rad(0), math.rad(-50), math.rad(-5)) * angles(math.rad(-5), math.rad(0), math.rad(0)), 0.3)
    RH.C0 = clerp(RH.C0, cf(1, -1, 0) * angles(math.rad(0), math.rad(130), math.rad(-10)) * angles(math.rad(-5), math.rad(0), math.rad(0)), 0.3)
    if R == "Sword" then
      RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(40), math.rad(0), math.rad(20)), 0.3)
      handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0.4) * angles(math.rad(85), math.rad(-10), math.rad(0)), 0.3)
    end
    RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(-70)), 0.3)
    Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(70)), 0.3)
    HandleBweld.C0 = clerp(HandleBweld.C0, cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(0)), 0.3)
  end
  MagniDamage(Torso, 10, 6, 12, true)
  so("http://www.roblox.com/asset/?id=320557563", BarrelB, 1, 0.9)
  for i = 1, 10 do
    swait()
    if R == "Sword" then
      RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(40), math.rad(0), math.rad(20)), 0.3)
      handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0.4) * angles(math.rad(85), math.rad(-10), math.rad(0)), 0.3)
    end
    LW.C0 = clerp(LW.C0, cf(-1, 0.5, 0) * euler(math.rad(0), math.rad(0), math.rad(-90)), 0.3)
    RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(70)), 0.3)
    Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(-70)), 0.3)
    HandleBweld.C0 = clerp(HandleBweld.C0, cf(0, 0, 0.5) * angles(math.rad(30), math.rad(0), math.rad(0)), 0.3)
  end
  attack = false
end
function bustershot()
  attack = true
  for i = 1, 10 do
    swait()
    LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(90), math.rad(0), math.rad(-90)), 0.3)
    LH.C0 = clerp(LH.C0, cf(-1, -1, 0) * angles(math.rad(0), math.rad(-50), math.rad(-5)) * angles(math.rad(-5), math.rad(0), math.rad(0)), 0.3)
    RH.C0 = clerp(RH.C0, cf(1, -1, 0) * angles(math.rad(0), math.rad(130), math.rad(-10)) * angles(math.rad(-5), math.rad(0), math.rad(0)), 0.3)
    if R == "Sword" then
      RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(40), math.rad(0), math.rad(20)), 0.3)
      handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0.4) * angles(math.rad(85), math.rad(-10), math.rad(0)), 0.3)
    end
    RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(-90)), 0.3)
    Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(90)), 0.3)
    HandleBweld.C0 = clerp(HandleBweld.C0, cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(0)), 0.3)
  end
  LaserBarrage(BarrelB, m)
  for i = 1, 10 do
    swait()
    if R == "Sword" then
      RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(40), math.rad(0), math.rad(20)), 0.3)
      handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0.4) * angles(math.rad(85), math.rad(-10), math.rad(0)), 0.3)
    end
    LW.C0 = clerp(LW.C0, cf(-1, 0.5, 0) * euler(math.rad(90), math.rad(0), math.rad(-90)), 0.3)
    RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(-90)), 0.3)
    Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(90)), 0.3)
    HandleBweld.C0 = clerp(HandleBweld.C0, cf(0, 0, 0.5) * angles(math.rad(30), math.rad(0), math.rad(0)), 0.3)
  end
  attack = false
end
function busterattackthree()
  attack = true
  for i = 1, 3 do
    swait()
    LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(90), math.rad(50), math.rad(-90)), 0.3)
    LH.C0 = clerp(LH.C0, cf(-1, -1, 0) * angles(math.rad(0), math.rad(-50), math.rad(-5)) * angles(math.rad(-5), math.rad(0), math.rad(0)), 0.3)
    RH.C0 = clerp(RH.C0, cf(1, -1, 0) * angles(math.rad(0), math.rad(130), math.rad(-10)) * angles(math.rad(-5), math.rad(0), math.rad(0)), 0.3)
    if R == "Sword" then
      RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(40), math.rad(0), math.rad(20)), 0.3)
      handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0.4) * angles(math.rad(85), math.rad(-10), math.rad(0)), 0.3)
    end
    RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(-90)), 0.3)
    Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(90)), 0.3)
    HandleBweld.C0 = clerp(HandleBweld.C0, cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(0)), 0.3)
  end
  LaserBarrage(BarrelB, m)
  for i = 1, 3 do
    swait()
    if R == "Sword" then
      RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(40), math.rad(0), math.rad(20)), 0.3)
      handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0.4) * angles(math.rad(85), math.rad(-10), math.rad(0)), 0.3)
    end
    LW.C0 = clerp(LW.C0, cf(-1, 0.5, 0) * euler(math.rad(90), math.rad(50), math.rad(-90)), 0.3)
    RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(-90)), 0.3)
    Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(90)), 0.3)
    HandleBweld.C0 = clerp(HandleBweld.C0, cf(0, 0, 0.5) * angles(math.rad(30), math.rad(0), math.rad(0)), 0.3)
  end
  for i = 1, 3 do
    swait()
    LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(90), math.rad(0), math.rad(-90)), 0.3)
    LH.C0 = clerp(LH.C0, cf(-1, -1, 0) * angles(math.rad(0), math.rad(-50), math.rad(-5)) * angles(math.rad(-5), math.rad(0), math.rad(0)), 0.3)
    RH.C0 = clerp(RH.C0, cf(1, -1, 0) * angles(math.rad(0), math.rad(130), math.rad(-10)) * angles(math.rad(-5), math.rad(0), math.rad(0)), 0.3)
    if R == "Sword" then
      RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(40), math.rad(0), math.rad(20)), 0.3)
      handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0.4) * angles(math.rad(85), math.rad(-10), math.rad(0)), 0.3)
    end
    RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(-90)), 0.3)
    Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(90)), 0.3)
    HandleBweld.C0 = clerp(HandleBweld.C0, cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(0)), 0.3)
  end
  LaserBarrage(BarrelB, m)
  for i = 1, 3 do
    swait()
    if R == "Sword" then
      RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(40), math.rad(0), math.rad(20)), 0.3)
      handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0.4) * angles(math.rad(85), math.rad(-10), math.rad(0)), 0.3)
    end
    LW.C0 = clerp(LW.C0, cf(-1, 0.5, 0) * euler(math.rad(90), math.rad(0), math.rad(-90)), 0.3)
    RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(-90)), 0.3)
    Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(90)), 0.3)
    HandleBweld.C0 = clerp(HandleBweld.C0, cf(0, 0, 0.5) * angles(math.rad(30), math.rad(0), math.rad(0)), 0.3)
  end
  for i = 1, 3 do
    swait()
    LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(90), math.rad(-50), math.rad(-90)), 0.3)
    LH.C0 = clerp(LH.C0, cf(-1, -1, 0) * angles(math.rad(0), math.rad(-50), math.rad(-5)) * angles(math.rad(-5), math.rad(0), math.rad(0)), 0.3)
    RH.C0 = clerp(RH.C0, cf(1, -1, 0) * angles(math.rad(0), math.rad(130), math.rad(-10)) * angles(math.rad(-5), math.rad(0), math.rad(0)), 0.3)
    if R == "Sword" then
      RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(40), math.rad(0), math.rad(20)), 0.3)
      handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0.4) * angles(math.rad(85), math.rad(-10), math.rad(0)), 0.3)
    end
    RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(-90)), 0.3)
    Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(90)), 0.3)
    HandleBweld.C0 = clerp(HandleBweld.C0, cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(0)), 0.3)
  end
  LaserBarrage(BarrelB, m)
  for i = 1, 3 do
    swait()
    if R == "Sword" then
      RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(40), math.rad(0), math.rad(20)), 0.3)
      handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0.4) * angles(math.rad(85), math.rad(-10), math.rad(0)), 0.3)
    end
    LW.C0 = clerp(LW.C0, cf(-1, 0.5, 0) * euler(math.rad(90), math.rad(-50), math.rad(-90)), 0.3)
    RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(-90)), 0.3)
    Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(90)), 0.3)
    HandleBweld.C0 = clerp(HandleBweld.C0, cf(0, 0, 0.5) * angles(math.rad(30), math.rad(0), math.rad(0)), 0.3)
  end
  attack = false
end
function MagicRing(brickcolor, cframe, x1, y1, z1, x3, y3, z3)
  local prt = part(3, workspace, "SmoothPlastic", 0, 0, brickcolor, "Effect", vt(0.5, 0.5, 0.5))
  prt.Anchored = true
  prt.CFrame = cframe
  local msh = mesh("SpecialMesh", prt, "FileMesh", "http://www.roblox.com/asset/?id=3270017", vt(0, 0, 0), vt(x1, y1, z1))
  coroutine.resume(coroutine.create(function(Part, Mesh)
    for i = 0, 1, 0.03 do
      wait()
      Part.CFrame = Part.CFrame
      Part.Transparency = i
      Mesh.Scale = Mesh.Scale + vt(x3, y3, z3)
    end
    Part.Parent = nil
  end), prt, msh)
end
function busterattacktwo()
  attack = true
  for i = 1, 10 do
    swait()
    LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(90), math.rad(0), math.rad(-90)), 0.3)
    LH.C0 = clerp(LH.C0, cf(-1, -1, 0) * angles(math.rad(0), math.rad(-50), math.rad(-5)) * angles(math.rad(-5), math.rad(0), math.rad(0)), 0.3)
    RH.C0 = clerp(RH.C0, cf(1, -1, 0) * angles(math.rad(0), math.rad(130), math.rad(-10)) * angles(math.rad(-5), math.rad(0), math.rad(0)), 0.3)
    if R == "Sword" then
      RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(40), math.rad(0), math.rad(20)), 0.3)
      handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0.4) * angles(math.rad(85), math.rad(-10), math.rad(0)), 0.3)
    end
    RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(-90)), 0.3)
    Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(90)), 0.3)
    HandleBweld.C0 = clerp(HandleBweld.C0, cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(0)), 0.3)
  end
  if 0 < busterammo then
    busterammo = busterammo - 1
    MagicRing(BrickColor.new("White"), BarrelB.CFrame * euler(math.random(-50, 50), math.random(-50, 50), math.random(-50, 50)), 0.5, 0.5, 0.5, 0.6, 0.6, 0.6)
    MagicCircle(BrickColor.new("White"), BarrelB.CFrame, 1, 1, 1, 2, 2, 2, 0.05)
    MagniDamage(BarrelB, 5, 6, 12, true, 50)
    so("http://www.roblox.com/asset/?id=203691837", BarrelB, 1, 0.9)
  else
    so("http://www.roblox.com/asset/?id=203691822", BarrelB, 1, 0.9)
  end
  for i = 1, 10 do
    swait()
    if R == "Sword" then
      RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(40), math.rad(0), math.rad(20)), 0.3)
      handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0.4) * angles(math.rad(85), math.rad(-10), math.rad(0)), 0.3)
    end
    LW.C0 = clerp(LW.C0, cf(-1, 0.5, 0) * euler(math.rad(90), math.rad(0), math.rad(-90)), 0.3)
    RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(-90)), 0.3)
    Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(90)), 0.3)
    HandleBweld.C0 = clerp(HandleBweld.C0, cf(0, 0, 0.5) * angles(math.rad(30), math.rad(0), math.rad(0)), 0.3)
  end
  attack = false
end
function Stab()
  attack = true
  local con = Hitbox.Touched:connect(function(hit)
    Damagefunc(Hitbox, hit, 12, 16, math.random(10, 20), "Normal", RootPart, 0.2, 1)
  end)
  for i = 0, 1, 0.1 do
    swait()
    RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(-70)), 0.3)
    Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(10), math.rad(0), math.rad(60)), 0.3)
    RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * angles(math.rad(0), math.rad(20), math.rad(90)), 0.3)
    LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * angles(math.rad(0), math.rad(-20), math.rad(-90)), 0.3)
    handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0) * angles(math.rad(20), math.rad(0), math.rad(0)), 0.3)
  end
  hitconasdf = Hitbox.Touched:connect(function(hit)
    local Humanoid2 = hit.Parent:FindFirstChild("Humanoid")
    if Humanoid2 and not Humanoid2:IsDescendantOf(Character) then
      so("http://roblox.com/asset/?id=154965973", Hitbox, 1, 1)
      for i = 1, 10 do
        BreakEffect(VertexRainbow(), hit.Parent.Torso.CFrame, 0.5, math.random(5, 20), 0.5)
      end
      hitconasdf:disconnect()
    end
  end)
  so("http://www.roblox.com/asset/?id=154965962", Hitbox, 1, 0.9)
  so("http://www.roblox.com/asset/?id=231917758", Hitbox, 1, 0.9)
  for i = 0, 1, 0.1 do
    swait()
    local blcf = Hitbox.CFrame * CFrame.new(0, 0.3, 0)
    if scfr and 0.1 < (Hitbox.Position - scfr.p).magnitude then
      local h = 5
      local a, b = Triangle(scfr * CFrame.new(0, h / 2, 0).p, scfr * CFrame.new(0, -h / 2, 0).p, blcf * CFrame.new(0, h / 2, 0).p)
      if a then
        game.Debris:AddItem(a, 1)
      end
      if b then
        game.Debris:AddItem(b, 1)
      end
      local a, b = Triangle(blcf * CFrame.new(0, h / 2, 0).p, blcf * CFrame.new(0, -h / 2, 0).p, scfr * CFrame.new(0, -h / 2, 0).p)
      if a then
        game.Debris:AddItem(a, 1)
      end
      if b then
        game.Debris:AddItem(b, 1)
      end
      scfr = blcf
    elseif not scfr then
      scfr = blcf
    end
    RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(90)), 0.4)
    Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(10), math.rad(0), math.rad(-80)), 0.4)
    RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * angles(math.rad(0), math.rad(0), math.rad(90)), 0.4)
    LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * angles(math.rad(0), math.rad(-20), math.rad(-30)), 0.4)
    handleweld.C0 = clerp(handleweld.C0, cf(0, -1, -1) * angles(math.rad(-90), math.rad(0), math.rad(0)), 0.4)
  end
  con:disconnect()
  attack = false
  scfr = nil
  pcall(function()
    hitconasdf:disconnect()
  end)
end
function Spin()
  attack = true
  Humanoid.WalkSpeed = 32
  local con = Hitbox.Touched:connect(function(hit)
    Damagefunc(Hitbox, hit, 12, 16, math.random(10, 20), "Normal", RootPart, 0.2, 1)
  end)
  hitconasdf = Hitbox.Touched:connect(function(hit)
    local Humanoid2 = hit.Parent:FindFirstChild("Humanoid")
    if Humanoid2 and not Humanoid2:IsDescendantOf(Character) then
      so("http://roblox.com/asset/?id=154965973", Hitbox, 1, 1)
      for i = 1, 10 do
        BreakEffect(VertexRainbow(), hit.Parent.Torso.CFrame, 0.5, math.random(5, 20), 0.5)
      end
      hitconasdf:disconnect()
    end
  end)
  for i = 0, 1 do
    so("http://roblox.com/asset/?id=154965962", Hitbox, 1, 1)
    so("http://www.roblox.com/asset/?id=231917758", Hitbox, 1, 1)
    swait()
    for i = 0, 1, 0.1 do
      swait()
      local blcf = Hitbox.CFrame * CFrame.new(0, 0.3, 0)
      if scfr and 0.1 < (Hitbox.Position - scfr.p).magnitude then
        local h = 5
        local a, b = Triangle(scfr * CFrame.new(0, h / 2, 0).p, scfr * CFrame.new(0, -h / 2, 0).p, blcf * CFrame.new(0, h / 2, 0).p)
        if a then
          game.Debris:AddItem(a, 1)
        end
        if b then
          game.Debris:AddItem(b, 1)
        end
        local a, b = Triangle(blcf * CFrame.new(0, h / 2, 0).p, blcf * CFrame.new(0, -h / 2, 0).p, scfr * CFrame.new(0, -h / 2, 0).p)
        if a then
          game.Debris:AddItem(a, 1)
        end
        if b then
          game.Debris:AddItem(b, 1)
        end
        scfr = blcf
      elseif not scfr then
        scfr = blcf
      end
      RW.C0 = clerp(RW.C0, cf(1, 0.5, -0.5) * angles(math.rad(90), math.rad(0), math.rad(-50)), 0.3)
      LW.C0 = clerp(LW.C0, cf(-1, 0.5, -0.5) * angles(math.rad(90), math.rad(0), math.rad(50)), 0.3)
      LH.C0 = clerp(LH.C0, cf(-1, -0.5, -1) * angles(math.rad(-20), math.rad(-90), math.rad(0)), 0.3)
      RH.C0 = clerp(RH.C0, cf(1, -0.5, -1) * angles(math.rad(-20), math.rad(90), math.rad(0)), 0.3)
      RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 5) * euler(6 * i, 0, 0), 0.5)
      Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(10), math.rad(0), math.rad(0)), 0.3)
      handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(30)), 1)
    end
  end
  attack = false
  con:disconnect()
  scfr = nil
  pcall(function()
    hitconasdf:disconnect()
    Humanoid.WalkSpeed = 20
  end)
end
function ContAttack()
  attack = true
  local con = Hitbox.Touched:connect(function(hit)
    Damagefunc(Hitbox, hit, 12, 16, math.random(10, 20), "Normal", RootPart, 0.2, 1)
  end)
  hitconasdf = Hitbox.Touched:connect(function(hit)
    local Humanoid2 = hit.Parent:FindFirstChild("Humanoid")
    if Humanoid2 and not Humanoid2:IsDescendantOf(Character) then
      so("http://roblox.com/asset/?id=154965973", Hitbox, 1, 1)
      for i = 1, 10 do
        BreakEffect(VertexRainbow(), hit.Parent.Torso.CFrame, 0.5, math.random(5, 20), 0.5)
      end
      hitconasdf:disconnect()
    end
  end)
  for i = 1, 4 do
    swait()
    for i = 0, 1, 0.2 do
      swait()
      RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(120), math.rad(0), math.rad(20)), 0.3)
      LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(-10), math.rad(-20), math.rad(-90)), 0.3)
      handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0.4) * angles(math.rad(70), math.rad(-10), math.rad(0)), 0.3)
      RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(-70)), 0.3)
      Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(50)), 0.3)
    end
    so("http://www.roblox.com/asset/?id=154965962", Hitbox, 1, 1)
    so("http://www.roblox.com/asset/?id=231917758", Hitbox, 1, 1)
    for i = 0, 1, 0.2 do
      swait()
      local blcf = Hitbox.CFrame * CFrame.new(0, 0.3, 0)
      if scfr and (Hitbox.Position - scfr.p).magnitude > 0.1 then
        local h = 5
        local a, b = Triangle(scfr * CFrame.new(0, h / 2, 0).p, scfr * CFrame.new(0, -h / 2, 0).p, blcf * CFrame.new(0, h / 2, 0).p)
        if a then
          game.Debris:AddItem(a, 1)
        end
        if b then
          game.Debris:AddItem(b, 1)
        end
        local a, b = Triangle(blcf * CFrame.new(0, h / 2, 0).p, blcf * CFrame.new(0, -h / 2, 0).p, scfr * CFrame.new(0, -h / 2, 0).p)
        if a then
          game.Debris:AddItem(a, 1)
        end
        if b then
          game.Debris:AddItem(b, 1)
        end
        scfr = blcf
      elseif not scfr then
        scfr = blcf
      end
      RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(110), math.rad(-90), math.rad(20)), 0.3)
      LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(-10), math.rad(-20), math.rad(-50)), 0.3)
      handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0) * angles(math.rad(-60), math.rad(-10), math.rad(0)), 0.3)
      RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(90)), 0.3)
      Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(-50)), 0.3)
    end
    for i = 0, 1, 0.2 do
      swait()
      RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(0), math.rad(90), math.rad(90)), 0.3)
      LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(-10), math.rad(-20), math.rad(-50)), 0.3)
      handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0) * angles(math.rad(-30), math.rad(-10), math.rad(0)), 0.3)
      RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(70)), 0.3)
      Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(-50)), 0.3)
    end
    so("http://www.roblox.com/asset/?id=154965962", Hitbox, 1, 0.9)
    so("http://www.roblox.com/asset/?id=231917758", Hitbox, 1, 0.9)
    for i = 0, 1, 0.2 do
      swait()
      local blcf = Hitbox.CFrame * CFrame.new(0, 0.3, 0)
      if scfr and (Hitbox.Position - scfr.p).magnitude > 0.1 then
        local h = 5
        local a, b = Triangle(scfr * CFrame.new(0, h / 2, 0).p, scfr * CFrame.new(0, -h / 2, 0).p, blcf * CFrame.new(0, h / 2, 0).p)
        if a then
          game.Debris:AddItem(a, 1)
        end
        if b then
          game.Debris:AddItem(b, 1)
        end
        local a, b = Triangle(blcf * CFrame.new(0, h / 2, 0).p, blcf * CFrame.new(0, -h / 2, 0).p, scfr * CFrame.new(0, -h / 2, 0).p)
        if a then
          game.Debris:AddItem(a, 1)
        end
        if b then
          game.Debris:AddItem(b, 1)
        end
        scfr = blcf
      elseif not scfr then
        scfr = blcf
      end
      RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(0), math.rad(-50), math.rad(90)), 0.3)
      LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(-10), math.rad(-20), math.rad(-90)), 0.3)
      handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0) * angles(math.rad(-50), math.rad(10), math.rad(0)), 0.3)
      RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(-70)), 0.3)
      Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(50)), 0.3)
    end
  end
  attack = false
  con:disconnect()
  scfr = nil
  pcall(function()
    hitconasdf:disconnect()
  end)
end
function Sheathe()
  attack = true
  so("http://www.roblox.com/asset/?id=273797222", Hitbox, 1, 0.9)
  for i = 0, 1, 0.1 do
    swait()
    RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(0)), 0.3)
    Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(-10), math.rad(0), math.rad(-20)), 0.3)
    RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(190), math.rad(0), math.rad(0)), 0.3)
    LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(-10), math.rad(20), math.rad(-10)), 0.3)
  end
  handleweld.Part0 = Torso
  R = ""
  attack = false
end
function Unsheathe()
  attack = true
  R = "Sword"
  so("http://www.roblox.com/asset/?id=239169404", Hitbox, 1, 0.9)
  for i = 0, 1, 0.1 do
    swait()
    handleweld.Part0 = RightArm
    RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(-70)), 0.3)
    Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(60)), 0.3)
    RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(200), math.rad(0), math.rad(0)), 0.3)
    LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(0), math.rad(-30), math.rad(-30)), 0.3)
  end
  scfr = nil
  attack = false
end
function BusterOn()
  attack = true
  for i = 0, 1, 0.1 do
    swait()
    RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(70)), 0.3)
    Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(-60)), 0.3)
    RH.C0 = clerp(RH.C0, cf(1, -1, 0) * angles(math.rad(0), math.rad(90), math.rad(-10)) * angles(math.rad(-5), math.rad(0), math.rad(0)), 0.3)
    LW.C0 = clerp(LW.C0, cf(-1.5, 0, 0) * euler(math.rad(-20), math.rad(-30), math.rad(30)), 0.3)
  end
  L = "Buster"
  so("http://www.roblox.com/asset/?id=250890848", BarrelB, 1, 1)
  scfr = nil
  attack = false
end
function BusterOff()
  attack = true
  for i = 0, 1, 0.1 do
    swait()
    RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(-70)), 0.3)
    Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(60)), 0.3)
    RH.C0 = clerp(RH.C0, cf(1, -1, 0) * angles(math.rad(0), math.rad(90), math.rad(-10)) * angles(math.rad(-5), math.rad(0), math.rad(0)), 0.3)
    LW.C0 = clerp(LW.C0, cf(-1.5, 0, 0) * euler(math.rad(-20), math.rad(-30), math.rad(30)), 0.3)
    HandleBweld.C0 = clerp(HandleBweld.C0, cf(-2.5, -2, 0.5) * angles(0, -1.6, 0) * angles(1.5, 0, 0), 0.3)
  end
  L = ""
  so("http://www.roblox.com/asset/?id=250890848", BarrelB, 1, 1)
  attack = false
end
function Reload()
  if L == "Buster" and busterammo ~= maxbusterammo then
    attack = true
    Humanoid.WalkSpeed = 0
    Humanoid.JumpPower = 0
    so("http://www.roblox.com/asset/?id=141645761", BarrelB, 1, 0.9)
    for i = 1, 20 do
      swait()
      LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(90), math.rad(0), math.rad(40)), 0.3)
      RW.C0 = clerp(RW.C0, cf(1, 0.5, -1) * euler(math.rad(90), math.rad(0), math.rad(-70)), 0.3)
      RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(0)), 0.3)
      Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(20), math.rad(0), math.rad(30)), 0.3)
      HandleBweld.C0 = clerp(HandleBweld.C0, cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(0)), 0.3)
    end
    busterammo = maxbusterammo
    for i = 1, 25 do
      swait()
      LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(90), math.rad(0), math.rad(40)), 0.3)
      RW.C0 = clerp(RW.C0, cf(1, 0.5, -1) * euler(math.rad(60), math.rad(0), math.rad(-10)), 0.3)
      RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(0)), 0.3)
      Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(20), math.rad(0), math.rad(30)), 0.3)
      HandleBweld.C0 = clerp(HandleBweld.C0, cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(0)), 0.3)
    end
    for i = 1, 30 do
      swait()
      LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(90), math.rad(0), math.rad(40)), 0.3)
      RW.C0 = clerp(RW.C0, cf(1, 0.5, -1) * euler(math.rad(90), math.rad(0), math.rad(-70)), 0.3)
      RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(0)), 0.3)
      Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(20), math.rad(0), math.rad(30)), 0.3)
      HandleBweld.C0 = clerp(HandleBweld.C0, cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(0)), 0.3)
    end
    for i = 1, 30 do
      swait()
      LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(90), math.rad(0), math.rad(40)), 0.3)
      RW.C0 = clerp(RW.C0, cf(1, 0.5, -1) * euler(math.rad(180), math.rad(0), math.rad(-70)), 0.3)
      RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(0)), 0.3)
      Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(20), math.rad(0), math.rad(30)), 0.3)
      HandleBweld.C0 = clerp(HandleBweld.C0, cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(0)), 0.3)
    end
    for i = 1, 30 do
      swait()
      LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(90), math.rad(0), math.rad(40)), 0.3)
      RW.C0 = clerp(RW.C0, cf(1, 0.5, -1) * euler(math.rad(60), math.rad(0), math.rad(-70)), 0.3)
      RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(0)), 0.3)
      Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(20), math.rad(0), math.rad(30)), 0.3)
      HandleBweld.C0 = clerp(HandleBweld.C0, cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(0)), 0.3)
    end
    Humanoid.WalkSpeed = 16
    Humanoid.JumpPower = 50
    attack = false
  end
end
local Sit = false
mouse.Button1Down:connect(function()
  if gun then
    shoot = true
    gun = false
  end
  if R == "" and L == "" then
    return
  end
  if attack == false then
    if attacktype == 1 then
      attack = true
      attacktype = 2
      if R == "Sword" then
        attackone()
      end
      if L == "Buster" and R ~= "Sword" then
        busterattackone()
      end
    elseif attacktype == 2 then
      attack = true
      attacktype = 3
      if L == "Buster" and R ~= "Sword" then
        busterattacktwo()
      end
      if L ~= "Buster" then
        attacktype = 1
      end
      if R == "Sword" then
        attacktwo()
      end
    elseif attacktype == 3 then
      attack = true
      attacktype = 1
      if L == "Buster" and R == "Sword" then
        busterattackone()
        bustershot()
      end
      if L == "Buster" and R ~= "Sword" then
        busterattackthree()
      end
      attack = false
    end
  end
end)
mouse.KeyUp:connect(function(key)
end)
function Aim()
  if gun then
    attack = true
    local gyro = Instance.new("BodyGyro")
    gyro.Parent = RootPart
    gyro.maxTorque = Vector3.new(0, math.huge, 0)
    gyro.P = 20000
    gyro.cframe = RootPart.CFrame
    while gun do
      swait()
      local gunpos = vt(Mouse.Hit.p.x, Head.Position.Y, Mouse.Hit.p.z)
      local offset = (Torso.Position.y - Mouse.Hit.p.y) / 60
      local mag = (Torso.Position - Mouse.Hit.p).magnitude / 80
      offset = offset / mag
      gyro.CFrame = cf(RootPart.Position, Mouse.Hit.p)
      Neck.C0 = clerp(Neck.C0, necko * euler(0, offset / 2, 1.57), 0.3)
      LW.C1 = clerp(LW.C1, cf(0, 0.5, 0) * euler(offset, 0, 0), 0.2)
      if R == "Sword" then
        handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0.4) * angles(math.rad(85), math.rad(-10), math.rad(0)), 0.3)
        RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(40), math.rad(0), math.rad(20)), 0.3)
      else
      end
      LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(90), math.rad(0), math.rad(-90)), 0.3)
      RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(-90)), 0.3)
      Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(90)), 0.3)
      HandleBweld.C0 = clerp(HandleBweld.C0, cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(0)), 0.3)
    end
    if shoot then
      LaserBarrage(BarrelB, m)
      for i = 1, 10 do
        swait()
        if R == "Sword" then
          handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0.4) * angles(math.rad(85), math.rad(-10), math.rad(0)), 0.3)
          RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(40), math.rad(0), math.rad(20)), 0.3)
        end
        if R ~= "Sword" then
          RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(0), math.rad(0), math.rad(5)), 0.3)
        end
        LW.C0 = clerp(LW.C0, cf(-1, 0.5, 0) * euler(math.rad(90), math.rad(0), math.rad(-90)), 0.3)
        RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(-90)), 0.3)
        Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(90)), 0.3)
        HandleBweld.C0 = clerp(HandleBweld.C0, cf(0, 0, 0.5) * angles(math.rad(30), math.rad(0), math.rad(0)), 0.3)
      end
      for i = 1, 10 do
        swait()
        LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(0), math.rad(0), math.rad(0)), 0.3)
      end
    end
    gyro:Remove()
    attack = false
  end
end
mouse.KeyDown:connect(function(k)
  k = k:lower()
  if k == "r" and attack == false then
    if R == "Sword" then
      Sheathe()
      swait(30)
    end
    Reload()
  end
  if k == "z" then
    if attack == false and R == "Sword" then
      Stab()
    end
  elseif k == "x" then
    if attack == false and R == "Sword" then
      Spin()
    end
  elseif k == "c" then
    if attack == false and R == "Sword" then
      ContAttack()
    end
  elseif k == "h" then
    if attack == false and R == "Sword" then
      Sheathe()
    elseif k == "h" and attack == false and Sit == false and R == "" then
      Unsheathe()
    end
  elseif k == "j" then
    if attack == false and L == "" then
      BusterOn()
    elseif k == "j" and attack == false and Sit == false and L == "Buster" then
      BusterOff()
    end
  elseif k == "e" then
    if attack == false and Sit == false and R == "" and L == "" then
      Sit = true
      Humanoid.WalkSpeed = 0
    elseif k == "e" and attack == false and Sit == true and R == "" and L == "" then
      Sit = false
      Humanoid.WalkSpeed = 16
    end
  end
end)
local sine = 0
local change = 1
local val = 0
function effect(Color, Ref, LP, P1, returnn)
  if LP == nil or P1 == nil then
    return
  end
  local effectsmsh = Instance.new("CylinderMesh")
  effectsmsh.Scale = Vector3.new(0.2, 1, 0.2)
  effectsmsh.Name = "Mesh"
  local effectsg = Instance.new("Part")
  NoOutline(effectsg)
  effectsg.formFactor = 3
  effectsg.CanCollide = false
  effectsg.Name = "Eff"
  effectsg.Locked = true
  effectsg.Anchored = true
  effectsg.Size = Vector3.new(0.5, 1, 0.5)
  effectsg.Parent = workspace
  effectsmsh.Parent = effectsg
  effectsg.BrickColor = BrickColor.new(Color)
  effectsg.Reflectance = Ref
  local point1 = P1
  local mg = (LP.p - point1.p).magnitude
  effectsg.Size = Vector3.new(0.5, mg, 0.5)
  effectsg.CFrame = cf((LP.p + point1.p) / 2, point1.p) * CFrame.Angles(math.rad(90), 0, 0)
  effectsmsh.Scale = Vector3.new(0.2, 1, 0.2)
  game:GetService("Debris"):AddItem(effectsg, 2)
  if returnn then
    return effectsg
  end
  if not returnn then
    table.insert(Effects, {
      effectsg,
      "Cylinder",
      0.2,
      0.01,
      0,
      0.01,
      effectsmsh
    })
  end
end
function MagicCircle(brickcolor, cframe, x1, y1, z1, x3, y3, z3, delay)
  local prt = part(3, workspace, "SmoothPlastic", 0, 0, brickcolor, "Effect", vt())
  prt.Anchored = true
  prt.CFrame = cframe
  local msh = mesh("SpecialMesh", prt, "Sphere", "", vt(0, 0, 0), vt(x1, y1, z1))
  game:GetService("Debris"):AddItem(prt, 2)
  table.insert(Effects, {
    prt,
    "Cylinder",
    delay,
    x3,
    y3,
    z3,
    msh
  })
end
function MagicCylinder(brickcolor, cframe, x1, y1, z1, x3, y3, z3, delay)
  local prt = part(3, workspace, "SmoothPlastic", 0, 0, brickcolor, "Effect", vt())
  prt.Anchored = true
  prt.CFrame = cframe
  local msh = mesh("CylinderMesh", prt, "", "", vt(0, 0, 0), vt(x1, y1, z1))
  game:GetService("Debris"):AddItem(prt, 2)
  table.insert(Effects, {
    prt,
    "Cylinder",
    delay,
    x3,
    y3,
    z3,
    msh
  })
end
function MagicHead(brickcolor, cframe, x1, y1, z1, x3, y3, z3, delay)
  local prt = part(3, workspace, "SmoothPlastic", 0, 0, brickcolor, "Effect", vt())
  prt.Anchored = true
  prt.CFrame = cframe
  local msh = mesh("SpecialMesh", prt, "Head", "", vt(0, 0, 0), vt(x1, y1, z1))
  game:GetService("Debris"):AddItem(prt, 2)
  table.insert(Effects, {
    prt,
    "Cylinder",
    delay,
    x3,
    y3,
    z3,
    msh
  })
end
Humanoid.Animator:Remove()
Character.Animate:Remove()
walk = false
while true do
  swait()
  sine = sine + change
  local torvel = (RootPart.Velocity * Vector3.new(1, 0, 1)).magnitude
  local velderp = RootPart.Velocity.y
  hitfloor, posfloor = rayCast(RootPart.Position, CFrame.new(RootPart.Position, RootPart.Position - Vector3.new(0, 1, 0)).lookVector, 4, Character)
  if equipped == true or equipped == false then
    if attack == false then
      idle = idle + 1
    else
      idle = 0
    end
    if not (idle >= 500) or attack == false then
    end
    if torvel > 2 and torvel < 22 and hitfloor ~= nil then
      walk = true
      Humanoid.WalkSpeed = 12
      RH.C0 = clerp(RH.C0, cf(1, -1 - 0.25 * math.cos(sine / 7) / 2, 0.5 * math.cos(sine / 7) / 2) * angles(math.rad(-15 - 30 * math.cos(sine / 7)) + -math.sin(sine / 7) / 2.5, math.rad(90 - 5 * math.cos(sine / 7)), math.rad(0)) * angles(math.rad(0), math.rad(0), math.rad(0)), 0.3)
      LH.C0 = clerp(LH.C0, cf(-1, -1 + 0.25 * math.cos(sine / 7) / 2, -0.5 * math.cos(sine / 7) / 2) * angles(math.rad(-15 + 30 * math.cos(sine / 7)) + math.sin(sine / 7) / 2.5, math.rad(-90 - 5 * math.cos(sine / 7)), math.rad(0)) * angles(math.rad(0), math.rad(0), math.rad(0)), 0.3)
    end
    if torvel < 1 and hitfloor ~= nil and walk then
      coroutine.resume(coroutine.create(function()
        wait(0.5)
        walk = false
      end))
      Humanoid.WalkSpeed = 12
      RH.C0 = clerp(RH.C0, cf(1, -1, 0) * angles(0, 1.6, 0) * angles(-0.05, 0, 0), 0.3)
      LH.C0 = clerp(LH.C0, cf(-1, -1, 0) * angles(0, -1.6, 0) * angles(-0.05, 0, 0), 0.3)
    end
    if RootPart.Velocity.y > 1 and hitfloor == nil then
      Anim = "Jump"
      if attack == false and Sit == false then
        RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(0)), 0.15)
        Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(-10), math.rad(0), math.rad(0)), 0.15)
        LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(-40), math.rad(5), math.rad(-10)) * angles(math.rad(-5), math.rad(0), math.rad(0)), 0.15)
        LH.C0 = clerp(LH.C0, cf(-1, -0.5, -1) * angles(math.rad(-20), math.rad(-90), math.rad(0)) * angles(math.rad(-5), math.rad(0), math.rad(0)), 0.15)
        RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(50), math.rad(0), math.rad(30)), 0.15)
        if L == "Buster" then
          HandleBweld.Part0 = LeftArm
        end
        if R == "Sword" then
          handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0.4) * angles(math.rad(85), math.rad(-10), math.rad(0)), 0.15)
        end
      end
      if attack == false and Sit == false and R == "" and L == "" then
        RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(-10), math.rad(0), math.rad(0)), 0.15)
        Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(-20), math.rad(0), math.rad(0)), 0.15)
        RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(0), math.rad(0), math.rad(30)), 0.15)
        LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(0), math.rad(0), math.rad(-30)), 0.15)
        LH.C0 = clerp(LH.C0, cf(-1, -1, -0.2) * angles(math.rad(0), math.rad(-90), math.rad(0)) * angles(math.rad(-3), math.rad(0), math.rad(0)), 0.15)
        RH.C0 = clerp(RH.C0, cf(1, -1, -0.2) * angles(math.rad(0), math.rad(90), math.rad(5)) * angles(math.rad(-3), math.rad(0), math.rad(0)), 0.15)
        handleweld.C0 = clerp(handleweld.C0, cf(3, 3, 0.5) * angles(math.rad(90), math.rad(150), math.rad(90)), 0.15)
        HandleBweld.Part0 = Torso
        HandleBweld.C0 = clerp(HandleBweld.C0, cf(-2.5, -2, 0.5) * angles(0, -1.6, 0) * angles(1.5, 0, 0), 0.15)
      end
    elseif RootPart.Velocity.y < -1 and hitfloor == nil then
      Anim = "Fall"
      if attack == false and Sit == false then
        RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(10), math.rad(0), math.rad(0)), 0.15)
        Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(10), math.rad(0), math.rad(0)), 0.15)
        RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(-5), math.rad(0), math.rad(20)), 0.15)
        LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(-40), math.rad(5), math.rad(-10)) * angles(math.rad(-5), math.rad(0), math.rad(0)), 0.15)
        LH.C0 = clerp(LH.C0, cf(-1, -0.5, -1) * angles(math.rad(-20), math.rad(-90), math.rad(0)) * angles(math.rad(-5), math.rad(0), math.rad(0)), 0.15)
        if L == "Busters" then
          HandleBweld.Part0 = LeftArm
        end
        if R == "Sword" then
          handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0.4) * angles(math.rad(85), math.rad(-10), math.rad(0)), 0.15)
        end
      end
      if attack == false and Sit == false and R == "" and L == "" then
        RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(10), math.rad(0), math.rad(0)), 0.15)
        Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(20), math.rad(0), math.rad(0)), 0.15)
        RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(0), math.rad(0), math.rad(50)), 0.15)
        LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(0), math.rad(0), math.rad(-50)), 0.15)
        LH.C0 = clerp(LH.C0, cf(-1, -0.5, -0.5) * angles(math.rad(0), math.rad(-90), math.rad(0)) * angles(math.rad(-3), math.rad(0), math.rad(0)), 0.15)
        RH.C0 = clerp(RH.C0, cf(1, -1, -0.5) * angles(math.rad(0), math.rad(90), math.rad(5)) * angles(math.rad(-3), math.rad(0), math.rad(0)), 0.15)
        handleweld.C0 = clerp(handleweld.C0, cf(3, 3, 0.5) * angles(math.rad(90), math.rad(150), math.rad(90)), 0.15)
        HandleBweld.Part0 = Torso
        HandleBweld.C0 = clerp(HandleBweld.C0, cf(-2.5, -2, 0.2) * angles(0, -1.6, 0) * angles(1.5, 0, 0), 0.15)
      end
    elseif torvel < 1 and hitfloor ~= nil then
      Anim = "Idle"
      if attack == false and Sit == false then
        if R == "Sword" then
          RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(-40)), 0.15)
          Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(40)), 0.15)
          RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(40), math.rad(0), math.rad(20)), 0.15)
          LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(0), math.rad(0), math.rad(-10)), 0.15)
          LH.C0 = clerp(LH.C0, cf(-1, -1, 0) * angles(math.rad(0), math.rad(-60), math.rad(-5)) * angles(math.rad(-5), math.rad(0), math.rad(0)), 0.15)
          RH.C0 = clerp(RH.C0, cf(1, -1, 0) * angles(math.rad(0), math.rad(90), math.rad(-10)) * angles(math.rad(-5), math.rad(0), math.rad(0)), 0.15)
          handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0.4) * angles(math.rad(85), math.rad(-10), math.rad(0)), 0.15)
          if L ~= "Buster" then
            HandleBweld.Part0 = Torso
            HandleBweld.C0 = clerp(HandleBweld.C0, cf(-2.5, -2, 0.4) * angles(0, -1.6, 0) * angles(1.5, 0, 0), 0.15)
          end
        end
        if L == "Buster" then
          RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(-40)), 0.15)
          Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(40)), 0.15)
          if R == "Sword" then
            RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(40), math.rad(0), math.rad(20)), 0.15)
          else
            RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(0), math.rad(0), math.rad(10)), 0.15)
          end
          LW.C0 = clerp(LW.C0, CFrame.new(-1.4, 0.5, 0) * angles(math.rad(40), math.rad(0), math.rad(-20)), 0.15)
          LH.C0 = clerp(LH.C0, cf(-1, -1, 0) * angles(math.rad(0), math.rad(-60), math.rad(-5)) * angles(math.rad(-5), math.rad(0), math.rad(0)), 0.15)
          RH.C0 = clerp(RH.C0, cf(1, -1, 0) * angles(math.rad(0), math.rad(90), math.rad(-10)) * angles(math.rad(-5), math.rad(0), math.rad(0)), 0.15)
          HandleBweld.Part0 = LeftArm
          HandleBweld.C0 = clerp(HandleBweld.C0, cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(0)), 0.15)
          if R ~= "Sword" then
            handleweld.C0 = clerp(handleweld.C0, cf(3, 3, 0.5) * angles(math.rad(90), math.rad(150), math.rad(90)), 0.15)
          end
        end
      end
      if attack == false and Sit == false and R == "" and L == "" then
        RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(0)), 0.15)
        Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(0), math.rad(0), math.rad(0)), 0.15)
        RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(0), math.rad(0), math.rad(5)), 0.15)
        LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(0), math.rad(0), math.rad(-5)), 0.15)
        LH.C0 = clerp(LH.C0, cf(-1, -1, 0) * angles(math.rad(0), math.rad(-90), math.rad(0)) * angles(math.rad(-3), math.rad(0), math.rad(0)), 0.15)
        RH.C0 = clerp(RH.C0, cf(1, -1, 0) * angles(math.rad(0), math.rad(90), math.rad(5)) * angles(math.rad(-3), math.rad(0), math.rad(0)), 0.15)
        handleweld.C0 = clerp(handleweld.C0, cf(3, 3, 0.5) * angles(math.rad(90), math.rad(150), math.rad(90)), 0.15)
        HandleBweld.Part0 = Torso
        HandleBweld.C0 = clerp(HandleBweld.C0, cf(-2.5, -2, 0.5) * angles(0, -1.6, 0) * angles(1.5, 0, 0), 0.15)
      end
      if attack == false and Sit == true then
        RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, -2) * angles(math.rad(-10), math.rad(0), math.rad(0)), 0.15)
        Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(10), math.rad(0), math.rad(0)), 0.15)
        RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(-10), math.rad(0), math.rad(5)), 0.15)
        LW.C0 = clerp(LW.C0, cf(-1.3, 0.5, 0) * euler(math.rad(90), math.rad(0), math.rad(30)), 0.15)
        LH.C0 = clerp(LH.C0, cf(-1, 0.7, -0.5) * angles(math.rad(0), math.rad(-90), math.rad(-10)) * angles(math.rad(-3), math.rad(0), math.rad(0)), 0.15)
        RH.C0 = clerp(RH.C0, cf(1, -0.5, -0.5) * angles(math.rad(0), math.rad(90), math.rad(70)) * angles(math.rad(-3), math.rad(0), math.rad(0)), 0.15)
        handleweld.C0 = clerp(handleweld.C0, cf(3, 3, 0.5) * angles(math.rad(90), math.rad(150), math.rad(90)), 0.15)
        HandleBweld.Part0 = Torso
        HandleBweld.C0 = clerp(HandleBweld.C0, cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(0)), 0.15)
      end
    elseif torvel > 2 and hitfloor ~= nil then
      Anim = "Walk"
      if attack == false and Sit == false then
        change = 1
        if R == "Sword" then
          RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(10), math.rad(0), math.rad(0)), 0.15)
          Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(-5), math.rad(0), math.rad(0)), 0.15)
          RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(-5), math.rad(0), math.rad(20)), 0.15)
          if L == "Buster" then
            LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(-30), math.rad(5), math.rad(-10)), 0.15)
          end
          LH.C0 = clerp(LH.C0, cf(-1, -1, 0) * angles(math.rad(0), math.rad(-90), math.rad(0)) * angles(math.rad(-3), math.rad(0), math.rad(0)), 0.15)
          RH.C0 = clerp(RH.C0, cf(1, -1, 0) * angles(math.rad(0), math.rad(90), math.rad(0)) * angles(math.rad(-3), math.rad(0), math.rad(0)), 0.15)
          handleweld.C0 = clerp(handleweld.C0, cf(0, 0, 0) * angles(math.rad(15), math.rad(-10), math.rad(0)), 0.15)
          if L ~= "Buster" then
            LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(-30 * math.cos(sine / 10)), math.rad(0), math.rad(-5)), 0.15)
            HandleBweld.Part0 = Torso
            HandleBweld.C0 = clerp(HandleBweld.C0, cf(-2.5, -2, 0.5) * angles(0, -1.6, 0) * angles(1.5, 0, 0), 0.15)
          end
        end
        if L == "Buster" then
          RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(10), math.rad(0), math.rad(0)), 0.15)
          Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(-5), math.rad(0), math.rad(0)), 0.15)
          if R == "Sword" then
            RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(-5), math.rad(0), math.rad(20)), 0.15)
          end
          LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(-30), math.rad(5), math.rad(-10)), 0.15)
          LH.C0 = clerp(LH.C0, cf(-1, -1, 0) * angles(math.rad(0), math.rad(-90), math.rad(0)) * angles(math.rad(-3), math.rad(0), math.rad(0)), 0.15)
          RH.C0 = clerp(RH.C0, cf(1, -1, 0) * angles(math.rad(0), math.rad(90), math.rad(0)) * angles(math.rad(-3), math.rad(0), math.rad(0)), 0.15)
          HandleBweld.Part0 = LeftArm
          HandleBweld.C0 = clerp(HandleBweld.C0, cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(0)), 0.15)
          if R ~= "Sword" then
            RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(30 * math.cos(sine / 10)), math.rad(0), math.rad(5)), 0.15)
            handleweld.C0 = clerp(handleweld.C0, cf(3, 3, 0.5) * angles(math.rad(90), math.rad(150), math.rad(90)), 0.15)
          end
        end
      end
      if attack == false and Sit == false and R == "" and L == "" then
        RootJoint.C0 = clerp(RootJoint.C0, RootCF * cf(0, 0, 0) * angles(math.rad(10), math.rad(0), math.rad(0)), 0.15)
        Torso.Neck.C0 = clerp(Torso.Neck.C0, necko * angles(math.rad(-5), math.rad(0), math.rad(0)), 0.15)
        RW.C0 = clerp(RW.C0, cf(1.5, 0.5, 0) * euler(math.rad(30 * math.cos(sine / 10)), math.rad(0), math.rad(5)), 0.15)
        LW.C0 = clerp(LW.C0, cf(-1.5, 0.5, 0) * euler(math.rad(-30 * math.cos(sine / 10)), math.rad(0), math.rad(-5)), 0.15)
        LH.C0 = clerp(LH.C0, cf(-1, -1, 0) * angles(math.rad(0), math.rad(-90), math.rad(0)) * angles(math.rad(-2), math.rad(0), math.rad(0)), 0.15)
        RH.C0 = clerp(RH.C0, cf(1, -1, 0) * angles(math.rad(0), math.rad(90), math.rad(5)) * angles(math.rad(-2), math.rad(0), math.rad(0)), 0.15)
        handleweld.C0 = clerp(handleweld.C0, cf(3, 3, 0.5) * angles(math.rad(90), math.rad(150), math.rad(90)), 0.15)
        HandleBweld.C0 = clerp(HandleBweld.C0, cf(0, 0, 0) * angles(math.rad(0), math.rad(0), math.rad(0)), 0.15)
        handleweld.C0 = clerp(handleweld.C0, cf(3, 3, 0.5) * angles(math.rad(90), math.rad(150), math.rad(90)), 0.15)
        handleweld.C0 = clerp(handleweld.C0, cf(3, 3, 0.5) * angles(math.rad(90), math.rad(150), math.rad(90)), 0.15)
        HandleBweld.Part0 = Torso
        HandleBweld.C0 = clerp(HandleBweld.C0, cf(-4, -3.5, 1.5) * angles(0, 1.6, 4.2) * angles(-0.3, 0.5, 0), 0.15)
      end
    end
  end
  Ring1ReferencePointweld.C0 = clerp(Ring1ReferencePointweld.C0, cf(0, 0, 0) * angles(math.rad(0), math.rad(0 + 180 * math.cos(sine / 30)), math.rad(0 + 180 * math.cos(sine / 60))), 0.15)
  Ring2ReferencePointweld.C0 = clerp(Ring2ReferencePointweld.C0, cf(0, 0, 0) * angles(math.rad(0), math.rad(0 - 180 * math.cos(sine / 45)), math.rad(0 - 180 * math.cos(sine / 75))), 0.15)
  Ammo1.Text = "Buster ammo: " .. busterammo .. " / " .. maxbusterammo
  if #Effects > 0 then
    for e = 1, #Effects do
      if Effects[e] ~= nil then
        local Thing = Effects[e]
        if Thing ~= nil then
          local Part = Thing[1]
          local Mode = Thing[2]
          local Delay = Thing[3]
          local IncX = Thing[4]
          local IncY = Thing[5]
          local IncZ = Thing[6]
          if Thing[2] == "DecreaseStat" then
            Thing[5] = Thing[5] - 1
            if Thing[5] <= 0 then
              if Thing[1]:findFirstChild("Stats") ~= nil then
                Thing[1].Stats[Thing[3]].Value = Thing[1].Stats[Thing[3]].Value + Thing[4]
              end
              table.remove(Effects, e)
            end
          end
          if Thing[2] == "Shoot" then
            local Look = Thing[1]
            local hit, pos = rayCast(Thing[4], Look, 20, m)
            local mag = Thing[4] - pos.magnitude
            MagicHead(BrickColor.new("White"), CFrame.new((Thing[4] + pos) / 2, pos) * angles(1.57, 0, 0), 1, mag * 5, 1, 0.5, 0, 0.5, 0.1)
            Thing[4] = Thing[4] + Look * 20
            Thing[3] = Thing[3] - 1
            if hit ~= nil then
              Thing[3] = 0
              if Thing[8] == 1 then
                Damagefunc(hit, Thing[5], Thing[6], Thing[7], "Normal", RootPart, 0, 2, math.random(1, 5), nil, nil, true)
              elseif Thing[8] == 2 then
                Damagefunc(hit, Thing[5], Thing[6], Thing[7], "NormalDecreaseMvmt1", RootPart, 0, 2, math.random(1, 5), nil, nil, true)
              end
              ref = part(3, workspace, "SmoothPlastic", 0, 1, BrickColor.new("White"), "Reference", vt())
              ref.Anchored = true
              ref.CFrame = cf(pos)
              MagicCircle(BrickColor.new("Lime green"), cf(pos), 5, 5, 5, 1, 1, 1, 0.03)
              game:GetService("Debris"):AddItem(ref, 1)
            end
            if Thing[3] <= 0 then
              table.remove(Effects, e)
            end
          end
          if Thing[2] == "CylinderClang" then
            if Thing[3] <= 1 then
              Thing[1].CFrame = Thing[1].CFrame * CFrame.new(0, 2.5 * Thing[5], 0) * CFrame.fromEulerAnglesXYZ(Thing[6], 0, 0)
              Thing[7] = Thing[1].CFrame
              effect("New Yeller", 0, Thing[8], Thing[7])
              Thing[8] = Thing[7]
              Thing[3] = Thing[3] + Thing[4]
            else
              Part.Parent = nil
              table.remove(Effects, e)
            end
          end
          if Thing[2] ~= "Shoot" and Thing[2] ~= "DecreaseStat" then
            if Thing[1].Transparency <= 1 then
              if Thing[2] == "Block1" then
                Thing[1].CFrame = Thing[1].CFrame * euler(math.random(-50, 50), math.random(-50, 50), math.random(-50, 50))
                Mesh = Thing[7]
                Mesh.Scale = Mesh.Scale + vt(Thing[4], Thing[5], Thing[6])
                Thing[1].Transparency = Thing[1].Transparency + Thing[3]
              elseif Thing[2] == "Block2" then
                Thing[1].CFrame = Thing[1].CFrame
                Mesh = Thing[7]
                Mesh.Scale = Mesh.Scale + vt(Thing[4], Thing[5], Thing[6])
                Thing[1].Transparency = Thing[1].Transparency + Thing[3]
              elseif Thing[2] == "Cylinder" then
                if Thing[1]:FindFirstChild("Mesh") then
                  Mesh = Thing[7]
                  Mesh.Scale = Mesh.Scale + vt(Thing[4], Thing[5], Thing[6])
                  Thing[1].Transparency = Thing[1].Transparency + Thing[3]
                end
              elseif Thing[2] == "Blood" then
                Mesh = Thing[7]
                Thing[1].CFrame = Thing[1].CFrame * cf(0, 0.5, 0)
                Mesh.Scale = Mesh.Scale + vt(Thing[4], Thing[5], Thing[6])
                Thing[1].Transparency = Thing[1].Transparency + Thing[3]
              elseif Thing[2] == "Elec" then
                Mesh = Thing[1].Mesh
                Mesh.Scale = Mesh.Scale + vt(Thing[7], Thing[8], Thing[9])
                Thing[1].Transparency = Thing[1].Transparency + Thing[3]
              elseif Thing[2] == "Disappear" then
                Thing[1].Transparency = Thing[1].Transparency + Thing[3]
              end
            else
              Part.Parent = nil
              table.remove(Effects, e)
            end
          end
        end
      end
    end
  end
end
