CreateMainGui = function()
	-- Objects

local VPExplorer = Instance.new("ScreenGui")
local ExplorerOpenClose = Instance.new("Frame")
local ImageButton = Instance.new("ImageButton")
local ExplorerFolder = Instance.new("Frame")
local CommandPanel = Instance.new("Frame")
local TextButton = Instance.new("TextButton")
local TextBox = Instance.new("TextBox")
local property = Instance.new("Frame")
local edit = Instance.new("Frame")
local check = Instance.new("ImageButton")
local box = Instance.new("TextBox")
local locked = Instance.new("TextLabel")
local border = Instance.new("Frame")
local name = Instance.new("Frame")
local locked_2 = Instance.new("TextLabel")
local unlocked = Instance.new("TextLabel")
local ScrollFrame = Instance.new("Frame")
local ScrollBar = Instance.new("ImageButton")
local ScrollThumb = Instance.new("ImageButton")
local GripGraphic = Instance.new("Frame")
local Frame = Instance.new("Frame")
local Frame_2 = Instance.new("Frame")
local Frame_3 = Instance.new("Frame")
local ScrollUp = Instance.new("ImageButton")
local ArrowGraphic = Instance.new("Frame")
local Graphic = Instance.new("Frame")
local Graphic_2 = Instance.new("Frame")
local Graphic_3 = Instance.new("Frame")
local Graphic_4 = Instance.new("Frame")
local ScrollDown = Instance.new("ImageButton")
local ArrowGraphic_2 = Instance.new("Frame")
local Graphic_5 = Instance.new("Frame")
local Graphic_6 = Instance.new("Frame")
local Graphic_7 = Instance.new("Frame")
local Graphic_8 = Instance.new("Frame")
local TextWidth = Instance.new("TextLabel")
local Header = Instance.new("Frame")
local TextLabel = Instance.new("TextLabel")
local OutputPanel = Instance.new("Frame")
local property_2 = Instance.new("Frame")
local edit_2 = Instance.new("Frame")
local check_2 = Instance.new("ImageButton")
local box_2 = Instance.new("TextBox")
local locked_3 = Instance.new("TextLabel")
local border_2 = Instance.new("Frame")
local name_2 = Instance.new("Frame")
local locked_4 = Instance.new("TextLabel")
local unlocked_2 = Instance.new("TextLabel")
local ScrollFrame_2 = Instance.new("Frame")
local ScrollBar_2 = Instance.new("ImageButton")
local ScrollThumb_2 = Instance.new("ImageButton")
local GripGraphic_2 = Instance.new("Frame")
local Frame_4 = Instance.new("Frame")
local Frame_5 = Instance.new("Frame")
local Frame_6 = Instance.new("Frame")
local ScrollUp_2 = Instance.new("ImageButton")
local ArrowGraphic_3 = Instance.new("Frame")
local Graphic_9 = Instance.new("Frame")
local Graphic_10 = Instance.new("Frame")
local Graphic_11 = Instance.new("Frame")
local Graphic_12 = Instance.new("Frame")
local ScrollDown_2 = Instance.new("ImageButton")
local ArrowGraphic_4 = Instance.new("Frame")
local Graphic_13 = Instance.new("Frame")
local Graphic_14 = Instance.new("Frame")
local Graphic_15 = Instance.new("Frame")
local Graphic_16 = Instance.new("Frame")
local TextWidth_2 = Instance.new("TextLabel")
local List = Instance.new("Frame")
local Header_2 = Instance.new("Frame")
local TextLabel_2 = Instance.new("TextLabel")
local Dump = Instance.new("Frame")
local CreateInstance = Instance.new("Frame")
local NewInstance = Instance.new("TextBox")
local Create = Instance.new("TextButton")
local TopBar = Instance.new("TextLabel")
local Close = Instance.new("TextButton")
local ExplorerPanel = Instance.new("Frame")
local PropertiesPanel = Instance.new("Frame")
local Header_3 = Instance.new("Frame")
local TextLabel_3 = Instance.new("TextLabel")
local List_2 = Instance.new("Frame")
local property_3 = Instance.new("Frame")
local edit_3 = Instance.new("Frame")
local check_3 = Instance.new("ImageButton")
local box_3 = Instance.new("TextBox")
local locked_5 = Instance.new("TextLabel")
local border_3 = Instance.new("Frame")
local name_3 = Instance.new("Frame")
local locked_6 = Instance.new("TextLabel")
local unlocked_3 = Instance.new("TextLabel")
local property_4 = Instance.new("Frame")
local edit_4 = Instance.new("Frame")
local check_4 = Instance.new("ImageButton")
local box_4 = Instance.new("TextBox")
local locked_7 = Instance.new("TextLabel")
local border_4 = Instance.new("Frame")
local name_4 = Instance.new("Frame")
local locked_8 = Instance.new("TextLabel")
local unlocked_4 = Instance.new("TextLabel")
local property_5 = Instance.new("Frame")
local edit_5 = Instance.new("Frame")
local check_5 = Instance.new("ImageButton")
local box_5 = Instance.new("TextBox")
local locked_9 = Instance.new("TextLabel")
local border_5 = Instance.new("Frame")
local name_5 = Instance.new("Frame")
local locked_10 = Instance.new("TextLabel")
local unlocked_5 = Instance.new("TextLabel")
local property_6 = Instance.new("Frame")
local edit_6 = Instance.new("Frame")
local check_6 = Instance.new("ImageButton")
local box_6 = Instance.new("TextBox")
local locked_11 = Instance.new("TextLabel")
local border_6 = Instance.new("Frame")
local name_6 = Instance.new("Frame")
local locked_12 = Instance.new("TextLabel")
local unlocked_6 = Instance.new("TextLabel")
local ScrollFrame_3 = Instance.new("Frame")
local ScrollBar_3 = Instance.new("ImageButton")
local ScrollThumb_3 = Instance.new("ImageButton")
local GripGraphic_3 = Instance.new("Frame")
local Frame_7 = Instance.new("Frame")
local Frame_8 = Instance.new("Frame")
local Frame_9 = Instance.new("Frame")
local ScrollUp_3 = Instance.new("ImageButton")
local ArrowGraphic_5 = Instance.new("Frame")
local Graphic_17 = Instance.new("Frame")
local Graphic_18 = Instance.new("Frame")
local Graphic_19 = Instance.new("Frame")
local Graphic_20 = Instance.new("Frame")
local ScrollDown_3 = Instance.new("ImageButton")
local ArrowGraphic_6 = Instance.new("Frame")
local Graphic_21 = Instance.new("Frame")
local Graphic_22 = Instance.new("Frame")
local Graphic_23 = Instance.new("Frame")
local Graphic_24 = Instance.new("Frame")
local property_7 = Instance.new("Frame")
local edit_7 = Instance.new("Frame")
local check_7 = Instance.new("ImageButton")
local box_7 = Instance.new("TextBox")
local locked_13 = Instance.new("TextLabel")
local border_7 = Instance.new("Frame")
local name_7 = Instance.new("Frame")
local locked_14 = Instance.new("TextLabel")
local unlocked_7 = Instance.new("TextLabel")
local TextWidth_3 = Instance.new("TextLabel")
local BindableFunction1 = Instance.new("BindableFunction")
local BindableFunction2 = Instance.new("BindableFunction")
local BindableFunction3 = Instance.new("BindableFunction")
local BindableFunction4 = Instance.new("BindableFunction")
local BindableFunction5 = Instance.new("BindableFunction")
local BindableFunction6 = Instance.new("BindableFunction")
local BindableFunction7 = Instance.new("BindableFunction")
local BindableFunction8 = Instance.new("BindableFunction")

local BindableEvent1 = Instance.new("BindableEvent")
local BindableEvent2 = Instance.new("BindableEvent")
local BindableEvent3 = Instance.new("BindableEvent")
-- Properties

VPExplorer.Name = "VPExplorer"

ExplorerOpenClose.Name = "Explorer Open/Close"
ExplorerOpenClose.Parent = VPExplorer
ExplorerOpenClose.BackgroundColor3 = Color3.new(0, 1, 1)
ExplorerOpenClose.BackgroundTransparency = 1
ExplorerOpenClose.BorderSizePixel = 0
ExplorerOpenClose.Size = UDim2.new(1, 0, 1, 0)
ExplorerOpenClose.ZIndex = 10

ImageButton.Parent = ExplorerOpenClose
ImageButton.BackgroundColor3 = Color3.new(1, 1, 1)
ImageButton.BackgroundTransparency = 1
ImageButton.Draggable = true
ImageButton.Position = UDim2.new(0, 0, 0.5, -48)
ImageButton.Size = UDim2.new(0, 55, 0, 55)
ImageButton.ZIndex = 10
ImageButton.Image = "http://www.roblox.com/asset/?id=357306037"

ExplorerFolder.Name = "ExplorerFolder"
ExplorerFolder.Parent = VPExplorer
ExplorerFolder.BackgroundColor3 = Color3.new(1, 1, 1)
ExplorerFolder.BackgroundTransparency = 1
ExplorerFolder.Position = UDim2.new(-1, 0, 0, 0)
ExplorerFolder.Size = UDim2.new(1, 0, 1, 0)

ArrowGraphic.Name = "Arrow Graphic"
ArrowGraphic.Parent = ScrollUp
ArrowGraphic.BackgroundTransparency = 1
ArrowGraphic.BorderSizePixel = 0
ArrowGraphic.Position = UDim2.new(0.5, -4, 0.5, -4)
ArrowGraphic.Size = UDim2.new(0, 8, 0, 8)
ArrowGraphic.ZIndex = 10

Graphic.Name = "Graphic"
Graphic.Parent = ArrowGraphic
Graphic.BackgroundColor3 = Color3.new(0.584314, 0.584314, 0.584314)
Graphic.BackgroundTransparency = 0.69999998807907
Graphic.BorderSizePixel = 0
Graphic.Position = UDim2.new(0, 0, 0.625, 0)
Graphic.Size = UDim2.new(1, 0, 0.125, 0)
Graphic.ZIndex = 10

Graphic_2.Name = "Graphic"
Graphic_2.Parent = ArrowGraphic
Graphic_2.BackgroundColor3 = Color3.new(0.584314, 0.584314, 0.584314)
Graphic_2.BackgroundTransparency = 0.69999998807907
Graphic_2.BorderSizePixel = 0
Graphic_2.Position = UDim2.new(0.125, 0, 0.5, 0)
Graphic_2.Size = UDim2.new(0.75, 0, 0.125, 0)
Graphic_2.ZIndex = 10

Graphic_3.Name = "Graphic"
Graphic_3.Parent = ArrowGraphic
Graphic_3.BackgroundColor3 = Color3.new(0.584314, 0.584314, 0.584314)
Graphic_3.BackgroundTransparency = 0.69999998807907
Graphic_3.BorderSizePixel = 0
Graphic_3.Position = UDim2.new(0.25, 0, 0.375, 0)
Graphic_3.Size = UDim2.new(0.5, 0, 0.125, 0)
Graphic_3.ZIndex = 10

Graphic_4.Name = "Graphic"
Graphic_4.Parent = ArrowGraphic
Graphic_4.BackgroundColor3 = Color3.new(0.584314, 0.584314, 0.584314)
Graphic_4.BackgroundTransparency = 0.69999998807907
Graphic_4.BorderSizePixel = 0
Graphic_4.Position = UDim2.new(0.375, 0, 0.25, 0)
Graphic_4.Size = UDim2.new(0.25, 0, 0.125, 0)
Graphic_4.ZIndex = 10

ScrollDown.Name = "ScrollDown"
ScrollDown.Parent = ScrollFrame
ScrollDown.BackgroundColor3 = Color3.new(0.866667, 0.866667, 0.866667)
ScrollDown.BorderColor3 = Color3.new(0.584314, 0.584314, 0.584314)
ScrollDown.Position = UDim2.new(0, 0, 1, -16)
ScrollDown.Size = UDim2.new(0, 16, 0, 16)
ScrollDown.ZIndex = 10

ArrowGraphic_2.Name = "Arrow Graphic"
ArrowGraphic_2.Parent = ScrollDown
ArrowGraphic_2.BackgroundTransparency = 1
ArrowGraphic_2.BorderSizePixel = 0
ArrowGraphic_2.Position = UDim2.new(0.5, -4, 0.5, -4)
ArrowGraphic_2.Size = UDim2.new(0, 8, 0, 8)
ArrowGraphic_2.ZIndex = 10

Graphic_5.Name = "Graphic"
Graphic_5.Parent = ArrowGraphic_2
Graphic_5.BackgroundColor3 = Color3.new(0.584314, 0.584314, 0.584314)
Graphic_5.BorderSizePixel = 0
Graphic_5.Position = UDim2.new(0, 0, 0.25, 0)
Graphic_5.Size = UDim2.new(1, 0, 0.125, 0)
Graphic_5.ZIndex = 10

Graphic_6.Name = "Graphic"
Graphic_6.Parent = ArrowGraphic_2
Graphic_6.BackgroundColor3 = Color3.new(0.584314, 0.584314, 0.584314)
Graphic_6.BorderSizePixel = 0
Graphic_6.Position = UDim2.new(0.125, 0, 0.375, 0)
Graphic_6.Size = UDim2.new(0.75, 0, 0.125, 0)
Graphic_6.ZIndex = 10

Graphic_7.Name = "Graphic"
Graphic_7.Parent = ArrowGraphic_2
Graphic_7.BackgroundColor3 = Color3.new(0.584314, 0.584314, 0.584314)
Graphic_7.BorderSizePixel = 0
Graphic_7.Position = UDim2.new(0.25, 0, 0.5, 0)
Graphic_7.Size = UDim2.new(0.5, 0, 0.125, 0)
Graphic_7.ZIndex = 10

Graphic_8.Name = "Graphic"
Graphic_8.Parent = ArrowGraphic_2
Graphic_8.BackgroundColor3 = Color3.new(0.584314, 0.584314, 0.584314)
Graphic_8.BorderSizePixel = 0
Graphic_8.Position = UDim2.new(0.375, 0, 0.625, 0)
Graphic_8.Size = UDim2.new(0.25, 0, 0.125, 0)
Graphic_8.ZIndex = 10

TextWidth.Name = "TextWidth"
TextWidth.Parent = CommandPanel
TextWidth.BackgroundColor3 = Color3.new(0, 0, 0)
TextWidth.BackgroundTransparency = 0.30000001192093
TextWidth.Size = UDim2.new(1, 0, 1, 0)
TextWidth.Visible = false
TextWidth.ZIndex = 10
TextWidth.Font = Enum.Font.SourceSans
TextWidth.FontSize = Enum.FontSize.Size14
TextWidth.Text = "TweenService"
TextWidth.TextColor3 = Color3.new(1, 1, 1)
TextWidth.TextStrokeColor3 = Color3.new(1, 1, 1)
TextWidth.TextXAlignment = Enum.TextXAlignment.Left

Header.Name = "Header"
Header.Parent = CommandPanel
Header.BackgroundColor3 = Color3.new(0, 0, 0)
Header.BackgroundTransparency = 1
Header.BorderColor3 = Color3.new(0.584314, 0.584314, 0.584314)
Header.BorderSizePixel = 0
Header.Size = UDim2.new(1, 0, 0, 18)
Header.ZIndex = 10

TextLabel.Parent = Header
TextLabel.BackgroundTransparency = 1
TextLabel.BorderSizePixel = 0
TextLabel.Position = UDim2.new(0, 4, 0, 0)
TextLabel.Size = UDim2.new(1, -4, 1, 0)
TextLabel.ZIndex = 10
TextLabel.Font = Enum.Font.SourceSans
TextLabel.FontSize = Enum.FontSize.Size14
TextLabel.Text = "Command"
TextLabel.TextColor3 = Color3.new(1, 1, 1)
TextLabel.TextXAlignment = Enum.TextXAlignment.Left

GripGraphic_2.Name = "Grip Graphic"
GripGraphic_2.Parent = ScrollThumb_2
GripGraphic_2.BackgroundTransparency = 1
GripGraphic_2.BorderSizePixel = 0
GripGraphic_2.Position = UDim2.new(0.5, -3, 0.5, -3)
GripGraphic_2.Size = UDim2.new(0, 6, 0, 6)

Frame_4.Parent = GripGraphic_2
Frame_4.BorderSizePixel = 0
Frame_4.Position = UDim2.new(0, 0, 0.666666687, 0)
Frame_4.Size = UDim2.new(1, 0, 0.166666672, 0)

Frame_5.Parent = GripGraphic_2
Frame_5.BorderSizePixel = 0
Frame_5.Position = UDim2.new(0, 0, 0.333333343, 0)
Frame_5.Size = UDim2.new(1, 0, 0.166666672, 0)

Frame_6.Parent = GripGraphic_2
Frame_6.BorderSizePixel = 0
Frame_6.Size = UDim2.new(1, 0, 0.166666672, 0)

ScrollUp_2.Name = "ScrollUp"
ScrollUp_2.Parent = ScrollFrame_2
ScrollUp_2.Active = false
ScrollUp_2.BackgroundColor3 = Color3.new(0.866667, 0.866667, 0.866667)
ScrollUp_2.BorderColor3 = Color3.new(0.584314, 0.584314, 0.584314)
ScrollUp_2.Size = UDim2.new(0, 16, 0, 16)
ScrollUp_2.AutoButtonColor = false

ArrowGraphic_3.Name = "Arrow Graphic"
ArrowGraphic_3.Parent = ScrollUp_2
ArrowGraphic_3.BackgroundTransparency = 1
ArrowGraphic_3.BorderSizePixel = 0
ArrowGraphic_3.Position = UDim2.new(0.5, -4, 0.5, -4)
ArrowGraphic_3.Size = UDim2.new(0, 8, 0, 8)

Graphic_9.Name = "Graphic"
Graphic_9.Parent = ArrowGraphic_3
Graphic_9.BackgroundColor3 = Color3.new(0.584314, 0.584314, 0.584314)
Graphic_9.BackgroundTransparency = 0.69999998807907
Graphic_9.BorderSizePixel = 0
Graphic_9.Position = UDim2.new(0, 0, 0.625, 0)
Graphic_9.Size = UDim2.new(1, 0, 0.125, 0)

Graphic_10.Name = "Graphic"
Graphic_10.Parent = ArrowGraphic_3
Graphic_10.BackgroundColor3 = Color3.new(0.584314, 0.584314, 0.584314)
Graphic_10.BackgroundTransparency = 0.69999998807907
Graphic_10.BorderSizePixel = 0
Graphic_10.Position = UDim2.new(0.125, 0, 0.5, 0)
Graphic_10.Size = UDim2.new(0.75, 0, 0.125, 0)

Graphic_11.Name = "Graphic"
Graphic_11.Parent = ArrowGraphic_3
Graphic_11.BackgroundColor3 = Color3.new(0.584314, 0.584314, 0.584314)
Graphic_11.BackgroundTransparency = 0.69999998807907
Graphic_11.BorderSizePixel = 0
Graphic_11.Position = UDim2.new(0.25, 0, 0.375, 0)
Graphic_11.Size = UDim2.new(0.5, 0, 0.125, 0)

Graphic_12.Name = "Graphic"
Graphic_12.Parent = ArrowGraphic_3
Graphic_12.BackgroundColor3 = Color3.new(0.584314, 0.584314, 0.584314)
Graphic_12.BackgroundTransparency = 0.69999998807907
Graphic_12.BorderSizePixel = 0
Graphic_12.Position = UDim2.new(0.375, 0, 0.25, 0)
Graphic_12.Size = UDim2.new(0.25, 0, 0.125, 0)

ScrollDown_2.Name = "ScrollDown"
ScrollDown_2.Parent = ScrollFrame_2
ScrollDown_2.BackgroundColor3 = Color3.new(0.866667, 0.866667, 0.866667)
ScrollDown_2.BorderColor3 = Color3.new(0.584314, 0.584314, 0.584314)
ScrollDown_2.Position = UDim2.new(0, 0, 1, -16)
ScrollDown_2.Size = UDim2.new(0, 16, 0, 16)

ArrowGraphic_4.Name = "Arrow Graphic"
ArrowGraphic_4.Parent = ScrollDown_2
ArrowGraphic_4.BackgroundTransparency = 1
ArrowGraphic_4.BorderSizePixel = 0
ArrowGraphic_4.Position = UDim2.new(0.5, -4, 0.5, -4)
ArrowGraphic_4.Size = UDim2.new(0, 8, 0, 8)

Graphic_13.Name = "Graphic"
Graphic_13.Parent = ArrowGraphic_4
Graphic_13.BackgroundColor3 = Color3.new(0.584314, 0.584314, 0.584314)
Graphic_13.BorderSizePixel = 0
Graphic_13.Position = UDim2.new(0, 0, 0.25, 0)
Graphic_13.Size = UDim2.new(1, 0, 0.125, 0)

Graphic_14.Name = "Graphic"
Graphic_14.Parent = ArrowGraphic_4
Graphic_14.BackgroundColor3 = Color3.new(0.584314, 0.584314, 0.584314)
Graphic_14.BorderSizePixel = 0
Graphic_14.Position = UDim2.new(0.125, 0, 0.375, 0)
Graphic_14.Size = UDim2.new(0.75, 0, 0.125, 0)

Graphic_15.Name = "Graphic"
Graphic_15.Parent = ArrowGraphic_4
Graphic_15.BackgroundColor3 = Color3.new(0.584314, 0.584314, 0.584314)
Graphic_15.BorderSizePixel = 0
Graphic_15.Position = UDim2.new(0.25, 0, 0.5, 0)
Graphic_15.Size = UDim2.new(0.5, 0, 0.125, 0)

Graphic_16.Name = "Graphic"
Graphic_16.Parent = ArrowGraphic_4
Graphic_16.BackgroundColor3 = Color3.new(0.584314, 0.584314, 0.584314)
Graphic_16.BorderSizePixel = 0
Graphic_16.Position = UDim2.new(0.375, 0, 0.625, 0)
Graphic_16.Size = UDim2.new(0.25, 0, 0.125, 0)

TextWidth_2.Name = "TextWidth"
TextWidth_2.Parent = OutputPanel
TextWidth_2.Size = UDim2.new(1, 0, 1, 0)
TextWidth_2.Visible = false
TextWidth_2.Font = Enum.Font.SourceSans
TextWidth_2.FontSize = Enum.FontSize.Size14
TextWidth_2.Text = "TweenService"
TextWidth_2.TextColor3 = Color3.new(1, 1, 1)
TextWidth_2.TextXAlignment = Enum.TextXAlignment.Left

List.Name = "List"
List.Parent = OutputPanel
List.BackgroundColor3 = Color3.new(0, 0, 0)
List.BackgroundTransparency = 1
List.BorderColor3 = Color3.new(0, 0, 0)
List.ClipsDescendants = true
List.Position = UDim2.new(0, 0, 0, 18)
List.Size = UDim2.new(1, -16, 1, -18)

Header_2.Name = "Header"
Header_2.Parent = OutputPanel
Header_2.BackgroundColor3 = Color3.new(0, 0, 0)
Header_2.BackgroundTransparency = 1
Header_2.BorderColor3 = Color3.new(0, 0, 0)
Header_2.Size = UDim2.new(1, 0, 0, 18)

TextLabel_2.Parent = Header_2
TextLabel_2.BackgroundTransparency = 1
TextLabel_2.Position = UDim2.new(0, 4, 0, 0)
TextLabel_2.Size = UDim2.new(1, -4, 1, 0)
TextLabel_2.Font = Enum.Font.SourceSans
TextLabel_2.FontSize = Enum.FontSize.Size14
TextLabel_2.Text = "Output"
TextLabel_2.TextColor3 = Color3.new(1, 1, 1)
TextLabel_2.TextXAlignment = Enum.TextXAlignment.Left

Dump.Name = "Dump"
Dump.Parent = ExplorerFolder
Dump.BackgroundColor3 = Color3.new(1, 1, 1)
Dump.BackgroundTransparency = 1
Dump.Size = UDim2.new(1, 0, 1, 0)

CreateInstance.Name = "CreateInstance"
CreateInstance.Parent = ExplorerFolder
CreateInstance.BackgroundColor3 = Color3.new(1, 1, 1)
CreateInstance.BackgroundTransparency = 0.5
CreateInstance.BorderSizePixel = 0
CreateInstance.Position = UDim2.new(0.5, -125, 0.5, -138)
CreateInstance.Size = UDim2.new(0, 250, 0, 90)
CreateInstance.Visible = false

NewInstance.Name = "Instance"
NewInstance.Parent = CreateInstance
NewInstance.BackgroundColor3 = Color3.new(1, 1, 1)
NewInstance.BackgroundTransparency = 0.30000001192093
NewInstance.BorderSizePixel = 0
NewInstance.Position = UDim2.new(0, 25, 0, 30)
NewInstance.Size = UDim2.new(0, 200, 0, 25)
NewInstance.ZIndex = 5
NewInstance.Font = Enum.Font.SourceSans
NewInstance.FontSize = Enum.FontSize.Size14
NewInstance.Text = "Class Name"

Create.Name = "Create"
Create.Parent = CreateInstance
Create.BackgroundColor3 = Color3.new(1, 1, 1)
Create.BackgroundTransparency = 0.30000001192093
Create.BorderSizePixel = 0
Create.Position = UDim2.new(0, 120, 0, 60)
Create.Size = UDim2.new(0, 100, 0, 25)
Create.ZIndex = 5
Create.Font = Enum.Font.SourceSans
Create.FontSize = Enum.FontSize.Size14
Create.Text = "Create Instance"

TopBar.Name = "TopBar"
TopBar.Parent = CreateInstance
TopBar.BackgroundColor3 = Color3.new(1, 1, 1)
TopBar.BackgroundTransparency = 0.30000001192093
TopBar.BorderSizePixel = 0
TopBar.Size = UDim2.new(0, 225, 0, 25)
TopBar.Font = Enum.Font.SourceSans
TopBar.FontSize = Enum.FontSize.Size14
TopBar.Text = "Create Instance"

Close.Name = "Close"
Close.Parent = CreateInstance
Close.BackgroundColor3 = Color3.new(1, 0, 0)
Close.BorderSizePixel = 0
Close.Position = UDim2.new(1, -25, 0, 0)
Close.Size = UDim2.new(0, 25, 0, 25)
Close.ZIndex = 5
Close.Modal = true
Close.Font = Enum.Font.SourceSans
Close.FontSize = Enum.FontSize.Size14
Close.Text = "X"

ExplorerPanel.Name = "ExplorerPanel"
ExplorerPanel.Parent = ExplorerFolder
ExplorerPanel.Active = true
ExplorerPanel.BackgroundColor3 = Color3.new(0.129412, 0.129412, 0.129412)
ExplorerPanel.BackgroundTransparency = 0.5
ExplorerPanel.BorderColor3 = Color3.new(0.74902, 0.74902, 0.74902)
ExplorerPanel.Position = UDim2.new(1, -300, 0, 0)
ExplorerPanel.Size = UDim2.new(0, 300, 0.5, 0)
ExplorerPanel.BorderSizePixel = 0

PropertiesPanel.Name = "PropertiesPanel"
PropertiesPanel.Parent = ExplorerFolder
PropertiesPanel.Active = true
PropertiesPanel.BackgroundColor3 = Color3.new(0.129412, 0.129412, 0.129412)
PropertiesPanel.BackgroundTransparency = 0.5
PropertiesPanel.BorderColor3 = Color3.new(0.584314, 0.584314, 0.584314)
PropertiesPanel.Position = UDim2.new(1, -300, 0.5, 0)
PropertiesPanel.Size = UDim2.new(0, 300, 0.5, 0)
PropertiesPanel.BorderSizePixel = 0

Header_3.Name = "Header"
Header_3.Parent = PropertiesPanel
Header_3.BackgroundColor3 = Color3.new(0, 0, 0)
Header_3.BackgroundTransparency = 1
Header_3.BorderColor3 = Color3.new(0.584314, 0.584314, 0.584314)
Header_3.BorderSizePixel = 0
Header_3.Size = UDim2.new(1, 0, 0, 18)
Header_3.ZIndex = 10

TextLabel_3.Parent = Header_3
TextLabel_3.BackgroundTransparency = 1
TextLabel_3.Position = UDim2.new(0, 4, 0, 0)
TextLabel_3.Size = UDim2.new(1, -4, 1, 0)
TextLabel_3.ZIndex = 10
TextLabel_3.Font = Enum.Font.SourceSans
TextLabel_3.FontSize = Enum.FontSize.Size14
TextLabel_3.Text = "Properties"
TextLabel_3.TextColor3 = Color3.new(1, 1, 1)
TextLabel_3.TextStrokeColor3 = Color3.new(1, 1, 1)
TextLabel_3.TextXAlignment = Enum.TextXAlignment.Left

List_2.Name = "List"
List_2.Parent = PropertiesPanel
List_2.BackgroundColor3 = Color3.new(0, 0, 0)
List_2.BackgroundTransparency = 1
List_2.BorderColor3 = Color3.new(0.584314, 0.584314, 0.584314)
List_2.BorderSizePixel = 0
List_2.ClipsDescendants = true
List_2.Position = UDim2.new(0, 0, 0, 18)
List_2.Size = UDim2.new(1, -16, 1, -18)
List_2.ZIndex = 10

property_3.Name = "property"
property_3.Parent = List_2
property_3.BackgroundColor3 = Color3.new(0.866667, 0.866667, 0.870588)
property_3.BackgroundTransparency = 1
property_3.BorderColor3 = Color3.new(0.584314, 0.584314, 0.584314)
property_3.BorderSizePixel = 0
property_3.Size = UDim2.new(1, 0, 0, 22)
property_3.ZIndex = 10

edit_3.Name = "edit"
edit_3.Parent = property_3
edit_3.BackgroundColor3 = Color3.new(0, 0, 0)
edit_3.BackgroundTransparency = 1
edit_3.BorderColor3 = Color3.new(0.686275, 0.686275, 0.686275)
edit_3.Position = UDim2.new(0.5, 0, 0, 0)
edit_3.Size = UDim2.new(0.5, 0, 1, -1)
edit_3.ZIndex = 10

check_3.Name = "check"
check_3.Parent = edit_3
check_3.BackgroundColor3 = Color3.new(0.866667, 0.866667, 0.870588)
check_3.BorderSizePixel = 0
check_3.Position = UDim2.new(0, 5, 0, 5)
check_3.Size = UDim2.new(0, 12, 0, 12)
check_3.ZIndex = 10
check_3.Image = "http://www.roblox.com/asset/?id=48138491"

box_3.Name = "box"
box_3.Parent = edit_3
box_3.BackgroundTransparency = 1
box_3.Position = UDim2.new(0, 5, 0, 0)
box_3.Size = UDim2.new(1, -10, 1, 0)
box_3.Visible = false
box_3.ZIndex = 10
box_3.Font = Enum.Font.SourceSans
box_3.FontSize = Enum.FontSize.Size14
box_3.Text = ""
box_3.TextColor3 = Color3.new(1, 1, 1)
box_3.TextStrokeColor3 = Color3.new(1, 1, 1)
box_3.TextWrapped = true
box_3.TextXAlignment = Enum.TextXAlignment.Left

locked_5.Name = "locked"
locked_5.Parent = edit_3
locked_5.BackgroundTransparency = 1
locked_5.Position = UDim2.new(0, 5, 0, 0)
locked_5.Size = UDim2.new(1, -10, 1, 0)
locked_5.Visible = false
locked_5.ZIndex = 10
locked_5.Font = Enum.Font.SourceSans
locked_5.FontSize = Enum.FontSize.Size14
locked_5.Text = ""
locked_5.TextColor3 = Color3.new(1, 1, 1)
locked_5.TextStrokeColor3 = Color3.new(1, 1, 1)
locked_5.TextWrapped = true
locked_5.TextXAlignment = Enum.TextXAlignment.Left

border_3.Name = "border"
border_3.Parent = property_3
border_3.BackgroundColor3 = Color3.new(0, 0, 0)
border_3.BackgroundTransparency = 1
border_3.BorderColor3 = Color3.new(0.686275, 0.686275, 0.686275)
border_3.BorderSizePixel = 0
border_3.Position = UDim2.new(0.5, 0, 0, 0)
border_3.Size = UDim2.new(0, 1, 1, 0)
border_3.ZIndex = 10

name_3.Name = "name"
name_3.Parent = property_3
name_3.BackgroundColor3 = Color3.new(0, 0, 0)
name_3.BackgroundTransparency = 1
name_3.BorderColor3 = Color3.new(0.686275, 0.686275, 0.686275)
name_3.Size = UDim2.new(0.5, 0, 1, -1)
name_3.ZIndex = 10

locked_6.Name = "locked"
locked_6.Parent = name_3
locked_6.BackgroundTransparency = 1
locked_6.Position = UDim2.new(0, 5, 0, 0)
locked_6.Size = UDim2.new(1, -10, 1, 0)
locked_6.Visible = false
locked_6.ZIndex = 10
locked_6.Font = Enum.Font.SourceSans
locked_6.FontSize = Enum.FontSize.Size14
locked_6.Text = "Archivable"
locked_6.TextColor3 = Color3.new(1, 1, 1)
locked_6.TextStrokeColor3 = Color3.new(1, 1, 1)
locked_6.TextWrapped = true
locked_6.TextXAlignment = Enum.TextXAlignment.Left

unlocked_3.Name = "unlocked"
unlocked_3.Parent = name_3
unlocked_3.BackgroundTransparency = 1
unlocked_3.Position = UDim2.new(0, 5, 0, 0)
unlocked_3.Size = UDim2.new(1, -10, 1, 0)
unlocked_3.ZIndex = 10
unlocked_3.Font = Enum.Font.SourceSans
unlocked_3.FontSize = Enum.FontSize.Size14
unlocked_3.Text = "Archivable"
unlocked_3.TextColor3 = Color3.new(1, 1, 1)
unlocked_3.TextStrokeColor3 = Color3.new(1, 1, 1)
unlocked_3.TextWrapped = true
unlocked_3.TextXAlignment = Enum.TextXAlignment.Left

property_4.Name = "property"
property_4.Parent = List_2
property_4.BackgroundColor3 = Color3.new(0.929412, 0.929412, 0.933333)
property_4.BackgroundTransparency = 1
property_4.BorderColor3 = Color3.new(0.584314, 0.584314, 0.584314)
property_4.BorderSizePixel = 0
property_4.Position = UDim2.new(0, 0, 0, 23)
property_4.Size = UDim2.new(1, 0, 0, 22)
property_4.ZIndex = 10

edit_4.Name = "edit"
edit_4.Parent = property_4
edit_4.BackgroundColor3 = Color3.new(0, 0, 0)
edit_4.BackgroundTransparency = 1
edit_4.BorderColor3 = Color3.new(0.686275, 0.686275, 0.686275)
edit_4.Position = UDim2.new(0.5, 0, 0, 0)
edit_4.Size = UDim2.new(0.5, 0, 1, -1)
edit_4.ZIndex = 10

check_4.Name = "check"
check_4.Parent = edit_4
check_4.BackgroundColor3 = Color3.new(0.866667, 0.866667, 0.870588)
check_4.BorderSizePixel = 0
check_4.Position = UDim2.new(0, 5, 0, 5)
check_4.Size = UDim2.new(0, 12, 0, 12)
check_4.Visible = false
check_4.ZIndex = 10

box_4.Name = "box"
box_4.Parent = edit_4
box_4.BackgroundTransparency = 1
box_4.Position = UDim2.new(0, 5, 0, 0)
box_4.Size = UDim2.new(1, -10, 1, 0)
box_4.Visible = false
box_4.ZIndex = 10
box_4.Font = Enum.Font.SourceSans
box_4.FontSize = Enum.FontSize.Size14
box_4.Text = ""
box_4.TextColor3 = Color3.new(1, 1, 1)
box_4.TextStrokeColor3 = Color3.new(1, 1, 1)
box_4.TextWrapped = true
box_4.TextXAlignment = Enum.TextXAlignment.Left

locked_7.Name = "locked"
locked_7.Parent = edit_4
locked_7.BackgroundTransparency = 1
locked_7.Position = UDim2.new(0, 5, 0, 0)
locked_7.Size = UDim2.new(1, -10, 1, 0)
locked_7.ZIndex = 10
locked_7.Font = Enum.Font.SourceSans
locked_7.FontSize = Enum.FontSize.Size14
locked_7.Text = "LogService"
locked_7.TextColor3 = Color3.new(1, 1, 1)
locked_7.TextStrokeColor3 = Color3.new(1, 1, 1)
locked_7.TextWrapped = true
locked_7.TextXAlignment = Enum.TextXAlignment.Left

border_4.Name = "border"
border_4.Parent = property_4
border_4.BackgroundColor3 = Color3.new(0, 0, 0)
border_4.BackgroundTransparency = 1
border_4.BorderColor3 = Color3.new(0.686275, 0.686275, 0.686275)
border_4.BorderSizePixel = 0
border_4.Position = UDim2.new(0.5, 0, 0, 0)
border_4.Size = UDim2.new(0, 1, 1, 0)
border_4.ZIndex = 10

name_4.Name = "name"
name_4.Parent = property_4
name_4.BackgroundColor3 = Color3.new(0, 0, 0)
name_4.BackgroundTransparency = 1
name_4.BorderColor3 = Color3.new(0.686275, 0.686275, 0.686275)
name_4.Size = UDim2.new(0.5, 0, 1, -1)
name_4.ZIndex = 10

locked_8.Name = "locked"
locked_8.Parent = name_4
locked_8.BackgroundTransparency = 1
locked_8.Position = UDim2.new(0, 5, 0, 0)
locked_8.Size = UDim2.new(1, -10, 1, 0)
locked_8.ZIndex = 10
locked_8.Font = Enum.Font.SourceSans
locked_8.FontSize = Enum.FontSize.Size14
locked_8.Text = "ClassName"
locked_8.TextColor3 = Color3.new(1, 1, 1)
locked_8.TextStrokeColor3 = Color3.new(1, 1, 1)
locked_8.TextWrapped = true
locked_8.TextXAlignment = Enum.TextXAlignment.Left

unlocked_4.Name = "unlocked"
unlocked_4.Parent = name_4
unlocked_4.BackgroundTransparency = 1
unlocked_4.Position = UDim2.new(0, 5, 0, 0)
unlocked_4.Size = UDim2.new(1, -10, 1, 0)
unlocked_4.Visible = false
unlocked_4.ZIndex = 10
unlocked_4.Font = Enum.Font.SourceSans
unlocked_4.FontSize = Enum.FontSize.Size14
unlocked_4.Text = "ClassName"
unlocked_4.TextColor3 = Color3.new(1, 1, 1)
unlocked_4.TextStrokeColor3 = Color3.new(1, 1, 1)
unlocked_4.TextWrapped = true
unlocked_4.TextXAlignment = Enum.TextXAlignment.Left

property_5.Name = "property"
property_5.Parent = List_2
property_5.BackgroundColor3 = Color3.new(0.866667, 0.866667, 0.870588)
property_5.BackgroundTransparency = 1
property_5.BorderColor3 = Color3.new(0.584314, 0.584314, 0.584314)
property_5.BorderSizePixel = 0
property_5.Position = UDim2.new(0, 0, 0, 46)
property_5.Size = UDim2.new(1, 0, 0, 22)
property_5.ZIndex = 10

edit_5.Name = "edit"
edit_5.Parent = property_5
edit_5.BackgroundColor3 = Color3.new(0, 0, 0)
edit_5.BackgroundTransparency = 1
edit_5.BorderColor3 = Color3.new(0.686275, 0.686275, 0.686275)
edit_5.Position = UDim2.new(0.5, 0, 0, 0)
edit_5.Size = UDim2.new(0.5, 0, 1, -1)
edit_5.ZIndex = 10

check_5.Name = "check"
check_5.Parent = edit_5
check_5.BackgroundColor3 = Color3.new(0.866667, 0.866667, 0.870588)
check_5.BorderSizePixel = 0
check_5.Position = UDim2.new(0, 5, 0, 5)
check_5.Size = UDim2.new(0, 12, 0, 12)
check_5.Visible = false
check_5.ZIndex = 10

box_5.Name = "box"
box_5.Parent = edit_5
box_5.BackgroundTransparency = 1
box_5.Position = UDim2.new(0, 5, 0, 0)
box_5.Size = UDim2.new(1, -10, 1, 0)
box_5.ZIndex = 10
box_5.Font = Enum.Font.SourceSans
box_5.FontSize = Enum.FontSize.Size14
box_5.Text = "LogService"
box_5.TextColor3 = Color3.new(1, 1, 1)
box_5.TextStrokeColor3 = Color3.new(1, 1, 1)
box_5.TextWrapped = true
box_5.TextXAlignment = Enum.TextXAlignment.Left

locked_9.Name = "locked"
locked_9.Parent = edit_5
locked_9.BackgroundTransparency = 1
locked_9.Position = UDim2.new(0, 5, 0, 0)
locked_9.Size = UDim2.new(1, -10, 1, 0)
locked_9.Visible = false
locked_9.ZIndex = 10
locked_9.Font = Enum.Font.SourceSans
locked_9.FontSize = Enum.FontSize.Size14
locked_9.Text = ""
locked_9.TextColor3 = Color3.new(1, 1, 1)
locked_9.TextStrokeColor3 = Color3.new(1, 1, 1)
locked_9.TextWrapped = true
locked_9.TextXAlignment = Enum.TextXAlignment.Left

border_5.Name = "border"
border_5.Parent = property_5
border_5.BackgroundColor3 = Color3.new(0, 0, 0)
border_5.BackgroundTransparency = 1
border_5.BorderColor3 = Color3.new(0.686275, 0.686275, 0.686275)
border_5.BorderSizePixel = 0
border_5.Position = UDim2.new(0.5, 0, 0, 0)
border_5.Size = UDim2.new(0, 1, 1, 0)
border_5.ZIndex = 10

name_5.Name = "name"
name_5.Parent = property_5
name_5.BackgroundColor3 = Color3.new(0, 0, 0)
name_5.BackgroundTransparency = 1
name_5.BorderColor3 = Color3.new(0.686275, 0.686275, 0.686275)
name_5.Size = UDim2.new(0.5, 0, 1, -1)
name_5.ZIndex = 10

locked_10.Name = "locked"
locked_10.Parent = name_5
locked_10.BackgroundTransparency = 1
locked_10.Position = UDim2.new(0, 5, 0, 0)
locked_10.Size = UDim2.new(1, -10, 1, 0)
locked_10.Visible = false
locked_10.ZIndex = 10
locked_10.Font = Enum.Font.SourceSans
locked_10.FontSize = Enum.FontSize.Size14
locked_10.Text = "Name"
locked_10.TextColor3 = Color3.new(1, 1, 1)
locked_10.TextStrokeColor3 = Color3.new(1, 1, 1)
locked_10.TextWrapped = true
locked_10.TextXAlignment = Enum.TextXAlignment.Left

unlocked_5.Name = "unlocked"
unlocked_5.Parent = name_5
unlocked_5.BackgroundTransparency = 1
unlocked_5.Position = UDim2.new(0, 5, 0, 0)
unlocked_5.Size = UDim2.new(1, -10, 1, 0)
unlocked_5.ZIndex = 10
unlocked_5.Font = Enum.Font.SourceSans
unlocked_5.FontSize = Enum.FontSize.Size14
unlocked_5.Text = "Name"
unlocked_5.TextColor3 = Color3.new(1, 1, 1)
unlocked_5.TextStrokeColor3 = Color3.new(1, 1, 1)
unlocked_5.TextWrapped = true
unlocked_5.TextXAlignment = Enum.TextXAlignment.Left

property_6.Name = "property"
property_6.Parent = List_2
property_6.BackgroundColor3 = Color3.new(0.929412, 0.929412, 0.933333)
property_6.BackgroundTransparency = 1
property_6.BorderColor3 = Color3.new(0.584314, 0.584314, 0.584314)
property_6.BorderSizePixel = 0
property_6.Position = UDim2.new(0, 0, 0, 69)
property_6.Size = UDim2.new(1, 0, 0, 22)
property_6.ZIndex = 10

edit_6.Name = "edit"
edit_6.Parent = property_6
edit_6.BackgroundColor3 = Color3.new(0, 0, 0)
edit_6.BackgroundTransparency = 1
edit_6.BorderColor3 = Color3.new(0.686275, 0.686275, 0.686275)
edit_6.Position = UDim2.new(0.5, 0, 0, 0)
edit_6.Size = UDim2.new(0.5, 0, 1, -1)
edit_6.ZIndex = 10

check_6.Name = "check"
check_6.Parent = edit_6
check_6.BackgroundColor3 = Color3.new(0.866667, 0.866667, 0.870588)
check_6.BorderSizePixel = 0
check_6.Position = UDim2.new(0, 5, 0, 5)
check_6.Size = UDim2.new(0, 12, 0, 12)
check_6.Visible = false
check_6.ZIndex = 10

box_6.Name = "box"
box_6.Parent = edit_6
box_6.BackgroundTransparency = 1
box_6.Position = UDim2.new(0, 5, 0, 0)
box_6.Size = UDim2.new(1, -10, 1, 0)
box_6.Visible = false
box_6.ZIndex = 10
box_6.Font = Enum.Font.SourceSans
box_6.FontSize = Enum.FontSize.Size14
box_6.Text = ""
box_6.TextColor3 = Color3.new(1, 1, 1)
box_6.TextStrokeColor3 = Color3.new(1, 1, 1)
box_6.TextWrapped = true
box_6.TextXAlignment = Enum.TextXAlignment.Left

locked_11.Name = "locked"
locked_11.Parent = edit_6
locked_11.BackgroundTransparency = 1
locked_11.Position = UDim2.new(0, 5, 0, 0)
locked_11.Size = UDim2.new(1, -10, 1, 0)
locked_11.ZIndex = 10
locked_11.Font = Enum.Font.SourceSans
locked_11.FontSize = Enum.FontSize.Size14
locked_11.Text = "Baseplate"
locked_11.TextColor3 = Color3.new(1, 1, 1)
locked_11.TextStrokeColor3 = Color3.new(1, 1, 1)
locked_11.TextWrapped = true
locked_11.TextXAlignment = Enum.TextXAlignment.Left

border_6.Name = "border"
border_6.Parent = property_6
border_6.BackgroundColor3 = Color3.new(0, 0, 0)
border_6.BackgroundTransparency = 1
border_6.BorderColor3 = Color3.new(0.686275, 0.686275, 0.686275)
border_6.BorderSizePixel = 0
border_6.Position = UDim2.new(0.5, 0, 0, 0)
border_6.Size = UDim2.new(0, 1, 1, 0)
border_6.ZIndex = 10

name_6.Name = "name"
name_6.Parent = property_6
name_6.BackgroundColor3 = Color3.new(0, 0, 0)
name_6.BackgroundTransparency = 1
name_6.BorderColor3 = Color3.new(0.686275, 0.686275, 0.686275)
name_6.Size = UDim2.new(0.5, 0, 1, -1)
name_6.ZIndex = 10

locked_12.Name = "locked"
locked_12.Parent = name_6
locked_12.BackgroundTransparency = 1
locked_12.Position = UDim2.new(0, 5, 0, 0)
locked_12.Size = UDim2.new(1, -10, 1, 0)
locked_12.ZIndex = 10
locked_12.Font = Enum.Font.SourceSans
locked_12.FontSize = Enum.FontSize.Size14
locked_12.Text = "Parent"
locked_12.TextColor3 = Color3.new(1, 1, 1)
locked_12.TextStrokeColor3 = Color3.new(1, 1, 1)
locked_12.TextWrapped = true
locked_12.TextXAlignment = Enum.TextXAlignment.Left

unlocked_6.Name = "unlocked"
unlocked_6.Parent = name_6
unlocked_6.BackgroundTransparency = 1
unlocked_6.Position = UDim2.new(0, 5, 0, 0)
unlocked_6.Size = UDim2.new(1, -10, 1, 0)
unlocked_6.Visible = false
unlocked_6.ZIndex = 10
unlocked_6.Font = Enum.Font.SourceSans
unlocked_6.FontSize = Enum.FontSize.Size14
unlocked_6.Text = "Parent"
unlocked_6.TextColor3 = Color3.new(1, 1, 1)
unlocked_6.TextStrokeColor3 = Color3.new(1, 1, 1)
unlocked_6.TextWrapped = true
unlocked_6.TextXAlignment = Enum.TextXAlignment.Left

ScrollFrame_3.Name = "ScrollFrame"
ScrollFrame_3.Parent = PropertiesPanel
ScrollFrame_3.BackgroundColor3 = Color3.new(0, 0, 0)
ScrollFrame_3.BackgroundTransparency = 1
ScrollFrame_3.BorderColor3 = Color3.new(0.584314, 0.584314, 0.584314)
ScrollFrame_3.BorderSizePixel = 0
ScrollFrame_3.Position = UDim2.new(1, -16, 0, 18)
ScrollFrame_3.Size = UDim2.new(0, 16, 1, -18)
ScrollFrame_3.ZIndex = 10

ScrollBar_3.Name = "ScrollBar"
ScrollBar_3.Parent = ScrollFrame_3
ScrollBar_3.BackgroundColor3 = Color3.new(0, 0, 0)
ScrollBar_3.BackgroundTransparency = 1
ScrollBar_3.BorderColor3 = Color3.new(0.584314, 0.584314, 0.584314)
ScrollBar_3.BorderSizePixel = 0
ScrollBar_3.Position = UDim2.new(0, 0, 0, 16)
ScrollBar_3.Size = UDim2.new(1, 0, 1, -32)
ScrollBar_3.ZIndex = 10
ScrollBar_3.AutoButtonColor = false
ScrollBar_3.ImageColor3 = Color3.new(0, 0, 0)

ScrollThumb_3.Name = "ScrollThumb"
ScrollThumb_3.Parent = ScrollBar_3
ScrollThumb_3.BackgroundColor3 = Color3.new(0, 0, 0)
ScrollThumb_3.BackgroundTransparency = 1
ScrollThumb_3.BorderColor3 = Color3.new(0.584314, 0.584314, 0.584314)
ScrollThumb_3.BorderSizePixel = 0
ScrollThumb_3.Draggable = true
ScrollThumb_3.Size = UDim2.new(0, 16, 0, 75)
ScrollThumb_3.ZIndex = 10
ScrollThumb_3.AutoButtonColor = false
ScrollThumb_3.ImageColor3 = Color3.new(0, 0, 0)

GripGraphic_3.Name = "Grip Graphic"
GripGraphic_3.Parent = ScrollThumb_3
GripGraphic_3.BackgroundTransparency = 1
GripGraphic_3.BorderSizePixel = 0
GripGraphic_3.Position = UDim2.new(0.5, -3, 0.5, -3)
GripGraphic_3.Size = UDim2.new(0, 6, 0, 6)
GripGraphic_3.ZIndex = 10

Frame_7.Parent = GripGraphic_3
Frame_7.BorderSizePixel = 0
Frame_7.Position = UDim2.new(0, 0, 0.666666687, 0)
Frame_7.Size = UDim2.new(1, 0, 0.166666672, 0)
Frame_7.ZIndex = 10

Frame_8.Parent = GripGraphic_3
Frame_8.BorderSizePixel = 0
Frame_8.Position = UDim2.new(0, 0, 0.333333343, 0)
Frame_8.Size = UDim2.new(1, 0, 0.166666672, 0)
Frame_8.ZIndex = 10

Frame_9.Parent = GripGraphic_3
Frame_9.BorderSizePixel = 0
Frame_9.Size = UDim2.new(1, 0, 0.166666672, 0)
Frame_9.ZIndex = 10

ScrollUp_3.Name = "ScrollUp"
ScrollUp_3.Parent = ScrollFrame_3
ScrollUp_3.Active = false
ScrollUp_3.BackgroundColor3 = Color3.new(0, 0, 0)
ScrollUp_3.BackgroundTransparency = 1
ScrollUp_3.BorderColor3 = Color3.new(0.584314, 0.584314, 0.584314)
ScrollUp_3.BorderSizePixel = 0
ScrollUp_3.Size = UDim2.new(0, 16, 0, 16)
ScrollUp_3.ZIndex = 10
ScrollUp_3.AutoButtonColor = false

ArrowGraphic_5.Name = "Arrow Graphic"
ArrowGraphic_5.Parent = ScrollUp_3
ArrowGraphic_5.BackgroundTransparency = 1
ArrowGraphic_5.BorderSizePixel = 0
ArrowGraphic_5.Position = UDim2.new(0.5, -4, 0.5, -4)
ArrowGraphic_5.Size = UDim2.new(0, 8, 0, 8)
ArrowGraphic_5.ZIndex = 10

Graphic_17.Name = "Graphic"
Graphic_17.Parent = ArrowGraphic_5
Graphic_17.BackgroundColor3 = Color3.new(0.584314, 0.584314, 0.584314)
Graphic_17.BackgroundTransparency = 0.69999998807907
Graphic_17.BorderSizePixel = 0
Graphic_17.Position = UDim2.new(0, 0, 0.625, 0)
Graphic_17.Size = UDim2.new(1, 0, 0.125, 0)
Graphic_17.ZIndex = 10

Graphic_18.Name = "Graphic"
Graphic_18.Parent = ArrowGraphic_5
Graphic_18.BackgroundColor3 = Color3.new(0.584314, 0.584314, 0.584314)
Graphic_18.BackgroundTransparency = 0.69999998807907
Graphic_18.BorderSizePixel = 0
Graphic_18.Position = UDim2.new(0.125, 0, 0.5, 0)
Graphic_18.Size = UDim2.new(0.75, 0, 0.125, 0)
Graphic_18.ZIndex = 10

Graphic_19.Name = "Graphic"
Graphic_19.Parent = ArrowGraphic_5
Graphic_19.BackgroundColor3 = Color3.new(0.584314, 0.584314, 0.584314)
Graphic_19.BackgroundTransparency = 0.69999998807907
Graphic_19.BorderSizePixel = 0
Graphic_19.Position = UDim2.new(0.25, 0, 0.375, 0)
Graphic_19.Size = UDim2.new(0.5, 0, 0.125, 0)
Graphic_19.ZIndex = 10

Graphic_20.Name = "Graphic"
Graphic_20.Parent = ArrowGraphic_5
Graphic_20.BackgroundColor3 = Color3.new(0.584314, 0.584314, 0.584314)
Graphic_20.BackgroundTransparency = 0.69999998807907
Graphic_20.BorderSizePixel = 0
Graphic_20.Position = UDim2.new(0.375, 0, 0.25, 0)
Graphic_20.Size = UDim2.new(0.25, 0, 0.125, 0)
Graphic_20.ZIndex = 10

ScrollDown_3.Name = "ScrollDown"
ScrollDown_3.Parent = ScrollFrame_3
ScrollDown_3.BackgroundColor3 = Color3.new(0, 0, 0)
ScrollDown_3.BackgroundTransparency = 1
ScrollDown_3.BorderColor3 = Color3.new(0.584314, 0.584314, 0.584314)
ScrollDown_3.BorderSizePixel = 0
ScrollDown_3.Position = UDim2.new(0, 0, 1, -16)
ScrollDown_3.Size = UDim2.new(0, 16, 0, 16)
ScrollDown_3.ZIndex = 10

ArrowGraphic_6.Name = "Arrow Graphic"
ArrowGraphic_6.Parent = ScrollDown_3
ArrowGraphic_6.BackgroundTransparency = 1
ArrowGraphic_6.BorderSizePixel = 0
ArrowGraphic_6.Position = UDim2.new(0.5, -4, 0.5, -4)
ArrowGraphic_6.Size = UDim2.new(0, 8, 0, 8)
ArrowGraphic_6.ZIndex = 10

Graphic_21.Name = "Graphic"
Graphic_21.Parent = ArrowGraphic_6
Graphic_21.BackgroundColor3 = Color3.new(0.584314, 0.584314, 0.584314)
Graphic_21.BorderSizePixel = 0
Graphic_21.Position = UDim2.new(0, 0, 0.25, 0)
Graphic_21.Size = UDim2.new(1, 0, 0.125, 0)
Graphic_21.ZIndex = 10

Graphic_22.Name = "Graphic"
Graphic_22.Parent = ArrowGraphic_6
Graphic_22.BackgroundColor3 = Color3.new(0.584314, 0.584314, 0.584314)
Graphic_22.BorderSizePixel = 0
Graphic_22.Position = UDim2.new(0.125, 0, 0.375, 0)
Graphic_22.Size = UDim2.new(0.75, 0, 0.125, 0)
Graphic_22.ZIndex = 10

Graphic_23.Name = "Graphic"
Graphic_23.Parent = ArrowGraphic_6
Graphic_23.BackgroundColor3 = Color3.new(0.584314, 0.584314, 0.584314)
Graphic_23.BorderSizePixel = 0
Graphic_23.Position = UDim2.new(0.25, 0, 0.5, 0)
Graphic_23.Size = UDim2.new(0.5, 0, 0.125, 0)
Graphic_23.ZIndex = 10

Graphic_24.Name = "Graphic"
Graphic_24.Parent = ArrowGraphic_6
Graphic_24.BackgroundColor3 = Color3.new(0.584314, 0.584314, 0.584314)
Graphic_24.BorderSizePixel = 0
Graphic_24.Position = UDim2.new(0.375, 0, 0.625, 0)
Graphic_24.Size = UDim2.new(0.25, 0, 0.125, 0)
Graphic_24.ZIndex = 10

property_7.Name = "property"
property_7.Parent = PropertiesPanel
property_7.BackgroundColor3 = Color3.new(0, 0, 0)
property_7.BackgroundTransparency = 1
property_7.BorderColor3 = Color3.new(0.584314, 0.584314, 0.584314)
property_7.BorderSizePixel = 0
property_7.Position = UDim2.new(0, 0, 0, 1)
property_7.Size = UDim2.new(1, 0, 0, 22)
property_7.Visible = false
property_7.ZIndex = 10

edit_7.Name = "edit"
edit_7.Parent = property_7
edit_7.BackgroundColor3 = Color3.new(0, 0, 0)
edit_7.BackgroundTransparency = 1
edit_7.BorderColor3 = Color3.new(0.686275, 0.686275, 0.686275)
edit_7.Position = UDim2.new(0.5, 0, 0, 0)
edit_7.Size = UDim2.new(0.5, 0, 1, -1)
edit_7.ZIndex = 10

check_7.Name = "check"
check_7.Parent = edit_7
check_7.BackgroundColor3 = Color3.new(0.866667, 0.866667, 0.870588)
check_7.BorderSizePixel = 0
check_7.Position = UDim2.new(0, 5, 0, 5)
check_7.Size = UDim2.new(0, 12, 0, 12)
check_7.Visible = false
check_7.ZIndex = 10

box_7.Name = "box"
box_7.Parent = edit_7
box_7.BackgroundTransparency = 1
box_7.Position = UDim2.new(0, 5, 0, 0)
box_7.Size = UDim2.new(1, -10, 1, 0)
box_7.Visible = false
box_7.ZIndex = 10
box_7.Font = Enum.Font.SourceSans
box_7.FontSize = Enum.FontSize.Size14
box_7.Text = ""
box_7.TextColor3 = Color3.new(1, 1, 1)
box_7.TextStrokeColor3 = Color3.new(1, 1, 1)
box_7.TextWrapped = true
box_7.TextXAlignment = Enum.TextXAlignment.Left

locked_13.Name = "locked"
locked_13.Parent = edit_7
locked_13.BackgroundTransparency = 1
locked_13.Position = UDim2.new(0, 5, 0, 0)
locked_13.Size = UDim2.new(1, -10, 1, 0)
locked_13.Visible = false
locked_13.ZIndex = 10
locked_13.Font = Enum.Font.SourceSans
locked_13.FontSize = Enum.FontSize.Size14
locked_13.Text = ""
locked_13.TextColor3 = Color3.new(1, 1, 1)
locked_13.TextStrokeColor3 = Color3.new(1, 1, 1)
locked_13.TextWrapped = true
locked_13.TextXAlignment = Enum.TextXAlignment.Left

border_7.Name = "border"
border_7.Parent = property_7
border_7.BackgroundColor3 = Color3.new(0, 0, 0)
border_7.BackgroundTransparency = 1
border_7.BorderColor3 = Color3.new(0.686275, 0.686275, 0.686275)
border_7.BorderSizePixel = 0
border_7.Position = UDim2.new(0.5, 0, 0, 0)
border_7.Size = UDim2.new(0, 1, 1, 0)
border_7.ZIndex = 10

name_7.Name = "name"
name_7.Parent = property_7
name_7.BackgroundColor3 = Color3.new(0, 0, 0)
name_7.BackgroundTransparency = 1
name_7.BorderColor3 = Color3.new(0.686275, 0.686275, 0.686275)
name_7.Size = UDim2.new(0.5, 0, 1, -1)
name_7.ZIndex = 10

locked_14.Name = "locked"
locked_14.Parent = name_7
locked_14.BackgroundTransparency = 1
locked_14.Position = UDim2.new(0, 5, 0, 0)
locked_14.Size = UDim2.new(1, -10, 1, 0)
locked_14.Visible = false
locked_14.ZIndex = 10
locked_14.Font = Enum.Font.SourceSans
locked_14.FontSize = Enum.FontSize.Size14
locked_14.Text = ""
locked_14.TextColor3 = Color3.new(1, 1, 1)
locked_14.TextStrokeColor3 = Color3.new(1, 1, 1)
locked_14.TextWrapped = true
locked_14.TextXAlignment = Enum.TextXAlignment.Left

unlocked_7.Name = "unlocked"
unlocked_7.Parent = name_7
unlocked_7.BackgroundTransparency = 1
unlocked_7.Position = UDim2.new(0, 5, 0, 0)
unlocked_7.Size = UDim2.new(1, -10, 1, 0)
unlocked_7.Visible = false
unlocked_7.ZIndex = 10
unlocked_7.Font = Enum.Font.SourceSans
unlocked_7.FontSize = Enum.FontSize.Size14
unlocked_7.Text = ""
unlocked_7.TextColor3 = Color3.new(1, 1, 1)
unlocked_7.TextStrokeColor3 = Color3.new(1, 1, 1)
unlocked_7.TextWrapped = true
unlocked_7.TextXAlignment = Enum.TextXAlignment.Left

TextWidth_3.Name = "TextWidth"
TextWidth_3.Parent = PropertiesPanel
TextWidth_3.Size = UDim2.new(1, 0, 1, 0)
TextWidth_3.Visible = false
TextWidth_3.ZIndex = 10
TextWidth_3.Font = Enum.Font.SourceSans
TextWidth_3.FontSize = Enum.FontSize.Size14
TextWidth_3.Text = "TweenService"
TextWidth_3.TextColor3 = Color3.new(1, 1, 1)
TextWidth_3.TextStrokeColor3 = Color3.new(1, 1, 1)
TextWidth_3.TextXAlignment = Enum.TextXAlignment.Left

BindableFunction1.Name = "GetApi"
BindableFunction1.Parent = PropertiesPanel
BindableFunction1.Archivable = true

BindableFunction2.Name = "GetAwaiting"
BindableFunction2.Parent = PropertiesPanel
BindableFunction2.Archivable = true

BindableEvent1.Name = "SetAwaiting"
BindableEvent1.Parent = PropertiesPanel
BindableEvent1.Archivable = true

BindableFunction3.Name = "GetOption"
BindableFunction3.Parent = ExplorerPanel
BindableFunction3.Archivable = true

BindableFunction4.Name = "GetSelection"
BindableFunction4.Parent = ExplorerPanel
BindableFunction4.Archivable = true

BindableFunction5.Name = "SetOption"
BindableFunction5.Parent = ExplorerPanel
BindableFunction5.Archivable = true

BindableFunction6.Name = "SetSelection"
BindableFunction6.Parent = ExplorerPanel
BindableFunction6.Archivable = true

BindableEvent2.Name = "SelectionChanged"
BindableEvent2.Parent = ExplorerPanel
BindableEvent2.Archivable = true

	return VPExplorer
end

local MainGui = CreateMainGui()
MainGui.Parent = game.CoreGui
wait(3)
local OpenGuiFrame = MainGui['Explorer Open/Close']
local OpenButton = OpenGuiFrame.ImageButton
local ExplorerFolder = MainGui['ExplorerFolder']
--[[Explorer Open/Close]]--
spawn(function()
	local player = game.Players.LocalPlayer
List = ExplorerFolder
local UIS = game:GetService('UserInputService')
game.StarterGui:SetCoreGuiEnabled('Chat', true)
Opened = UDim2.new(0, 0,0, 0)
Closed = UDim2.new(-1, 0,0, 0)
local Button = OpenButton



OpenButton.MouseEnter:connect(function(test)
	OpenButton.ImageColor3 = Color3.new(0,0,0)

end)
OpenButton.MouseLeave:connect(function(test)
	OpenButton.ImageColor3 = Color3.fromRGB(255,255,255)
end)


Button.MouseButton1Down:connect(function()
if List.Position == Closed then
		_G.Disabled = false
local camera = workspace.CurrentCamera
game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character.Humanoid
game.Workspace.CurrentCamera.CameraType = "Custom"
			List:TweenPosition(Opened, "InOut", "Sine", 1, true)
			wait(1)
elseif List.Position == Opened then
		_G.Disabled = true
game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character.Humanoid
game.Workspace.CurrentCamera.CameraType = "Custom"
			List:TweenPosition(Closed, "InOut", "Sine", 1, true)
			
			wait(1)
		end
end)
end)


--[[SelectionBox's]]--


spawn(function()
	local StudioL = ExplorerFolder
local ExplorerL = StudioL:WaitForChild("ExplorerPanel")
local SelectionCL = ExplorerL:WaitForChild("SelectionChanged")
local GSelectionL = ExplorerL:WaitForChild("GetSelection")
local SelectionBoxL = Instance.new("SelectionBox", StudioL)
SelectionBoxL.LineThickness = 0.05
StartedL = false
function RColorL(s, v)
s.Color3 = Color3.new(v/255,v/255,v/255)
end
function StopFadeL()
	StartedL = false
end
function StartFadeL()
	local addL = false
	local currentL = 200
	StartedL = true
	spawn(function()
	repeat
		if addL == true then
		currentL = currentL + 5
		if currentL >= 250 then
			addL = false
		end
	else
		currentL = currentL - 5
		if currentL <= 200 then
			addL = true
		end
	end
	RColorL(SelectionBoxL, currentL)
	wait(0.05)
	until StartedL == false
	end)
end
SelectionCL.Event:connect(function()
	StopFadeL()
	local ObjectL = GSelectionL:Invoke()[1]
	if pcall(function() SelectionBoxL.Adornee = ObjectL end) then
		StartFadeL()
	else
		pcall(function() SelectionBoxL.Adornee = nil end)
	end
end)
end)


--[[CommandPanel]]--


spawn(function()
local Explorer =ExplorerFolder:WaitForChild("ExplorerPanel")
Explorer:WaitForChild("List")
Explorer:WaitForChild("SelectionChanged")
local Output = ExplorerFolder:WaitForChild("CommandPanel")
local Command = ExplorerFolder:WaitForChild("CommandPanel")
local Properties = ExplorerFolder:WaitForChild("PropertiesPanel")
local Studio = ExplorerFolder

Command:WaitForChild("TextButton").MouseButton1Click:connect(function()
	print(">"," ran script:",Command.TextBox.Text)
 loadstring(Command.TextBox.Text)() 
wait(1)
Command.TextBox.Text = ""
end)
end)


--[[ExplorerPanel]]--
spawn(function()
	-- initial states
local Option = {
	-- can modify objects
	Modifiable = true;
	-- can select objects
	Selectable = true;
}

-- general size of GUI objects, in pixels
local GUI_SIZE = 16
-- padding between items within each entry
local ENTRY_PADDING = 1
-- padding between each entry
local ENTRY_MARGIN = 1
CreateInstanceF = ExplorerFolder:WaitForChild("CreateInstance")


local ENTRY_SIZE = GUI_SIZE + ENTRY_PADDING*2
local ENTRY_BOUND = ENTRY_SIZE + ENTRY_MARGIN
local HEADER_SIZE = ENTRY_SIZE

local FONT = 'SourceSans'
local FONT_SIZE do
	local size = {8,9,10,11,12,14,18,24,36,48}
	local s
	local n = math.huge
	for i = 1,#size do
		if size[i] <= GUI_SIZE then
			FONT_SIZE = i - 1
		end
	end
end

local GuiColor = {
	Background      = Color3.new(0/0, 0/0, 0/0);
	Border          = Color3.new(0/0, 0/0, 0/0);
	Selected        = Color3.new( 96/255, 140/255, 211/255);
	BorderSelected  = Color3.new( 86/255, 125/255, 188/255);
	Text            = Color3.new(  255/255,   255/255,   255/255);
	TextDisabled    = Color3.new(128/255, 128/255, 128/255);
	TextSelected    = Color3.new(255/255, 255/255, 255/255);
	Button          = Color3.new(221/255, 221/255, 221/255);
	ButtonBorder    = Color3.new(149/255, 149/255, 149/255);
	ButtonSelected  = Color3.new(255/255,   0/255,   0/255);
	Field           = Color3.new(255/255, 255/255, 255/255);
	FieldBorder     = Color3.new(191/255, 191/255, 191/255);
	TitleBackground = Color3.new(0/0, 0/0, 0/0);
}

----------------------------------------------------------------
----------------------------------------------------------------
----------------------------------------------------------------
----------------------------------------------------------------
---- Icon map constants

local MAP_ID = 418720155



-- Indices based on implementation of Icon function.
local BLANK = 150
local ACTION_CUT         = 160
local ACTION_COPY        = 161
local ACTION_PASTE       = 162
local ACTION_DELETE      = 163
local ACTION_SORT        = 164
local ACTION_CUT_OVER    = 174
local ACTION_COPY_OVER   = 175
local ACTION_PASTE_OVER  = 176
local ACTION_DELETE_OVER = 177
local ACTION_SORT_OVER   = 178

local NODE_COLLAPSED      = 165
local NODE_EXPANDED       = 166
local NODE_COLLAPSED_OVER = 179
local NODE_EXPANDED_OVER  = 180

local ExplorerIndex = {
	["Accessory"] = 32;
	["Accoutrement"] = 32;
	["AdService"] = 73;
	["Animation"] = 60;
	["AnimationController"] = 60;
	["AnimationTrack"] = 60;
	["Animator"] = 60;
	["ArcHandles"] = 56;
	["AssetService"] = 72;
	["Attachment"] = 34;
	["Backpack"] = 20;
	["BadgeService"] = 75;
	["BallSocketConstraint"] = 89;
	["BillboardGui"] = 64;
	["BinaryStringValue"] = 4;
	["BindableEvent"] = 67;
	["BindableFunction"] = 66;
	["BlockMesh"] = 8;
	["BloomEffect"] = 90;
	["BlurEffect"] = 90;
	["BodyAngularVelocity"] = 14;
	["BodyForce"] = 14;
	["BodyGyro"] = 14;
	["BodyPosition"] = 14;
	["BodyThrust"] = 14;
	["BodyVelocity"] = 14;
	["BoolValue"] = 4;
	["BoxHandleAdornment"] = 54;
	["BrickColorValue"] = 4;
	["Camera"] = 5;
	["CFrameValue"] = 4;
	["CharacterMesh"] = 60;
	["Chat"] = 33;
	["ClickDetector"] = 41;
	["CollectionService"] = 30;
	["Color3Value"] = 4;
	["ColorCorrectionEffect"] = 90;
	["ConeHandleAdornment"] = 54;
	["Configuration"] = 58;
	["ContentProvider"] = 72;
	["ContextActionService"] = 41;
	["CoreGui"] = 46;
	["CoreScript"] = 18;
	["CornerWedgePart"] = 1;
	["CustomEvent"] = 4;
	["CustomEventReceiver"] = 4;
	["CylinderHandleAdornment"] = 54;
	["CylinderMesh"] = 8;
	["CylindricalConstraint"] = 89;
	["Debris"] = 30;
	["Decal"] = 7;
	["Dialog"] = 62;
	["DialogChoice"] = 63;
	["DoubleConstrainedValue"] = 4;
	["Explosion"] = 36;
	["FileMesh"] = 8;
	["Fire"] = 61;
	["Flag"] = 38;
	["FlagStand"] = 39;
	["FloorWire"] = 4;
	["Folder"] = 70;
	["ForceField"] = 37;
	["Frame"] = 48;
	["GamePassService"] = 19;
	["Glue"] = 34;
	["GuiButton"] = 52;
	["GuiMain"] = 47;
	["GuiService"] = 47;
	["Handles"] = 53;
	["HapticService"] = 84;
	["Hat"] = 45;
	["HingeConstraint"] = 89;
	["Hint"] = 33;
	["HopperBin"] = 22;
	["HttpService"] = 76;
	["Humanoid"] = 9;
	["ImageButton"] = 52;
	["ImageLabel"] = 49;
	["InsertService"] = 72;
	["IntConstrainedValue"] = 4;
	["IntValue"] = 4;
	["JointInstance"] = 34;
	["JointsService"] = 34;
	["Keyframe"] = 60;
	["KeyframeSequence"] = 60;
	["KeyframeSequenceProvider"] = 60;
	["Lighting"] = 13;
	["LineHandleAdornment"] = 54;
	["LocalScript"] = 18;
	["LogService"] = 87;
	["MarketplaceService"] = 46;
	["Message"] = 33;
	["Model"] = 2;
	["ModuleScript"] = 71;
	["Motor"] = 34;
	["Motor6D"] = 34;
	["MoveToConstraint"] = 89;
	["NegateOperation"] = 78;
	["NetworkClient"] = 16;
	["NetworkReplicator"] = 29;
	["NetworkServer"] = 15;
	["NumberValue"] = 4;
	["ObjectValue"] = 4;
	["Pants"] = 44;
	["ParallelRampPart"] = 1;
	["Part"] = 1;
	["ParticleEmitter"] = 69;
	["PartPairLasso"] = 57;
	["PathfindingService"] = 37;
	["Platform"] = 35;
	["Player"] = 12;
	["PlayerGui"] = 46;
	["Players"] = 21;
	["PlayerScripts"] = 82;
	["PointLight"] = 13;
	["PointsService"] = 83;
	["Pose"] = 60;
	["PrismaticConstraint"] = 89;
	["PrismPart"] = 1;
	["PyramidPart"] = 1;
	["RayValue"] = 4;
	["ReflectionMetadata"] = 86;
	["ReflectionMetadataCallbacks"] = 86;
	["ReflectionMetadataClass"] = 86;
	["ReflectionMetadataClasses"] = 86;
	["ReflectionMetadataEnum"] = 86;
	["ReflectionMetadataEnumItem"] = 86;
	["ReflectionMetadataEnums"] = 86;
	["ReflectionMetadataEvents"] = 86;
	["ReflectionMetadataFunctions"] = 86;
	["ReflectionMetadataMember"] = 86;
	["ReflectionMetadataProperties"] = 86;
	["ReflectionMetadataYieldFunctions"] = 86;
	["RemoteEvent"] = 80;
	["RemoteFunction"] = 79;
	["ReplicatedFirst"] = 72;
	["ReplicatedStorage"] = 72;
	["RightAngleRampPart"] = 1;
	["RocketPropulsion"] = 14;
	["RodConstraint"] = 89;
	["RopeConstraint"] = 89;
	["Rotate"] = 34;
	["RotateP"] = 34;
	["RotateV"] = 34;
	["RunService"] = 66;
	["ScreenGui"] = 47;
	["Script"] = 6;
	["ScrollingFrame"] = 48;
	["Seat"] = 35;
	["Selection"] = 55;
	["SelectionBox"] = 54;
	["SelectionPartLasso"] = 57;
	["SelectionPointLasso"] = 57;
	["SelectionSphere"] = 54;
	["ServerScriptService"] = 0;
	["ServerStorage"] = 74;
	["Shirt"] = 43;
	["ShirtGraphic"] = 40;
	["SkateboardPlatform"] = 35;
	["Sky"] = 28;
	["SlidingBallConstraint"] = 89;
	["Smoke"] = 59;
	["Snap"] = 34;
	["Sound"] = 11;
	["SoundService"] = 31;
	["Sparkles"] = 42;
	["SpawnLocation"] = 25;
	["SpecialMesh"] = 8;
	["SphereHandleAdornment"] = 54;
	["SpotLight"] = 13;
	["SpringConstraint"] = 89;
	["StarterCharacterScripts"] = 82;
	["StarterGear"] = 20;
	["StarterGui"] = 46;
	["StarterPack"] = 20;
	["StarterPlayer"] = 88;
	["StarterPlayerScripts"] = 82;
	["Status"] = 2;
	["StringValue"] = 4;
	["SunRaysEffect"] = 90;
	["SurfaceGui"] = 64;
	["SurfaceLight"] = 13;
	["SurfaceSelection"] = 55;
	["Team"] = 24;
	["Teams"] = 23;
	["TeleportService"] = 81;
	["Terrain"] = 65;
	["TerrainRegion"] = 65;
	["TestService"] = 68;
	["TextBox"] = 51;
	["TextButton"] = 51;
	["TextLabel"] = 50;
	["Texture"] = 10;
	["TextureTrail"] = 4;
	["Tool"] = 17;
	["TouchTransmitter"] = 37;
	["TrussPart"] = 1;
	["UnionOperation"] = 77;
	["UserInputService"] = 84;
	["Vector3Value"] = 4;
	["VehicleSeat"] = 35;
	["VelocityMotor"] = 34;
	["WedgePart"] = 1;
	["Weld"] = 34;
	["Workspace"] = 19;
}
----------------------------------------------------------------
----------------------------------------------------------------
----------------------------------------------------------------
----------------------------------------------------------------
----------------------------------------------------------------

function Create(ty,data)
	local obj
	if type(ty) == 'string' then
		obj = Instance.new(ty)
	else
		obj = ty
	end
	for k, v in pairs(data) do
		if type(k) == 'number' then
			v.Parent = obj
		else
			obj[k] = v
		end
	end
	return obj
end

-- Connects a function to an event such that it fires asynchronously
function Connect(event,func)
	return event:connect(function(...)
		local a = {...}
		Spawn(function() func(unpack(a)) end)
	end)
end

-- returns the ascendant ScreenGui of an object
function GetScreen(screen)
	if screen == nil then return nil end
	while not screen:IsA("ScreenGui") do
		screen = screen.Parent
		if screen == nil then return nil end
	end
	return screen
end

do
	local ZIndexLock = {}
	-- Sets the ZIndex of an object and its descendants. Objects are locked so
	-- that SetZIndexOnChanged doesn't spawn multiple threads that set the
	-- ZIndex of the same object.
	function SetZIndex(object,z)
		if not ZIndexLock[object] then
			ZIndexLock[object] = true
			if object:IsA'GuiObject' then
				object.ZIndex = z
			end
			local children = object:GetChildren()
			for i = 1,#children do
				SetZIndex(children[i],z)
			end
			ZIndexLock[object] = nil
		end
	end

	function SetZIndexOnChanged(object)
		return object.Changed:connect(function(p)
			if p == "ZIndex" then
				SetZIndex(object,object.ZIndex)
			end
		end)
	end
end

---- IconMap ----
-- Image size: 256px x 256px
-- Icon size: 16px x 16px
-- Padding between each icon: 2px
-- Padding around image edge: 1px
-- Total icons: 14 x 14 (196)
local Icon do
	local iconMap = 'http://www.roblox.com/asset/?id=' .. MAP_ID
	Game:GetService('ContentProvider'):Preload(iconMap)
	local iconDehash do
		-- 14 x 14, 0-based input, 0-based output
		local f=math.floor
		function iconDehash(h)
			return f(h/14%14),f(h%14)
		end
	end

	function Icon(IconFrame,index)
		local row,col = iconDehash(index)
		local mapSize = Vector2.new(256,256)
		local pad,border = 2,1
		local iconSize = 16

		local class = 'Frame'
		if type(IconFrame) == 'string' then
			class = IconFrame
			IconFrame = nil
		end

		if not IconFrame then
			IconFrame = Create(class,{
				Name = "Icon";
				BackgroundTransparency = 1;
				ClipsDescendants = true;
				Create('ImageLabel',{
					Name = "IconMap";
					Active = false;
					BackgroundTransparency = 1;
					Image = iconMap;
					Size = UDim2.new(mapSize.x/iconSize,0,mapSize.y/iconSize,0);
				});
			})
		end

		IconFrame.IconMap.Position = UDim2.new(-col - (pad*(col+1) + border)/iconSize,0,-row - (pad*(row+1) + border)/iconSize,0)
		return IconFrame
	end
end

----------------------------------------------------------------
----------------------------------------------------------------
----------------------------------------------------------------
----------------------------------------------------------------
---- ScrollBar
do
	-- AutoButtonColor doesn't always reset properly
	local function ResetButtonColor(button)
		local active = button.Active
		button.Active = not active
		button.Active = active
	end

	local function ArrowGraphic(size,dir,scaled,template)
		local Frame = Create('Frame',{
			Name = "Arrow Graphic";
			BorderSizePixel = 0;
			Size = UDim2.new(0,size,0,size);
			Transparency = 1;
		})
		if not template then
			template = Instance.new("Frame")
			template.BorderSizePixel = 0
		end

		local transform
		if dir == nil or dir == 'Up' then
			function transform(p,s) return p,s end
		elseif dir == 'Down' then
			function transform(p,s) return UDim2.new(0,p.X.Offset,0,size-p.Y.Offset-1),s end
		elseif dir == 'Left' then
			function transform(p,s) return UDim2.new(0,p.Y.Offset,0,p.X.Offset),UDim2.new(0,s.Y.Offset,0,s.X.Offset) end
		elseif dir == 'Right' then
			function transform(p,s) return UDim2.new(0,size-p.Y.Offset-1,0,p.X.Offset),UDim2.new(0,s.Y.Offset,0,s.X.Offset) end
		end

		local scale
		if scaled then
			function scale(p,s) return UDim2.new(p.X.Offset/size,0,p.Y.Offset/size,0),UDim2.new(s.X.Offset/size,0,s.Y.Offset/size,0) end
		else
			function scale(p,s) return p,s end
		end

		local o = math.floor(size/4)
		if size%2 == 0 then
			local n = size/2-1
			for i = 0,n do
				local t = template:Clone()
				local p,s = scale(transform(
					UDim2.new(0,n-i,0,o+i),
					UDim2.new(0,(i+1)*2,0,1)
				))
				t.Position = p
				t.Size = s
				t.Parent = Frame
			end
		else
			local n = (size-1)/2
			for i = 0,n do
				local t = template:Clone()
				local p,s = scale(transform(
					UDim2.new(0,n-i,0,o+i),
					UDim2.new(0,i*2+1,0,1)
				))
				t.Position = p
				t.Size = s
				t.Parent = Frame
			end
		end
		if size%4 > 1 then
			local t = template:Clone()
			local p,s = scale(transform(
				UDim2.new(0,0,0,size-o-1),
				UDim2.new(0,size,0,1)
			))
			t.Position = p
			t.Size = s
			t.Parent = Frame
		end
		return Frame
	end


	local function GripGraphic(size,dir,spacing,scaled,template)
		local Frame = Create('Frame',{
			Name = "Grip Graphic";
			BorderSizePixel = 0;
			Size = UDim2.new(0,size.x,0,size.y);
			Transparency = 1;
		})
		if not template then
			template = Instance.new("Frame")
			template.BorderSizePixel = 0
		end

		spacing = spacing or 2

		local scale
		if scaled then
			function scale(p) return UDim2.new(p.X.Offset/size.x,0,p.Y.Offset/size.y,0) end
		else
			function scale(p) return p end
		end

		if dir == 'Vertical' then
			for i=0,size.x-1,spacing do
				local t = template:Clone()
				t.Size = scale(UDim2.new(0,1,0,size.y))
				t.Position = scale(UDim2.new(0,i,0,0))
				t.Parent = Frame
			end
		elseif dir == nil or dir == 'Horizontal' then
			for i=0,size.y-1,spacing do
				local t = template:Clone()
				t.Size = scale(UDim2.new(0,size.x,0,1))
				t.Position = scale(UDim2.new(0,0,0,i))
				t.Parent = Frame
			end
		end

		return Frame
	end

	local mt = {
		__index = {
			GetScrollPercent = function(self)
				return self.ScrollIndex/(self.TotalSpace-self.VisibleSpace)
			end;
			CanScrollDown = function(self)
				return self.ScrollIndex + self.VisibleSpace < self.TotalSpace
			end;
			CanScrollUp = function(self)
				return self.ScrollIndex > 0
			end;
			ScrollDown = function(self)
				self.ScrollIndex = self.ScrollIndex + self.PageIncrement
				self:Update()
			end;
			ScrollUp = function(self)
				self.ScrollIndex = self.ScrollIndex - self.PageIncrement
				self:Update()
			end;
			ScrollTo = function(self,index)
				self.ScrollIndex = index
				self:Update()
			end;
			SetScrollPercent = function(self,percent)
				self.ScrollIndex = math.floor((self.TotalSpace - self.VisibleSpace)*percent + 0.5)
				self:Update()
			end;
		};
	}
	mt.__index.CanScrollRight = mt.__index.CanScrollDown
	mt.__index.CanScrollLeft = mt.__index.CanScrollUp
	mt.__index.ScrollLeft = mt.__index.ScrollUp
	mt.__index.ScrollRight = mt.__index.ScrollDown

	function ScrollBar(horizontal)
		-- create row scroll bar
		local ScrollFrame = Create('Frame',{
			Name = "ScrollFrame";
			Position = horizontal and UDim2.new(0,0,1,-GUI_SIZE) or UDim2.new(1,-GUI_SIZE,0,0);
			Size = horizontal and UDim2.new(1,0,0,GUI_SIZE) or UDim2.new(0,GUI_SIZE,1,0);
			BackgroundTransparency = 1;
			Create('ImageButton',{
				Name = "ScrollDown";
				Position = horizontal and UDim2.new(1,-GUI_SIZE,0,0) or UDim2.new(0,0,1,-GUI_SIZE);
				Size = UDim2.new(0, GUI_SIZE, 0, GUI_SIZE);
				BackgroundColor3 = Color3.new(0, 0, 0);
				BorderColor3 = GuiColor.Border;
				  BackgroundTransparency = 1;
				BorderSizePixel = 0;
			});
			Create('ImageButton',{
				Name = "ScrollUp";
				Size = UDim2.new(0, GUI_SIZE, 0, GUI_SIZE);
				BackgroundColor3 = Color3.new(0, 0, 0);
				BorderColor3 = GuiColor.Border;
				  BackgroundTransparency = 1;
				BorderSizePixel = 0;
			});
			Create('ImageButton',{
				Name = "ScrollBar";
				Size = horizontal and UDim2.new(1,-GUI_SIZE*2,1,0) or UDim2.new(1,0,1,-GUI_SIZE*2);
				Position = horizontal and UDim2.new(0,GUI_SIZE,0,0) or UDim2.new(0,0,0,GUI_SIZE);
				AutoButtonColor = false;
				BackgroundColor3 = Color3.new(0, 0, 0);
				BorderColor3 = GuiColor.Border;
				 BackgroundTransparency = 1;
				BorderSizePixel = 0;
				Create('ImageButton',{
					Name = "ScrollThumb";
					AutoButtonColor = false;
					Size = UDim2.new(0, GUI_SIZE, 0, GUI_SIZE);
					BackgroundColor3 = GuiColor.Button;
					BorderColor3 = GuiColor.Border;
					  BackgroundTransparency = 1;
					BorderSizePixel = 0;
				});
			});
		})

		local graphicTemplate = Create('Frame',{
			Name="Graphic";
			BorderSizePixel = 0;
			BackgroundColor3 = GuiColor.Border;
		})
		local graphicSize = GUI_SIZE/2

		local ScrollDownFrame = ScrollFrame.ScrollDown
			local ScrollDownGraphic = ArrowGraphic(graphicSize,horizontal and 'Right' or 'Down',true,graphicTemplate)
			ScrollDownGraphic.Position = UDim2.new(0.5,-graphicSize/2,0.5,-graphicSize/2)
			ScrollDownGraphic.Parent = ScrollDownFrame
		local ScrollUpFrame = ScrollFrame.ScrollUp
			local ScrollUpGraphic = ArrowGraphic(graphicSize,horizontal and 'Left' or 'Up',true,graphicTemplate)
			ScrollUpGraphic.Position = UDim2.new(0.5,-graphicSize/2,0.5,-graphicSize/2)
			ScrollUpGraphic.Parent = ScrollUpFrame
		local ScrollBarFrame = ScrollFrame.ScrollBar
		local ScrollThumbFrame = ScrollBarFrame.ScrollThumb
		do
			local size = GUI_SIZE*3/8
			local Decal = GripGraphic(Vector2.new(size,size),horizontal and 'Vertical' or 'Horizontal',2,graphicTemplate)
			Decal.Position = UDim2.new(0.5,-size/2,0.5,-size/2)
			Decal.Parent = ScrollThumbFrame
		end

		local Class = setmetatable({
			GUI = ScrollFrame;
			ScrollIndex = 0;
			VisibleSpace = 0;
			TotalSpace = 0;
			PageIncrement = 1;
		},mt)

		local UpdateScrollThumb
		if horizontal then
			function UpdateScrollThumb()
				ScrollThumbFrame.Size = UDim2.new(Class.VisibleSpace/Class.TotalSpace,0,0,GUI_SIZE)
				if ScrollThumbFrame.AbsoluteSize.x < GUI_SIZE then
					ScrollThumbFrame.Size = UDim2.new(0,GUI_SIZE,0,GUI_SIZE)
				end
				local barSize = ScrollBarFrame.AbsoluteSize.x
				ScrollThumbFrame.Position = UDim2.new(Class:GetScrollPercent()*(barSize - ScrollThumbFrame.AbsoluteSize.x)/barSize,0,0,0)
			end
		else
			function UpdateScrollThumb()
				ScrollThumbFrame.Size = UDim2.new(0,GUI_SIZE,Class.VisibleSpace/Class.TotalSpace,0)
				if ScrollThumbFrame.AbsoluteSize.y < GUI_SIZE then
					ScrollThumbFrame.Size = UDim2.new(0,GUI_SIZE,0,GUI_SIZE)
				end
				local barSize = ScrollBarFrame.AbsoluteSize.y
				ScrollThumbFrame.Position = UDim2.new(0,0,Class:GetScrollPercent()*(barSize - ScrollThumbFrame.AbsoluteSize.y)/barSize,0)
			end
		end

		local lastDown
		local lastUp
		local scrollStyle = {BackgroundColor3=GuiColor.Border,BackgroundTransparency=0}
		local scrollStyle_ds = {BackgroundColor3=GuiColor.Border,BackgroundTransparency=0.7}

		local function Update()
			local t = Class.TotalSpace
			local v = Class.VisibleSpace
			local s = Class.ScrollIndex
			if v <= t then
				if s > 0 then
					if s + v > t then
						Class.ScrollIndex = t - v
					end
				else
					Class.ScrollIndex = 0
				end
			else
				Class.ScrollIndex = 0
			end

			if Class.UpdateCallback then
				if Class.UpdateCallback(Class) == false then
					return
				end
			end

			local down = Class:CanScrollDown()
			local up = Class:CanScrollUp()
			if down ~= lastDown then
				lastDown = down
				ScrollDownFrame.Active = down
				ScrollDownFrame.AutoButtonColor = down
				local children = ScrollDownGraphic:GetChildren()
				local style = down and scrollStyle or scrollStyle_ds
				for i = 1,#children do
					Create(children[i],style)
				end
			end
			if up ~= lastUp then
				lastUp = up
				ScrollUpFrame.Active = up
				ScrollUpFrame.AutoButtonColor = up
				local children = ScrollUpGraphic:GetChildren()
				local style = up and scrollStyle or scrollStyle_ds
				for i = 1,#children do
					Create(children[i],style)
				end
			end
			ScrollThumbFrame.Visible = down or up
			UpdateScrollThumb()
		end
		Class.Update = Update

		SetZIndexOnChanged(ScrollFrame)

		local MouseDrag = Create('ImageButton',{
			Name = "MouseDrag";
			Position = UDim2.new(-0.25,0,-0.25,0);
			Size = UDim2.new(1.5,0,1.5,0);
			Transparency = 1;
			AutoButtonColor = false;
			Active = true;
			ZIndex = 10;
		})

		local scrollEventID = 0
		ScrollDownFrame.MouseButton1Down:connect(function()
			scrollEventID = tick()
			local current = scrollEventID
			local up_con
			up_con = MouseDrag.MouseButton1Up:connect(function()
				scrollEventID = tick()
				MouseDrag.Parent = nil
				ResetButtonColor(ScrollDownFrame)
				up_con:disconnect(); drag = nil
			end)
			MouseDrag.Parent = GetScreen(ScrollFrame)
			Class:ScrollDown()
			wait(0.2) -- delay before auto scroll
			while scrollEventID == current do
				Class:ScrollDown()
				if not Class:CanScrollDown() then break end
				wait()
			end
		end)

		ScrollDownFrame.MouseButton1Up:connect(function()
			scrollEventID = tick()
		end)

		ScrollUpFrame.MouseButton1Down:connect(function()
			scrollEventID = tick()
			local current = scrollEventID
			local up_con
			up_con = MouseDrag.MouseButton1Up:connect(function()
				scrollEventID = tick()
				MouseDrag.Parent = nil
				ResetButtonColor(ScrollUpFrame)
				up_con:disconnect(); drag = nil
			end)
			MouseDrag.Parent = GetScreen(ScrollFrame)
			Class:ScrollUp()
			wait(0.2)
			while scrollEventID == current do
				Class:ScrollUp()
				if not Class:CanScrollUp() then break end
				wait()
			end
		end)

		ScrollUpFrame.MouseButton1Up:connect(function()
			scrollEventID = tick()
		end)

		if horizontal then
			ScrollBarFrame.MouseButton1Down:connect(function(x,y)
				scrollEventID = tick()
				local current = scrollEventID
				local up_con
				up_con = MouseDrag.MouseButton1Up:connect(function()
					scrollEventID = tick()
					MouseDrag.Parent = nil
					ResetButtonColor(ScrollUpFrame)
					up_con:disconnect(); drag = nil
				end)
				MouseDrag.Parent = GetScreen(ScrollFrame)
				if x > ScrollThumbFrame.AbsolutePosition.x then
					Class:ScrollTo(Class.ScrollIndex + Class.VisibleSpace)
					wait(0.2)
					while scrollEventID == current do
						if x < ScrollThumbFrame.AbsolutePosition.x + ScrollThumbFrame.AbsoluteSize.x then break end
						Class:ScrollTo(Class.ScrollIndex + Class.VisibleSpace)
						wait()
					end
				else
					Class:ScrollTo(Class.ScrollIndex - Class.VisibleSpace)
					wait(0.2)
					while scrollEventID == current do
						if x > ScrollThumbFrame.AbsolutePosition.x then break end
						Class:ScrollTo(Class.ScrollIndex - Class.VisibleSpace)
						wait()
					end
				end
			end)
		else
			ScrollBarFrame.MouseButton1Down:connect(function(x,y)
				scrollEventID = tick()
				local current = scrollEventID
				local up_con
				up_con = MouseDrag.MouseButton1Up:connect(function()
					scrollEventID = tick()
					MouseDrag.Parent = nil
					ResetButtonColor(ScrollUpFrame)
					up_con:disconnect(); drag = nil
				end)
				MouseDrag.Parent = GetScreen(ScrollFrame)
				if y > ScrollThumbFrame.AbsolutePosition.y then
					Class:ScrollTo(Class.ScrollIndex + Class.VisibleSpace)
					wait(0.2)
					while scrollEventID == current do
						if y < ScrollThumbFrame.AbsolutePosition.y + ScrollThumbFrame.AbsoluteSize.y then break end
						Class:ScrollTo(Class.ScrollIndex + Class.VisibleSpace)
						wait()
					end
				else
					Class:ScrollTo(Class.ScrollIndex - Class.VisibleSpace)
					wait(0.2)
					while scrollEventID == current do
						if y > ScrollThumbFrame.AbsolutePosition.y then break end
						Class:ScrollTo(Class.ScrollIndex - Class.VisibleSpace)
						wait()
					end
				end
			end)
		end

		if horizontal then
			ScrollThumbFrame.MouseButton1Down:connect(function(x,y)
				scrollEventID = tick()
				local mouse_offset = x - ScrollThumbFrame.AbsolutePosition.x
				local drag_con
				local up_con
				drag_con = MouseDrag.MouseMoved:connect(function(x,y)
					local bar_abs_pos = ScrollBarFrame.AbsolutePosition.x
					local bar_drag = ScrollBarFrame.AbsoluteSize.x - ScrollThumbFrame.AbsoluteSize.x
					local bar_abs_one = bar_abs_pos + bar_drag
					x = x - mouse_offset
					x = x < bar_abs_pos and bar_abs_pos or x > bar_abs_one and bar_abs_one or x
					x = x - bar_abs_pos
					Class:SetScrollPercent(x/(bar_drag))
				end)
				up_con = MouseDrag.MouseButton1Up:connect(function()
					scrollEventID = tick()
					MouseDrag.Parent = nil
					ResetButtonColor(ScrollThumbFrame)
					drag_con:disconnect(); drag_con = nil
					up_con:disconnect(); drag = nil
				end)
				MouseDrag.Parent = GetScreen(ScrollFrame)
			end)
		else
			ScrollThumbFrame.MouseButton1Down:connect(function(x,y)
				scrollEventID = tick()
				local mouse_offset = y - ScrollThumbFrame.AbsolutePosition.y
				local drag_con
				local up_con
				drag_con = MouseDrag.MouseMoved:connect(function(x,y)
					local bar_abs_pos = ScrollBarFrame.AbsolutePosition.y
					local bar_drag = ScrollBarFrame.AbsoluteSize.y - ScrollThumbFrame.AbsoluteSize.y
					local bar_abs_one = bar_abs_pos + bar_drag
					y = y - mouse_offset
					y = y < bar_abs_pos and bar_abs_pos or y > bar_abs_one and bar_abs_one or y
					y = y - bar_abs_pos
					Class:SetScrollPercent(y/(bar_drag))
				end)
				up_con = MouseDrag.MouseButton1Up:connect(function()
					scrollEventID = tick()
					MouseDrag.Parent = nil
					ResetButtonColor(ScrollThumbFrame)
					drag_con:disconnect(); drag_con = nil
					up_con:disconnect(); drag = nil
				end)
				MouseDrag.Parent = GetScreen(ScrollFrame)
			end)
		end

		function Class:Destroy()
			ScrollFrame:Destroy()
			MouseDrag:Destroy()
			for k in pairs(Class) do
				Class[k] = nil
			end
			setmetatable(Class,nil)
		end

		Update()

		return Class
	end
end

----------------------------------------------------------------
----------------------------------------------------------------
----------------------------------------------------------------
----------------------------------------------------------------
---- Explorer panel

local explorerPanel = ExplorerFolder:WaitForChild("ExplorerPanel")

Create(explorerPanel,{
	Active = true;
})

local listFrame = Create('Frame',{
	Name = "List";
	BackgroundColor3 = GuiColor.Background;
	BackgroundTransparency = 1;
	ClipsDescendants = true;
	Position = UDim2.new(0,0,0,HEADER_SIZE);
	Size = UDim2.new(1,-GUI_SIZE,1,-HEADER_SIZE);
	Parent = explorerPanel;
})

local scrollBar = ScrollBar(false)
scrollBar.PageIncrement = 1
Create(scrollBar.GUI,{
	Position = UDim2.new(1,-GUI_SIZE,0,HEADER_SIZE);
	Size = UDim2.new(0,GUI_SIZE,1,-HEADER_SIZE);
	Parent = explorerPanel;
})

local scrollBarH = ScrollBar(true)
scrollBarH.PageIncrement = GUI_SIZE
Create(scrollBarH.GUI,{
	Position = UDim2.new(0,0,1,-GUI_SIZE);
	Size = UDim2.new(1,-GUI_SIZE,0,GUI_SIZE);
	Visible = false;
	Parent = explorerPanel;
})

local headerFrame = Create('Frame',{
	Name = "Header";
BackgroundColor3 = GuiColor.Background;
	BorderColor3 = GuiColor.Border;
	Position = UDim2.new(0,0,0,0);
	Size = UDim2.new(1,0,0,HEADER_SIZE);
	Parent = explorerPanel;
    BackgroundTransparency = 1;
	Create('TextLabel',{
		Text = "Explorer";
		BackgroundTransparency = 1;
		TextColor3 = GuiColor.Text;
		TextXAlignment = 'Left';
		Font = FONT;
		FontSize = FONT_SIZE;
		Position = UDim2.new(0,4,0,0);
		Size = UDim2.new(1,-4,1,0);
	});
})

SetZIndexOnChanged(explorerPanel)

local getTextWidth do
	local text = Create('TextLabel',{
		Name = "TextWidth";
		TextXAlignment = 'Left';
		TextYAlignment = 'Center';
		Font = FONT;
		FontSize = FONT_SIZE;
		Text = "";
		Position = UDim2.new(0,0,0,0);
		Size = UDim2.new(1,0,1,0);
		Visible = false;
		Parent = explorerPanel;
	})
	function getTextWidth(s)
		text.Text = s
		return text.TextBounds.x
	end
end

-- Holds the game tree converted to a list.
local TreeList = {}
-- Matches objects to their tree node representation.
local NodeLookup = {}

local nodeWidth = 0

local updateList,rawUpdateList,updateScroll,rawUpdateSize do
	local function r(t)
		for i = 1,#t do
			TreeList[#TreeList+1] = t[i]

			local w = (t[i].Depth)*(2+ENTRY_PADDING+GUI_SIZE) + 2 + ENTRY_SIZE + 4 + getTextWidth(t[i].Object.Name) + 4
			if w > nodeWidth then
				nodeWidth = w
			end
			if t[i].Expanded then
				r(t[i])
			end
		end
	end

	function rawUpdateSize()
		scrollBarH.TotalSpace = nodeWidth
		scrollBarH.VisibleSpace = listFrame.AbsoluteSize.x
		scrollBarH:Update()
		local visible = scrollBarH:CanScrollDown() or scrollBarH:CanScrollUp()
		scrollBarH.GUI.Visible = visible

		listFrame.Size = UDim2.new(1,-GUI_SIZE,1,-GUI_SIZE*(visible and 1 or 0) - HEADER_SIZE)

		scrollBar.VisibleSpace = math.ceil(listFrame.AbsoluteSize.y/ENTRY_BOUND)
		scrollBar.GUI.Size = UDim2.new(0,GUI_SIZE,1,-GUI_SIZE*(visible and 1 or 0) - HEADER_SIZE)

		scrollBar.TotalSpace = #TreeList+1
		scrollBar:Update()
	end

	function rawUpdateList()
		-- Clear then repopulate the entire list. It appears to be fast enough.
		TreeList = {}
		nodeWidth = 0
		r(NodeLookup[Game])
		rawUpdateSize()
	end

	-- Adding or removing large models will cause many updates to occur. We
	-- can reduce the number of updates by creating a delay, then dropping any
	-- updates that occur during the delay.
	local updatingList = false
	function updateList()
		if updatingList then return end
		updatingList = true
		wait(0.25)
		updatingList = false
		rawUpdateList()
	end

	local updatingScroll = false
	function updateScroll()
		if updatingScroll then return end
		updatingScroll = true
		wait(0.25)
		updatingScroll = false
		scrollBar:Update()
	end
end

local Selection do
	local bindGetSelection = explorerPanel:FindFirstChild("GetSelection")
	if not bindGetSelection then
		bindGetSelection = Create('BindableFunction',{Name = "GetSelection"})
		bindGetSelection.Parent = explorerPanel
	end

	local bindSetSelection =explorerPanel:FindFirstChild("SetSelection")
	if not bindSetSelection then
		bindSetSelection = Create('BindableFunction',{Name = "SetSelection"})
		bindSetSelection.Parent = explorerPanel
	end

	local bindSelectionChanged = explorerPanel:FindFirstChild("SelectionChanged")
	if not bindSelectionChanged then
		bindSelectionChanged = Create('BindableEvent',{Name = "SelectionChanged"})
		bindSelectionChanged.Parent = explorerPanel
	end

	local SelectionList = {}
	local SelectionSet = {}
	Selection = {
		Selected = SelectionSet;
		List = SelectionList;
	}

	local function addObject(object)
		-- list update
		local lupdate = false
		-- scroll update
		local supdate = false

		if not SelectionSet[object] then
			local node = NodeLookup[object]
			if node then
				table.insert(SelectionList,object)
				SelectionSet[object] = true
				node.Selected = true

				-- expand all ancestors so that selected node becomes visible
				node = node.Parent
				while node do
					if not node.Expanded then
						node.Expanded = true
						lupdate = true
					end
					node = node.Parent
				end
				supdate = true
			end
		end
		return lupdate,supdate
	end

	function Selection:Set(objects)
		local lupdate = false
		local supdate = false

		if #SelectionList > 0 then
			for i = 1,#SelectionList do
				local object = SelectionList[i]
				local node = NodeLookup[object]
				if node then
					node.Selected = false
					SelectionSet[object] = nil
				end
			end

			SelectionList = {}
			Selection.List = SelectionList
			supdate = true
		end

		for i = 1,#objects do
			local l,s = addObject(objects[i])
			lupdate = l or lupdate
			supdate = s or supdate
		end

		if lupdate then
			rawUpdateList()
			supdate = true
		elseif supdate then
			scrollBar:Update()
		end

		if supdate then
			bindSelectionChanged:Fire()
		end
	end

	function Selection:Add(object)
		local l,s = addObject(object)
		if l then
			rawUpdateList()
			bindSelectionChanged:Fire()
		elseif s then
			scrollBar:Update()
			bindSelectionChanged:Fire()
		end
	end

	function Selection:Remove(object,noupdate)
		if SelectionSet[object] then
			local node = NodeLookup[object]
			if node then
				node.Selected = false
				SelectionSet[object] = nil
				for i = 1,#SelectionList do
					if SelectionList[i] == object then
						table.remove(SelectionList,i)
						break
					end
				end

				if not noupdate then
					scrollBar:Update()
				end
				bindSelectionChanged:Fire()
			end
		end
	end

	function Selection:Get()
		local list = {}
		for i = 1,#SelectionList do
			list[i] = SelectionList[i]
		end
		return list
	end

	bindSetSelection.OnInvoke = function(...)
		Selection:Set(...)
	end

	bindGetSelection.OnInvoke = function()
		return Selection:Get()
	end
end

local function cancelReparentDrag()end
local function cancelSelectDrag()end
do
	local listEntries = {}
	local nameConnLookup = {}

	local mouseDrag = Create('ImageButton',{
		Name = "MouseDrag";
		Position = UDim2.new(-0.25,0,-0.25,0);
		Size = UDim2.new(1.5,0,1.5,0);
		Transparency = 1;
		AutoButtonColor = false;
		Active = true;
		ZIndex = 10;
	})
	local function dragSelect(last,add,button)
	
	end

	local function dragReparent(object,dragGhost,clickPos,ghostOffset)
		local connDrag
		local conUp
		local conUp2

		local parentIndex = nil
		local dragged = false

		local parentHighlight = Create('Frame',{
			Transparency = 1;
			Visible = false;
			Create('Frame',{
				BorderSizePixel = 0;
				BackgroundColor3 = Color3.new(0,0,0);
				BackgroundTransparency = 0.1;
				Position = UDim2.new(0,0,0,0);
				Size = UDim2.new(1,0,0,1);
			});
			Create('Frame',{
				BorderSizePixel = 0;
				BackgroundColor3 = Color3.new(0,0,0);
				BackgroundTransparency = 0.1;
				Position = UDim2.new(1,0,0,0);
				Size = UDim2.new(0,1,1,0);
			});
			Create('Frame',{
				BorderSizePixel = 0;
				BackgroundColor3 = Color3.new(0,0,0);
				BackgroundTransparency = 0.1;
				Position = UDim2.new(0,0,1,0);
				Size = UDim2.new(1,0,0,1);
			});
			Create('Frame',{
				BorderSizePixel = 0;
				BackgroundColor3 = Color3.new(0,0,0);
				BackgroundTransparency = 0.1;
				Position = UDim2.new(0,0,0,0);
				Size = UDim2.new(0,1,1,0);
			});
		})
		SetZIndex(parentHighlight,9)



		function cancelReparentDrag()
			mouseDrag.Parent = nil
			conUp:disconnect()
			conUp2:disconnect()
			dragGhost:Destroy()
			parentHighlight:Destroy()
			function cancelReparentDrag()end
		end

		local wasSelected = Selection.Selected[object]
		if not wasSelected and Option.Selectable then
			Selection:Set({object})
		end

		conUp = mouseDrag.MouseButton1Up:connect(function()
			cancelReparentDrag()
			if dragged then
				if parentIndex then
					local parentNode = TreeList[parentIndex + scrollBar.ScrollIndex]
					if parentNode then
						parentNode.Expanded = true

						local parentObj = parentNode.Object
						local function parent(a,b)
							a.Parent = b
						end
						if Option.Selectable then
							local list = Selection.List
							for i = 1,#list do
								pcall(parent,list[i],parentObj)
							end
						else
							pcall(parent,object,parentObj)
						end
					end
				end
			else
				-- do selection click
				if wasSelected and Option.Selectable then
					Selection:Set({})
				end
			end
		end)
		conUp2 = mouseDrag.MouseButton2Down:connect(function()
			cancelReparentDrag()
		end)

		mouseDrag.Parent = GetScreen(listFrame)
	end

	local entryTemplate = Create('ImageButton',{
		Name = "Entry";
		Transparency = 1;
		AutoButtonColor = false;
		Position = UDim2.new(0,0,0,0);
		Size = UDim2.new(1,0,0,ENTRY_SIZE);
		Create('Frame',{
			Name = "IndentFrame";
			BackgroundTransparency = 1;
			BackgroundColor3 = GuiColor.Selected;
			BorderColor3 = GuiColor.BorderSelected;
			Position = UDim2.new(0,0,0,0);
			Size = UDim2.new(1,0,1,0);
			Create(Icon('ImageButton',0),{
				Name = "Expand";
				AutoButtonColor = false;
				Position = UDim2.new(0,-GUI_SIZE,0.5,-GUI_SIZE/2);
				Size = UDim2.new(0,GUI_SIZE,0,GUI_SIZE);
			});
			Create(Icon(nil,0),{
				Name = "ExplorerIcon";
				Position = UDim2.new(0,2+ENTRY_PADDING,0.5,-GUI_SIZE/2);
				Size = UDim2.new(0,GUI_SIZE,0,GUI_SIZE);
			});
			Create('TextLabel',{
				Name = "EntryText";
				BackgroundTransparency = 1;
				TextColor3 = GuiColor.Text;
				TextXAlignment = 'Left';
				TextYAlignment = 'Center';
				Font = FONT;
				FontSize = FONT_SIZE;
				Text = "";
				Position = UDim2.new(0,2+ENTRY_SIZE+4,0,0);
				Size = UDim2.new(1,-2,1,0);
			});
		});
	})

	function scrollBar.UpdateCallback(self)
		for i = 1,self.VisibleSpace do
			local node = TreeList[i + self.ScrollIndex]
			if node then
				local entry = listEntries[i]
				if not entry then
					entry = Create(entryTemplate:Clone(),{
						Position = UDim2.new(0,2,0,ENTRY_BOUND*(i-1)+2);
						Size = UDim2.new(0,nodeWidth,0,ENTRY_SIZE);
						ZIndex = listFrame.ZIndex;
					})
					listEntries[i] = entry

					local expand = entry.IndentFrame.Expand
					expand.MouseEnter:connect(function()
						local node = TreeList[i + self.ScrollIndex]
						if #node > 0 then
							if node.Expanded then
								Icon(expand,NODE_EXPANDED_OVER)
							else
								Icon(expand,NODE_COLLAPSED_OVER)
							end
						end
					end)
					expand.MouseLeave:connect(function()
						local node = TreeList[i + self.ScrollIndex]
						if #node > 0 then
							if node.Expanded then
								Icon(expand,NODE_EXPANDED)
							else
								Icon(expand,NODE_COLLAPSED)
							end
						end
					end)
					expand.MouseButton1Down:connect(function()
						local node = TreeList[i + self.ScrollIndex]
						if #node > 0 then
							node.Expanded = not node.Expanded
							-- use raw update so the list updates instantly
							rawUpdateList()
						end
					end)

					entry.MouseButton1Down:connect(function(x,y)
						local node = TreeList[i + self.ScrollIndex]
						if Option.Modifiable then
							local pos = Vector2.new(x,y)
							dragReparent(node.Object,entry:Clone(),pos,entry.AbsolutePosition-pos)
						elseif Option.Selectable then
							if Selection.Selected[node.Object] then
								Selection:Set({})
							else
								Selection:Set({node.Object})
							end
							dragSelect(i+self.ScrollIndex,true,'MouseButton1Up')
						end
					end)

					entry.MouseButton2Down:connect(function()
						if not Option.Selectable then return end

						local node = TreeList[i + self.ScrollIndex]
						if Selection.Selected[node.Object] then
							Selection:Remove(node.Object)
							dragSelect(i+self.ScrollIndex,false,'MouseButton2Up')
						else
							Selection:Add(node.Object)
							dragSelect(i+self.ScrollIndex,true,'MouseButton2Up')
						end
					end)

					entry.Parent = listFrame
				end

				entry.Visible = true

				local object = node.Object

				-- update expand icon
				if #node == 0 then
					entry.IndentFrame.Expand.Visible = false
				elseif node.Expanded then
					Icon(entry.IndentFrame.Expand,NODE_EXPANDED)
					entry.IndentFrame.Expand.Visible = true
				else
					Icon(entry.IndentFrame.Expand,NODE_COLLAPSED)
					entry.IndentFrame.Expand.Visible = true
				end

				-- update explorer icon
				Icon(entry.IndentFrame.ExplorerIcon,ExplorerIndex[object.ClassName] or 0)

				-- update indentation
				local w = (node.Depth)*(2+ENTRY_PADDING+GUI_SIZE)
				entry.IndentFrame.Position = UDim2.new(0,w,0,0)
				entry.IndentFrame.Size = UDim2.new(1,-w,1,0)

				-- update name change detection
				if nameConnLookup[entry] then
					nameConnLookup[entry]:disconnect()
				end
				local text = entry.IndentFrame.EntryText
				text.Text = object.Name
				nameConnLookup[entry] = node.Object.Changed:connect(function(p)
					if p == 'Name' then
						text.Text = object.Name
					end
				end)

				-- update selection
				entry.IndentFrame.Transparency = node.Selected and 0 or 1
				text.TextColor3 = GuiColor[node.Selected and 'TextSelected' or 'Text']

				entry.Size = UDim2.new(0,nodeWidth,0,ENTRY_SIZE)
			elseif listEntries[i] then
				listEntries[i].Visible = false
			end
		end
		for i = self.VisibleSpace+1,self.TotalSpace do
			local entry = listEntries[i]
			if entry then
				listEntries[i] = nil
				entry:Destroy()
			end
		end
	end

	function scrollBarH.UpdateCallback(self)
		for i = 1,scrollBar.VisibleSpace do
			local node = TreeList[i + scrollBar.ScrollIndex]
			if node then
				local entry = listEntries[i]
				if entry then
					entry.Position = UDim2.new(0,2 - scrollBarH.ScrollIndex,0,ENTRY_BOUND*(i-1)+2)
				end
			end
		end
	end

	Connect(listFrame.Changed,function(p)
		if p == 'AbsoluteSize' then
			rawUpdateSize()
		end
	end)

	local wheelAmount = 6
	explorerPanel.MouseWheelForward:connect(function()
		if scrollBar.VisibleSpace - 1 > wheelAmount then
			scrollBar:ScrollTo(scrollBar.ScrollIndex - wheelAmount)
		else
			scrollBar:ScrollTo(scrollBar.ScrollIndex - scrollBar.VisibleSpace)
		end
	end)
	explorerPanel.MouseWheelBackward:connect(function()
		if scrollBar.VisibleSpace - 1 > wheelAmount then
			scrollBar:ScrollTo(scrollBar.ScrollIndex + wheelAmount)
		else
			scrollBar:ScrollTo(scrollBar.ScrollIndex + scrollBar.VisibleSpace)
		end
	end)
end

----------------------------------------------------------------
----------------------------------------------------------------
----------------------------------------------------------------
----------------------------------------------------------------
---- Object detection

-- Inserts `v` into `t` at `i`. Also sets `Index` field in `v`.
local function insert(t,i,v)
	for n = #t,i,-1 do
		local v = t[n]
		v.Index = n+1
		t[n+1] = v
	end
	v.Index = i
	t[i] = v
end

-- Removes `i` from `t`. Also sets `Index` field in removed value.
local function remove(t,i)
	local v = t[i]
	for n = i+1,#t do
		local v = t[n]
		v.Index = n-1
		t[n-1] = v
	end
	t[#t] = nil
	v.Index = 0
	return v
end

-- Returns how deep `o` is in the tree.
local function depth(o)
	local d = -1
	while o do
		o = o.Parent
		d = d + 1
	end
	return d
end


local connLookup = {}

-- Returns whether a node would be present in the tree list
local function nodeIsVisible(node)
	local visible = true
	node = node.Parent
	while node and visible do
		visible = visible and node.Expanded
		node = node.Parent
	end
	return visible
end

-- Removes an object's tree node. Called when the object stops existing in the
-- game tree.
local function removeObject(object)
	local objectNode = NodeLookup[object]
	if not objectNode then
		return
	end

	local visible = nodeIsVisible(objectNode)

	Selection:Remove(object,true)

	local parent = objectNode.Parent
	remove(parent,objectNode.Index)
	NodeLookup[object] = nil
	connLookup[object]:disconnect()
	connLookup[object] = nil

	if visible then
		updateList()
	elseif nodeIsVisible(parent) then
		updateScroll()
	end
end

-- Moves a tree node to a new parent. Called when an existing object's parent
-- changes.
local function moveObject(object,parent)
	local objectNode = NodeLookup[object]
	if not objectNode then
		return
	end

	local parentNode = NodeLookup[parent]
	if not parentNode then
		return
	end

	local visible = nodeIsVisible(objectNode)

	remove(objectNode.Parent,objectNode.Index)
	objectNode.Parent = parentNode

	objectNode.Depth = depth(object)
	local function r(node,d)
		for i = 1,#node do
			node[i].Depth = d
			r(node[i],d+1)
		end
	end
	r(objectNode,objectNode.Depth+1)

	insert(parentNode,#parentNode+1,objectNode)

	if visible or nodeIsVisible(objectNode) then
		updateList()
	elseif nodeIsVisible(objectNode.Parent) then
		updateScroll()
	end
end

-- ScriptContext['/Libraries/LibraryRegistration/LibraryRegistration']
-- This RobloxLocked object lets me index its properties for some reason

local function check(object)
	return object.AncestryChanged
end

-- Creates a new tree node from an object. Called when an object starts
-- existing in the game tree.
local function addObject(object,noupdate)
	if script then
		-- protect against naughty RobloxLocked objects
		local s = pcall(check,object)
		if not s then
			return
		end
	end

	local parentNode = NodeLookup[object.Parent]
	if not parentNode then
		return
	end

	local objectNode = {
		Object = object;
		Parent = parentNode;
		Index = 0;
		Expanded = false;
		Selected = false;
		Depth = depth(object);
	}

	connLookup[object] = Connect(object.AncestryChanged,function(c,p)
		if c == object then
			if p == nil then
				removeObject(c)
			else
				moveObject(c,p)
			end
		end
	end)

	NodeLookup[object] = objectNode
	insert(parentNode,#parentNode+1,objectNode)

	if not noupdate then
		if nodeIsVisible(objectNode) then
			updateList()
		elseif nodeIsVisible(objectNode.Parent) then
			updateScroll()
		end
	end
end

do
	NodeLookup[Game] = {
		Object = Game;
		Parent = nil;
		Index = 0;
		Expanded = true;
	}

	Connect(Game.DescendantAdded,addObject)
	Connect(Game.DescendantRemoving,removeObject)

	local function get(o)
		return o:GetChildren()
	end

	local function r(o)
		local s,children = pcall(get,o)
		if s then
			for i = 1,#children do
				addObject(children[i],true)
				r(children[i])
			end
		end
	end

	r(Game)

	scrollBar.VisibleSpace = math.ceil(listFrame.AbsoluteSize.y/ENTRY_BOUND)
	updateList()
end

----------------------------------------------------------------
----------------------------------------------------------------
----------------------------------------------------------------
----------------------------------------------------------------
---- Actions

local actionButtons do
	actionButtons = {}

	local totalActions = (4) + 5
	local currentActions = totalActions
	local function makeButton(icon,over,name)
		local button = Create(Icon('ImageButton',icon),{
			Name = name .. "Button";
			Visible = Option.Modifiable and Option.Selectable;
			Position = UDim2.new(1,-(GUI_SIZE+2)*currentActions+2,0.5,-GUI_SIZE/2);
			Size = UDim2.new(0,GUI_SIZE,0,GUI_SIZE);
			Parent = headerFrame;
		})

		local tipText = Create('TextLabel',{
			Name = name .. "Text";
			Text = name;
			Visible = false;
			BackgroundTransparency = 1;
			TextXAlignment = 'Right';
			Font = FONT;
			FontSize = FONT_SIZE;
			Position = UDim2.new(0,0,0,0);
			Size = UDim2.new(1,-(GUI_SIZE+2)*totalActions,1,0);
			Parent = headerFrame;
		})


		button.MouseEnter:connect(function()
			Icon(button,over)
			tipText.Visible = true
		end)
		button.MouseLeave:connect(function()
			Icon(button,icon)
			tipText.Visible = false
		end)

		currentActions = currentActions - 1
		actionButtons[#actionButtons+1] = button
		return button
	end

	local clipboard = {}
	local function delete(o)
		o.Parent = nil
	end

	-- CUT
	Selecting = false
	HoveredPart = nil
	makeButton(18,50,"Decompile").MouseButton1Click:connect(function()pcall(function()
		if not Option.Modifiable then return end
		local list = Selection.List[1]
		if list.ClassName == "LocalScript" or list.ClassName == "ModuleScript" then
			CopyString(decompile(list))
		end
	end)end)
	makeButton(54,54,"SelectPart").MouseButton1Click:connect(function()
		if not Selecting then
		Mouse = game.Players.LocalPlayer:GetMouse()
		Selection:Set({})
		Selecting = true
		HoveredPart = nil
		SBox = Instance.new("SelectionBox", game.Workspace.CurrentCamera)
		SBox.Color3 = Color3.new(1,1,1)
		MouseMoveEvent = Mouse.Move:connect(function()
			local Targ = Mouse.Target
			if Targ then
				if Targ ~= HoveredPart then
				HoveredPart = Targ
				SBox.Adornee = HoveredPart
				end
			else
				SBox.Adornee = nil
				HoveredPart = nil
			end
		end)
		MouseClickEvent = Mouse.Button1Down:connect(function()
			if HoveredPart ~= nil then
				SBox:Destroy()
				Selection:Set({HoveredPart})
				MouseMoveEvent:disconnect()
				MouseMoveEvent = nil
				MouseClickEvent:disconnect()
				MouseClickEvent = nil
				Selecting = false
			end
		end)
		end
	end)
	makeButton(61,59,"ClearChildren").MouseButton1Click:connect(function()
		if not Option.Modifiable then return end
		local list = Selection.List
		for i=1,#list do
			list[1]:ClearAllChildren()
		end
	end)
	makeButton(1,0,"Create").MouseButton1Click:connect(function()
		if not Option.Modifiable then return end
		CreateInstanceF.Visible = true
	end)
	makeButton(ACTION_CUT,ACTION_CUT_OVER,"Cut").MouseButton1Click:connect(function()
		if not Option.Modifiable then return end
		clipboard = {}
		local list = Selection.List
		local cut = {}
		for i = 1,#list do
			local obj = list[i]:Clone()
			if obj then
				table.insert(clipboard,obj)
				table.insert(cut,list[i])
			end
		end
		for i = 1,#cut do
			pcall(delete,cut[i])
		end
	end)

	-- COPY
	makeButton(ACTION_COPY,ACTION_COPY_OVER,"Copy").MouseButton1Click:connect(function()
		if not Option.Modifiable then return end
		clipboard = {}
		local list = Selection.List
		for i = 1,#list do
			table.insert(clipboard,list[i]:Clone())
		end
	end)

	-- PASTE
	makeButton(ACTION_PASTE,ACTION_PASTE_OVER,"Paste").MouseButton1Click:connect(function()
		if not Option.Modifiable then return end
		local parent = Selection.List[1] or Workspace
		for i = 1,#clipboard do
			clipboard[i]:Clone().Parent = parent
		end
	end)

	-- DELETE
	makeButton(ACTION_DELETE,ACTION_DELETE_OVER,"Delete").MouseButton1Click:connect(function()
		if not Option.Modifiable then return end
		local list = Selection:Get()
		for i = 1,#list do
			pcall(delete,list[i])
		end
		Selection:Set({})
	end)

	-- SORT
	-- local actionSort = makeButton(ACTION_SORT,ACTION_SORT_OVER,"Sort")
end

----------------------------------------------------------------
----------------------------------------------------------------
----------------------------------------------------------------
----------------------------------------------------------------
---- Option Bindables

do
	local optionCallback = {
		Modifiable = function(value)
			for i = 1,#actionButtons do
				actionButtons[i].Visible = value and Option.Selectable
			end
			cancelReparentDrag()
		end;
		Selectable = function(value)
			for i = 1,#actionButtons do
				actionButtons[i].Visible = value and Option.Modifiable
			end
			cancelSelectDrag()
			Selection:Set({})
		end;
	}

	local bindSetOption = explorerPanel:FindFirstChild("SetOption")
	if not bindSetOption then
		bindSetOption = Create('BindableFunction',{Name = "SetOption"})
		bindSetOption.Parent = explorerPanel
	end

	bindSetOption.OnInvoke = function(optionName,value)
		if optionCallback[optionName] then
			Option[optionName] = value
			optionCallback[optionName](value)
		end
	end

	local bindGetOption = explorerPanel:FindFirstChild("GetOption")
	if not bindGetOption then
		bindGetOption = Create('BindableFunction',{Name = "GetOption"})
		bindGetOption.Parent = explorerPanel
	end

	bindGetOption.OnInvoke = function(optionName)
		if optionName then
			return Option[optionName]
		else
			local options = {}
			for k,v in pairs(Option) do
				options[k] = v
			end
			return options
		end
	end
end
end)



--[[CreateInstance]]--



spawn(function()
	GUI = ExplorerFolder
EXPL = GUI:WaitForChild("ExplorerPanel")
FRM = ExplorerFolder:WaitForChild("CreateInstance")
Close = FRM:WaitForChild("Close")
Createt = FRM:WaitForChild("Create")
InstanceName = FRM:WaitForChild("Instance")
Close.MouseButton1Down:connect(function()
	FRM.Visible = false
end)
Createt.MouseButton1Down:connect(function()
local Object = EXPL.GetSelection:Invoke()[1]
if Object then
	pcall(function()
		Instance.new(InstanceName.Text).Parent = Object
	end)
end
end)
end)



--[[Dump]]--


spawn(function()
	local Properties = ExplorerFolder:WaitForChild("PropertiesPanel")
	local Lists = Properties:WaitForChild("List")
local Studio = ExplorerFolder
local Explorer = Studio:WaitForChild("ExplorerPanel")
AutoUpdate = false --change to true if fixed
Explorer:WaitForChild("List")
Explorer:WaitForChild("SelectionChanged")
function Recursive(Parent,Do)
	for _,v in pairs(Parent:GetChildren())do
		Do(v)
		Recursive(v,Do)
	end
end

Recursive(Studio,function(child)
	if child:IsA("GuiObject") then
		child.ZIndex = 10
	end
end)
Studio.ChildAdded:connect(function(child)
	if child:IsA("GuiObject") then
		child.ZIndex = 10
	end
end)
Studio.DescendantAdded:connect(function(child) -- same as above? idk
	if child:IsA("GuiObject") then
		child.ZIndex = 10
	end
end)

wait(2)

local Alphabet = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"}

local Properties_TBL = {"AbsolutePosition","AbsoluteSize","AccountAge","AccountAgeReplicate",
"Active","Adornee","AllowAmbientOcclusion","AllowTeamChangeOnTouch","AluminumQuality",
"AlwaysOnTop","Ambient","AmbientReverb","Anchored","Angularvelocity","AnimationId",
"Archivable","AreHingesDetected","AttachmentForward","AttachmentPoint","AttachmentPos",
"AttachmentRight","AttachmentUp","AutoAssignable","AutoButtonColor","AutoColorCharacters",
"AvailablePhysicalMemory","Axes","BackgroundColor","BackgroundColor3","BackgroundTransparency",
"BaseTextureId","BaseUrl","Bevel","Roundness","BinType","BlastPressure","BlastRadius",
"BodyColor","BodyPart","BorderColor","BorderColor3","BorderSizePixel","BrickColor",
"Brightness","Browsable","BubbleChat","BubbleChatLifetime","BubbleChatMaxBubbles",
"Bulge","Button1DownConnectionCount","Button1UpConnectionCount","Button2DownConnectionCount",
"Button2UpConnectionCount","C0","C1","CameraMode","CameraSubject","CameraType",
"CanBeDropped","CanCollide","CartoonFactor","CastShadows","CelestialBodiesShown",
"CFrame","Cframe","Character","CharacterAppearance","CharacterAutoLoads","ChatScrollLength",
"ClassicChat","ClassName","ClearTextOnFocus","ClipsDescendants","CollisionSoundEnabled",
"CollisionSoundVolume","Color","Bottom","Top","ConstrainedValue","ControllingHumanoid",
"ControlMode","ConversationDistance","CoordinateFrame","CorrodedMetalQuality","CPU",
"CpuCount","CpuSpeed","CreatorId","CreatorType","CurrentAngle","CurrentCamera",
"CycleOffset","D","DataCap","DataComplexity","DataComplexityLimit","DataCost",
"DataReady","Deprecated","DeselectedConnectionCount","DesiredAngle","DiamondPlateQuality",
"Disabled","DistanceFactor","DistributedGameTime","DopplerScale","Draggable","DraggingV1",
"Duration","EditorFont","EditorFontSize","EditorTabWidth","ElapsedTime","Elasticity",
"Enabled","ExplosionType","ExtentsOffset","F0","F1","F2","F3","Face","FaceId","Faces",
"FieldOfView","Focus","FogColor","FogEnd","FogStart","Font","FontSize","Force","FormFactor",
"Friction","From","GearGenreSetting","Genre","GeographicLatitude","GfxCard","Graphic",
"GrassQuality","Grip","GripForward","GripPos","GripRight","GripUp","Guest","HeadsUpDisplay",
"Health","Heat","Hit","Humanoid","IceQuality","Icon","IdleConnectionCount","Image",
"InitialPrompt","InOut","InUse","IsPaused","IsPlaying","JobId","Jump","KeyDownConnectionCount",
"KeyUpConnectionCount","LeftLeg","LeftRight","LinkedSource","LocalPlayer","Location",
"Locked","LODX","LODY","Looped","Material","MaxActivationDistance","MaxCollisionSounds",
"MaxExtents","MaxForce","MaxHealth","MaxItems","MaxPlayers","MaxSpeed","MaxThrust",
"MaxTorque","MaxValue","MaxVelocity","MembershipType","MembershipTypeReplicate","MeshId",
"MeshType","MinValue","Modal","MouseButton1ClickConnectionCount","MouseButton1DownConnectionCount",
"MouseButton1UpConnectionCount","MouseButton2ClickConnectionCount","MouseButton2DownConnectionCount",
"MouseButton2UpConnectionCount","MouseDelta","MouseDragConnectionCount","MouseEnterConnectionCount",
"MouseHit","MouseLeaveConnectionCount","MouseLock","MouseMovedConnectionCount","MouseTarget",
"MouseTargetFilter","MouseTargetSurface","MoveConnectionCount","MoveState","MultiLine","Name",
"NameOcclusion","NetworkOwner","Neutral","NumPlayers","Offset","Opacity","Origin","OsPlatform",
"OsVer","OverlayTextureId","P","PantsTemplate","ParamA","ParamB","Parent","Part","Part0",
"Part1","Pitch","PixelShaderModel","PlaceId","PlasticQuality","PlatformStand","PlayCount",
"PlayerToHideFrom","PlayOnRemove","Point","Port","Position","Preliminary","PrimaryPart",
"PrivateWorkingSetBytes","Purpose","RAM","Reflectance","ReplicatedSelectedConnectionCount",
"ResizeableFaces","ResizeIncrement","Resolution","ResponseDialog","RightLeg","RiseVelocity",
"RobloxLocked","RobloxVersion","RolloffScale","RotVelocity","Scale","Score","ScriptsDisabled",
"SecondaryColor","Selected","ShadowColor","Shape","Shiny","ShirtTemplate","ShowDeprecatedObjects",
"ShowDevelopmentGui","ShowPreliminaryObjects","Sides","Sit","Size","SizeConstraint",
"SizeOffset","SkinColor","SkyboxBk","SkyboxDn","SkyboxFt","SkyboxLf","SkyboxRt","SkyboxUp",
"SlateQuality","SoundId","Source","SparkleColor","Specular","StarCount",
"Steer","StickyWheels","StudsBetweenTextures","StudsOffset","StudsPerTileU","StudsPerTileV",
"Style","Summary","SuperSafeChatReplicate","Surface","Surface0",
"Surface1","SurfaceInput","Target","TargetFilter","TargetOffset","TargetPoint",
"TargetRadius","TargetSurface","TeamColor","Terrain","Text","TextBounds","TextColor","TextColor3",
"TextFits","TextScaled","TextStrokeColor3","TextStrokeTransparency","TextTransparency","Texture",
"TextureId","TextureSize","TextWrap","TextWrapped","TextXAlignment","TextYAlignment","Throttle",
"ThrustD","ThrustP","Ticket","Time","TimeOfDay","To","Tone","ToolTip","TopBottom","Torque","Torso",
"Transparency","TrussDetail","TurnD","TurnP","TurnSpeed","UnitRay","UserDialog","UserId","Value",
"Version","VertexColor","VideoCaptureEnabled","VideoMemory","VideoQuality",
"ViewSizeX","ViewSizeY","Visible","Volume","WalkDirection","WalkSpeed","WalkToPart","WalkToPoint",
"WheelBackwardConnectionCount","WheelForwardConnectionCount","WindowSize","WireRadius","WoodQuality",
"X","Y","Size","Radius"}

local LockedProperties = { -- cant be edited
	"ClassName",
	"Parent",
	"userId",
	"MembershipType",
	"CameraSubject",
	"FilteringEnabled",
}

local LockedItems = { -- cant be edited
	
}

function GetProperties(obj)
	assert(pcall(function() assert(game.IsA(obj,"Instance")) end),"Should be ROBLOX instance")
	local objProper = {}
	for i = 1,#Properties_TBL do
		local v = Properties_TBL[i]
		if pcall(function() return obj[v] end) and ( not obj:FindFirstChild(v)) then
			objProper[#objProper+1] = v
		end
	end
	return objProper
end

local Player = game:service"Players".LocalPlayer
local Mouse = Player:GetMouse()
local guis_enabled = {}
if game:service"StarterGui":GetCoreGuiEnabled(0) then
	guis_enabled[0] = true
end
if game:service"StarterGui":GetCoreGuiEnabled(1) then
	guis_enabled[1] = true
end
if game:service"StarterGui":GetCoreGuiEnabled(2) then
	guis_enabled[2] = true
end
if game:service"StarterGui":GetCoreGuiEnabled(3) then
	guis_enabled[3] = true
end

-- generik scroll:
local scroll = Properties:WaitForChild("ScrollFrame")
scroll:WaitForChild("ScrollBar"):WaitForChild("ScrollThumb")
local down,up
scroll.ScrollBar.MouseButton1Click:connect(function()
if 	_G.Disabled == true then
else
		scroll.ScrollBar.ScrollThumb.Position = UDim2.new(0,0,0,scroll.ScrollBar.AbsolutePosition.Y-Mouse.Y)
end

end)
debounce = false
scroll.ScrollBar.ScrollThumb.Changed:connect(function()
if ExplorerFolder.Position == UDim2.new(0,0,0,0) then
	if 	_G.Disabled == true then 
	else
		debounce = false
	scroll.ScrollBar.ScrollThumb.Position = UDim2.new(0,0,0,scroll.ScrollBar.ScrollThumb.Position.Y.Offset)
	local p = scroll.ScrollBar.ScrollThumb.Position
	if p.Y.Offset < 0 then
		scroll.ScrollBar.ScrollThumb.Position = UDim2.new(0,0,0,0)
	end
	if p.Y.Offset > scroll.ScrollBar.AbsoluteSize.Y-scroll.ScrollBar.ScrollThumb.Size.Y.Offset then
		scroll.ScrollBar.ScrollThumb.Position = UDim2.new(0,0,0,scroll.ScrollBar.AbsoluteSize.Y-scroll.ScrollBar.ScrollThumb.Size.Y.Offset)
	end
	if p.Y.Offset > (23*#Properties.List:GetChildren())-(scroll.ScrollBar.ScrollThumb.Size.Y.Offset/2) then
		scroll.ScrollBar.ScrollThumb.Position = UDim2.new(0,0,0,(23*#Properties.List:GetChildren())-(scroll.ScrollBar.ScrollThumb.Size.Y.Offset/2))
	end
	for _,v in pairs(Lists:GetChildren())do
		v.Position = UDim2.new(0,0,0,v:WaitForChild("BasePosition").Value)-UDim2.new(0,0,0,4*scroll.ScrollBar.ScrollThumb.Position.Y.Offset)
	end
			
	end
else
	
end 
	

end)
scroll.ScrollDown.MouseButton1Down:connect(function()
	down = true
	repeat wait(.001) for _,v in pairs(Properties.List:GetChildren())do v.Position = v.Position - UDim2.new(0,0,0,1) end until not down
end)
scroll.ScrollDown.MouseButton1Up:connect(function()
	down = false
end)
scroll.ScrollDown.MouseLeave:connect(function()
	down = false
end)
scroll.ScrollUp.MouseButton1Down:connect(function()
	up = true
	repeat wait(.001) for _,v in pairs(Properties.List:GetChildren())do v.Position = v.Position + UDim2.new(0,0,0,1) end until not up
end)
scroll.ScrollUp.MouseButton1Up:connect(function()
	up = false
end)
scroll.ScrollUp.MouseLeave:connect(function()
	up = false
end)

function findInTable(tbl,f)
	for _,v in pairs(tbl)do
		if v == f then
			return true
		end
	end
	return false
end

function GetPropertyType(prop,obj)
	local propv = obj[prop]
	if type(propv) == "userdata" then
		local type = "instance"
		pcall(function() -- Detect Vector3
			local x,y,z,lv = propv.X,propv.Y,propv.Z,propv.unit.Z
			if x and y and z and lv then
				type = "vector3"
			end
		end)
		pcall(function() -- Detect CFrame
			local x,y,z,lv,p = propv.X,propv.Y,propv.Z,propv.lookVector,propv.p
			if x and y and z and lv and p then
				type = "cframe"
			end
		end)
		pcall(function() -- Detect UDim2
			local x,y,o1,o2 = propv.X.Offset,propv.Y.Offset,propv.X.Scale,propv.Y.Scale
			if x and y and o1 and o2 then
				type = "udim2"
			end
		end)
		pcall(function() -- Detect BrickColor
			local r,g,b,n,c = propv.r,propv.g,propv.b,propv.Name,propv.Color
			if r and g and b and n and c then
				type = "brickcolor"
			end
		end)
		pcall(function() -- Detect Color3
			local r,g,b = propv.r,propv.g,propv.b
			if r and g and b and not type == "brickcolor" then
				type = "color3"
			end
		end)
		pcall(function() -- Detect enum
			if tostring(propv):sub(1,#"Enum.") == "Enum." then
				type = "enum"
			end
		end)
		return type
	elseif type(propv) == "number" then
		return "number"
	elseif type(propv) == "string" then
		return "string"
	elseif type(propv) == "boolean" then
		return "boolean"
	end
	return "string" -- hm...
end

local Object
local Events = {}
local color = Color3.new(237/255, 237/255, 238/255)
local ocolor = color
Explorer.SelectionChanged.Event:connect(function()
	
	for _,v in pairs(Events)do v:disconnect() end
	Properties.List:ClearAllChildren()
	
	Object = Explorer.GetSelection:Invoke()[1]
	if Object then
		local DoNotUpdate = false
		local function LoadPropsk()
		color = ocolor
		for _,v in pairs(Events)do v:disconnect() end
		Properties.List:ClearAllChildren()
		local Properties_list = GetProperties(Object)
		for i=1,#Properties_list do
			local _ = Properties_list[i]
			if color ~= ocolor then
				color = ocolor
			else
				color = Color3.new(221/255, 221/255, 222/255)
			end
			local ui = Properties.property:Clone()
			ui.Visible = true
			ui.BackgroundColor3 = color
			ui.Parent = Properties.List
			ui.Position = UDim2.new(0,0,0,(22*(#Properties.List:GetChildren()-1))+(1*(#Properties.List:GetChildren()-1)))
			ui.name.locked.Text = _
			ui.name.unlocked.Text = _
			local bp = Instance.new("NumberValue",ui)
			bp.Name = "BasePosition"
			bp.Value = ui.Position.Y.Offset
			if findInTable(LockedProperties,_) then
				ui.name.locked.Visible = true
			else
				ui.name.unlocked.Visible = true
			end
			local type = GetPropertyType(_,Object)
			local propv = Object[_]
			local img_checked = "http://www.roblox.com/asset/?id=48138491"
			local img_unchecked = "http://www.roblox.com/asset/?id=48138474"
			ui.edit.box.FocusLost:connect(function() LoadPropsk() DoNotUpdate = false end)
			ui.edit.box.Focused:connect(function() DoNotUpdate = true end)
			if findInTable(LockedProperties,_) then
				ui.edit.locked.Visible = true
				ui.edit.locked.Text = tostring(propv)
			elseif type == "number" or type == "string" then
				ui.edit.box.Visible = true
				ui.edit.box.Text = tostring(propv)
				ui.edit.box.FocusLost:connect(function()
					if type == "number" then
						Object[_] = tonumber(ui.edit.box.Text)
					else
						Object[_] = ui.edit.box.Text
					end
				end)
			elseif type == "boolean" then
				ui.edit.check.Visible = true
				if propv then
					ui.edit.check.Image = img_checked
				else
					ui.edit.check.Image = img_unchecked
				end
				ui.edit.check.MouseButton1Click:connect(function() pcall(function()
					Object[_] = not Object[_]
					propv = Object[_]
					if propv then
						ui.edit.check.Image = img_checked
					else
						ui.edit.check.Image = img_unchecked
					end end)
				end)
			elseif type == "instance" then
				ui.edit.locked.Visible = true
				ui.edit.locked.Text = tostring(propv)
			elseif type == "vector3" then
				ui.edit.box.Visible = true
				ui.edit.box.Text = propv.X..", "..propv.Y..", "..propv.Z
				local origit = ui.edit.box.Text
				ui.edit.box.FocusLost:connect(function()
					local x,y,z
					local n = 1
					for match in ui.edit.box.Text:gsub(" ",""):gmatch("[^,]+") do
						if n == 1 then x = tonumber(match) end
						if n == 2 then y = tonumber(match) end
						if n == 3 then z = tonumber(match) end
						n = n + 1
					end
					x,y,z = tonumber(x),tonumber(y),tonumber(z)
					local origi = Object[_] if not pcall(function() Object[_] = Vector3.new(x,y,z) end) then Object[_] = origi ui.edit.box.Text = origit else origit = ui.edit.box.Text end
				end)
			elseif type == "cframe" then
				ui.edit.box.Visible = true
				ui.edit.box.Text = propv.p.X..", "..propv.p.Y..", "..propv.p.Z
				local origit = ui.edit.box.Text
				ui.edit.box.FocusLost:connect(function()
					local x,y,z
					local n = 1
					for match in ui.edit.box.Text:gsub(" ",""):gmatch("[^,]+") do
						if n == 1 then x = tonumber(match) end
						if n == 2 then y = tonumber(match) end
						if n == 3 then z = tonumber(match) end
						n = n + 1
					end
					x,y,z = tonumber(x),tonumber(y),tonumber(z)
					local origi = Object[_] if not pcall(function() Object[_] = CFrame.new(x,y,z) end) then Object[_] = origi ui.edit.box.Text = origit else origit = ui.edit.box.Text end
				end)
			elseif type == "udim2" then
				ui.edit.box.Visible = true
				ui.edit.box.Text = "{"..propv.X.Scale..", "..propv.X.Offset.."}, {"..propv.Y.Scale..", "..propv.Y.Offset.."}"
				local origit = ui.edit.box.Text
				ui.edit.box.FocusLost:connect(function()
					local xscale,xoffset,yscale,yoffset
					local n = 1
					for match in ui.edit.box.Text:gsub(" ",""):gsub("}",""):gsub("{",""):gmatch("[^,]+") do
						if n == 1 then xscale = tonumber(match) end
						if n == 2 then xoffset = tonumber(match) end
						if n == 3 then yscale = tonumber(match) end
						if n == 4 then yoffset = tonumber(match) end
						n = n + 1
					end
					xscale,xoffset,yscale,yoffset = tonumber(xscale),tonumber(xoffset),tonumber(yscale),tonumber(yoffset)
					local origi = Object[_] if not pcall(function() Object[_] = UDim2.new(xscale,xoffset,yscale,yoffset) end) then Object[_] = origi ui.edit.box.Text = origit else origit = ui.edit.box.Text end
				end)
			elseif type == "color3" then
				ui.edit.box.Visible = true
				ui.edit.box.Text = propv.r*255 ..", "..propv.g*255 ..", "..propv.b*255
				local origit = ui.edit.box.Text
				ui.edit.box.FocusLost:connect(function()
					local r,g,b
					local n = 1
					for match in ui.edit.box.Text:gsub(" ",""):gmatch("[^,]+") do
						if n == 1 then r = tonumber(match) end
						if n == 2 then g = tonumber(match) end
						if n == 3 then b = tonumber(match) end
						n = n + 1
					end
					r,g,b = tonumber(r)/255,tonumber(g)/255,tonumber(b)/255
					local origi = Object[_] if not pcall(function() Object[_] = Color3.new(r,g,b) end) then Object[_] = origi ui.edit.box.Text = origit else origit = ui.edit.box.Text end
				end)
			elseif type == "brickcolor" then
				ui.edit.box.Visible = true
				ui.edit.box.Text = tostring(propv)
				local origit = ui.edit.box.Text
				ui.edit.box.FocusLost:connect(function()
					local origi = Object[_] if not pcall(function() Object[_] = BrickColor.new(ui.edit.box.Text) end) then Object[_] = origi ui.edit.box.Text = origit else origit = ui.edit.box.Text end
				end)
			elseif type == "enum" then
				ui.edit.box.Visible = true
				ui.edit.box.Text = tostring(propv)
				local origit = ui.edit.box.Text
				ui.edit.box.FocusLost:connect(function()
					local origi = Object[_] if not pcall(function() Object[_] = loadstring("return "..ui.edit.box.Text)() end) then Object[_] = origi ui.edit.box.Text = origit else origit = ui.edit.box.Text end
				end)
			end
			Events[#Events + 1] = Object.Changed:connect(function() if not DoNotUpdate and AutoUpdate then LoadPropsk() end end)
		end
		end
		LoadPropsk()
	end
end)
end)



--[[OutputPanel]]--



spawn(function()
	local PushOutput = Instance.new("BindableFunction")
PushOutput.Name = "PushOutput"
PushOutput.Parent = ExplorerFolder:WaitForChild("OutputPanel")
	game:GetService"LogService".MessageOut:connect(function(message,messageType)
	PushOutput:Invoke(message,messageType)
end)



local Explorer = ExplorerFolder:WaitForChild("ExplorerPanel")
Explorer:WaitForChild("List")
Explorer:WaitForChild("SelectionChanged")
local Output = ExplorerFolder:WaitForChild("OutputPanel")
_G.___outputgui = Output
local Command = ExplorerFolder:WaitForChild("OutputPanel")
local Properties = ExplorerFolder:WaitForChild("CommandPanel")
local Studio = ExplorerFolder

ExplorerFolder:WaitForChild("OutputPanel"):WaitForChild("PushOutput").OnInvoke = function(message,messageType)
	if not _G.___outputgui then return end
	local l = Instance.new("TextLabel")
	l.Size = UDim2.new(1,0,0,15)
	l.BackgroundTransparency = 1
	l.TextColor3 = Color3.fromRGB(255,255,255)
	l.Text = message
	l.Position = UDim2.new(0,0,1,-15)
	if messageType == Enum.MessageType.MessageError then
		l.TextColor3 = Color3.fromRGB(255,0,0)
	elseif messageType == Enum.MessageType.MessageInfo then
		l.TextColor3 = Color3.new(0.4, 0.5, 1)
	elseif messageType == Enum.MessageType.MessageWarning then
		l.TextColor3 = Color3.new(1, 0.6, 0.4)
	end
	l.TextScaled = true
	for _,v in pairs(_G.___outputgui.List:GetChildren())do
		v.Position = v.Position - UDim2.new(0,0,0,16)
	end
	l.Parent = _G.___outputgui.List
end
end)


--[[Dump]]--



spawn(function()
	local bubbleimg = "http://www.roblox.com/asset/?id=263433152"
local bpos = 0
local maxbubbles = 50
local bubbles = true
local dump = ExplorerFolder:WaitForChild("Dump")
game:GetService("RunService").RenderStepped:connect(function()
if bubbles == true then
			if bpos < maxbubbles then
				MakeBubble(dump)
			end
end
end)
dump.ChildRemoved:connect(function(child)
	if child.Name == "Bubble" then
		bpos = bpos - 1
	end 
end)
function MakeBubble(parent)
	local bubble = Instance.new ("ImageLabel")
	bubble.Parent = dump
	local bubblespeed = math.random(5,10) -- the more, the slower
	bubble.Name = "Bubble"
	bubble.BackgroundTransparency = 1
	local maxposy = math.random (1,9)
	local spawnX = math.random (1,10)
	bubble.Image = bubbleimg
	bubble.ImageColor3 = Color3.new (220/220, 220/220, 220/220)
	local size = math.random (1,3)
	bubble.Size = UDim2.new (0,size,0,size)
	bubble.Position = UDim2.new (spawnX/10,0,1,0)
	bubble.ZIndex = parent.ZIndex+2
	bubble.ImageTransparency = 0.5
	local randomX = math.random (1,10)
	bubble:TweenPosition(UDim2.new(randomX/10, 0, maxposy/10, 0), "Out", "Linear",bubblespeed, true)
	game:GetService("Debris"):AddItem(bubble,bubblespeed)
	bpos = bpos +1
end
end)