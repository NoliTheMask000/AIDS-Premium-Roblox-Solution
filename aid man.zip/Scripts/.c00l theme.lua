-- Remove todos os sons existentes
for i, v in pairs(game.Workspace:GetChildren()) do
	if v:IsA("Sound") then
		v:Stop()
		v:Destroy()
	end
end

-- IDs das partes da música Classic C00lkidd
local musicParts = {
	104570724610975, -- part 1
	91824290033214,  -- part 2
	98626162521082,  -- part 3
	114573847650036, -- part 4
	98527792396195,  -- part 5
	138003843805735,-- part 7
	82631331316597,  -- part 8
	99247640743717,  -- part 9
	95261884054124,  -- part 10
}

-- Configurações gerais
local volume = 10
local pitch = 0.2

-- Função que toca cada parte
local function playPart(id)
	local s = Instance.new("Sound")
	s.Parent = game.Workspace
	s.SoundId = "rbxassetid://" .. id
	s.Volume = volume
	s.Pitch = pitch
	s.Looped = false
	s:Play()

	-- Espera o som começar
	repeat task.wait(0.05) until s.IsPlaying or s.TimeLength > 0

	-- Espera o som terminar
	repeat task.wait(0.1) until not s.IsPlaying
	s:Destroy()
end

-- Loop infinito das 10 partes
while true do
	for _, id in ipairs(musicParts) do
		playPart(id)
	end
end